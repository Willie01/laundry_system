//
//  ProfileSheetViewController.swift
//  Client
//
//  Created by BJQXDN0527 on 2017/4/10.
//  Copyright © 2017年 36Kr. All rights reserved.
//

import UIKit

class ProfileSheetViewController: UIViewController, UIViewControllerTransitioningDelegate {

    let pickerView: ProfilePickerView = {
        let view = ProfilePickerView()
        view.backgroundColor = UIColor.whiteColor()
        return view
    }()
//    private var saveSuccessClosure: (SimpleUserEntity -> Void)?
//    private var userEntity: SimpleUserEntity?
//    private var type: ProfileType?
    
    init() {
        super.init(nibName: nil, bundle: nil)
        transitioningDelegate = self
        modalPresentationStyle = .Custom
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func present(animated: Bool = true, completion: (() -> Void)? = nil) {
        UIViewController.topMostViewController()?.presentViewController(self, animated: animated, completion: completion)
    }
    
    // MARK: UIViewControllerTransitioningDelegate
    
    func presentationControllerForPresentedViewController(presented: UIViewController, presentingViewController presenting: UIViewController, sourceViewController source: UIViewController) -> UIPresentationController? {
        return PresentationController(presentedViewController: presented, presentingViewController: presenting)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(pickerView)
        pickerView.cancelClosure = {
            self.dismissViewControllerAnimated(true, completion: {
                
            })
        }
        pickerView.saveClosure = { (profile, entity) in
            if let type = self.type, let id = self.userEntity?.id {
                print(profile)
                UserManager.manager.updateUserProfile(profile, uid: id, type: type, completion: { (status, message) in
                    if status == true {
                        HUD.showSuccess("保存成功")
                        self.userEntity = entity
                        self.saveSuccessClosure?(entity)
                        self.dismissViewControllerAnimated(true, completion: {
                        })
                    } else {
                        if let message = message {
                            HUD.showError(message)
                        } else {
                            HUD.showError("保存失败，请重新提交")
                        }
                    }
                })
            }
        }
        // Do any additional setup after loading the view.
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        pickerView.left = 0
        pickerView.bottom = view.bottom
        pickerView.width = view.width
        pickerView.height = 250
        
    }
    
    class func show(type: ProfileType, entity: SimpleUserEntity? = nil, saveSuccessClosure: (SimpleUserEntity -> Void)) {
        let controller = ProfileSheetViewController()
        controller.userEntity = entity
        controller.pickerView.userEntity = entity
        controller.pickerView.type = type
        controller.saveSuccessClosure = saveSuccessClosure
        
        controller.type = type
        controller.present()
    }

}
