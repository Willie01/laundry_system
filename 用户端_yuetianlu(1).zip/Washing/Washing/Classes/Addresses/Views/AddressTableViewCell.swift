//
//  AddressTableViewCell.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/3/21.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit

class AddressTableViewCell: UITableViewCell {

    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var addressLabel: UILabel!
    
    @IBOutlet weak var phoneLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func setData(model: AddressModel) {
        if let name = model.name {
            nameLabel.text = "姓名：\(name)"
        }
        addressLabel.text = model.address
        phoneLabel.text = model.telphone
    }
    
    func setOrderDate() {
        nameLabel.text = "请选择地址"
        addressLabel.text = ""
        phoneLabel.text = ""
    }
    
    func createOrderUI() {
        self.layer.borderWidth = 1
        self.layer.borderColor = UIColor(hex: 0x4285F4).CGColor
    }
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
