//
//  ProfilePickerView.swift
//  Client
//
//  Created by BJQXDN0527 on 2017/4/10.
//  Copyright © 2017年 36Kr. All rights reserved.
//

import UIKit

class ProfilePickerView: UIView, UIPickerViewDelegate, UIPickerViewDataSource {
    
    var type: ProfileType = .Profession {
        didSet {
            createData(type)
        }
    }
    var data: [String] = []
    var timeData: [NSArray] = []
    private var pickerView = UIPickerView()
    private var toolView = UIToolbar()
    var cancelClosure: (Void -> Void)?
    var saveClosure: ((String, SimpleUserEntity) -> Void)?
    var userEntity: SimpleUserEntity?
    private var currentYear: Int?
    private var currentMonth: Int?
    private var currentDay: Int?
    private var selectText: String?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(pickerView)
        addSubview(toolView)
        createUI()
    }
    
    private func createUI() {
        toolView.backgroundColor = UIColor.grayColor()
        let cancelButton = UIBarButtonItem(title: "取消", style: .Plain, target: self, action: #selector(cancelClick))
        let gapButton = UIBarButtonItem(barButtonSystemItem: .FlexibleSpace, target: nil, action: nil)
        let saveButton = UIBarButtonItem(title: "保存", style: .Plain, target: self, action: #selector(saveClick))
        toolView.setItems([cancelButton, gapButton, saveButton], animated: false)
        pickerView.delegate = self
        pickerView.dataSource = self
    }
    
    private func createData(type: ProfileType) {
        switch type {
        case .Birthday:
            date()
            if let birthday = userEntity?.birthday?.timeIntervalSince1970.normalTime {
                selectText = birthday
                var dates:[String] = birthday.componentsSeparatedByString("-")
                if let year = Int(dates[0]), let month = Int(dates[1]), let day = Int(dates[2]) {
                    pickerView.selectRow(year - 1900, inComponent: 0, animated: true)
                    pickerView.selectRow(month - 1, inComponent: 1, animated: true)
                    pickerView.selectRow(day - 1, inComponent: 2, animated: true)
                }
            } else {
                pickerView.selectRow(85, inComponent: 0, animated: true)
                pickerView.selectRow(5, inComponent: 1, animated: true)
                pickerView.selectRow(14, inComponent: 2, animated: true)
                selectText = "1985-6-15"
            }
        case .Profession:
            data = type.data()
            selectText = data[0]
            if let job = userEntity?.job {
                pickerView.selectRow(data.indexOf(job) ?? 0, inComponent: 0, animated: true)
                selectText = data[data.indexOf(job) ?? 0]
            } else {
                pickerView.reloadAllComponents()
            }
        case .Industry:
            data = type.data()
            selectText = data[0]
            if let industry = userEntity?.industry {
                pickerView.selectRow(data.indexOf(industry) ?? 0, inComponent: 0, animated: true)
                selectText = data[data.indexOf(industry) ?? 0]
            } else {
                pickerView.reloadAllComponents()
            }
        default:
            pickerView.reloadAllComponents()
        }
    }
    
    
    func cancelClick() {
        cancelClosure?()
    }
    
    func saveClick() {
        if var entity = userEntity {
            switch type {
            case .Birthday:
                let row = Int(pickerView.selectedRowInComponent(0))
                let nowYear = timeData[0][row] as? Int
                let nowMonth = pickerView.selectedRowInComponent(1) + 1
                let nowday = pickerView.selectedRowInComponent(2) + 1
                if let year = nowYear {
                    selectText = "\(year)-\(nowMonth)-\(nowday)"
                }
                let formatter = NSDateFormatter()
                formatter.dateFormat = Constants.dateFormat
                if let time = selectText {
                    entity.birthday = formatter.dateFromString("\(time) 14:00:00")
                }
            case .Profession:
                let row = Int(pickerView.selectedRowInComponent(0))
                selectText = data[row]
                entity.job = selectText
            case .Industry:
                let row = Int(pickerView.selectedRowInComponent(0))
                selectText = data[row]
                entity.industry = selectText
            default:
                return
            }
            print(selectText)
            if let text = selectText {
                saveClosure?(text, entity)
            }
        }
        
    }
    
    private func date() {
        let dateFormatter:NSDateFormatter = NSDateFormatter();
        dateFormatter.dateFormat = "yyyy/MM/dd";
        let dateString:String = dateFormatter.stringFromDate(NSDate());
        var dates:[String] = dateString.componentsSeparatedByString("/")
        if let year = Int(dates[0]), let month = Int(dates[1]), let day = Int(dates[2]) {
            currentYear = year
            currentMonth = month
            currentDay = day
        }
        if let year = Int(dates[0]) {
            var data: [Int] = []
            for  num in 1900..<year + 1  {
                data.append(num)
            }
            timeData.append(data)
            data.removeAll()
            for num in 1..<13 {
                data.append(num)
            }
            timeData.append(data)
            data.removeAll()
            for num in 1..<32 {
                data.append(num)
            }
            timeData.append(data)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        toolView.frame = CGRect(x: 0, y: 0, width: width, height: 44)
        pickerView.frame = CGRect(x: 0, y: 44, width: width, height: 206)
    }
}

extension ProfilePickerView {
    // MARK: UIPickerViewDelegate
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        switch type {
        case .Birthday:
            return 3
        default:
            return 1
        }
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        switch type {
        case .Birthday:
            if component == 0 {
                return timeData[0].count
            } else if component == 1 {
                return timeData[1].count
            } else {
                let row = Int(pickerView.selectedRowInComponent(0))
                let nowYear = timeData[0][row] as? Int
                let nowMonth = pickerView.selectedRowInComponent(1)
                switch nowMonth + 1 {
                case 1, 3, 5, 7, 8, 10, 12:
                    return 31
                case 4, 6, 9, 11:
                    return 30
                case 2:
                    if let year = nowYear {
                        if (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0) {
                            return 29
                        }
                        return 28
                    }
                    return 0
                default:
                    return 0
                }
            }
        default:
            return data.count
        }
    }
    
    func pickerView(pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusingView view: UIView?) -> UIView {
        let label = UILabel()
        label.textColor = UIColor(hex: 0x464C56)
        label.font = UIFont.systemFontOfSize(16.0)
        label.textAlignment = .Center
        switch type {
        case .Birthday:
            switch component {
            case 0:
                label.text = "\(timeData[component][row])年"
            case 1:
                label.text = "\(timeData[component][row])月"
            case 2:
                label.text = "\(timeData[component][row])日"
            default:
                label.text = ""
            }
        default:
            label.text = "\(data[row])"
        }
        return label
    }

    func pickerView(pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 30
    }
    
    func pickerView(pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat {
        if type == .Birthday {
            return 70
        }
        return width
    }
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        switch type {
        case .Birthday:
            let row = Int(pickerView.selectedRowInComponent(0))
            let nowYear = timeData[0][row] as? Int
            let nowMonth = pickerView.selectedRowInComponent(1) + 1
            let nowday = pickerView.selectedRowInComponent(2) + 1
            switch component {
            case 0, 1:
                pickerView.reloadComponent(2)
                pickerView.selectRow(0, inComponent: 2, animated: true)
                if let year = nowYear, let currentyear = currentYear, let currentmonth = currentMonth, let currentday = currentDay {
                    if year == currentyear && nowMonth > currentmonth {
                        pickerView.selectRow(currentmonth - 1, inComponent: 1, animated: true)
                        pickerView.selectRow(currentday - 1, inComponent: 2, animated: true)
                    }
                }
            case 2:
                if let year = nowYear, let currentyear = currentYear, let currentmonth = currentMonth, let currentday = currentDay {
                    if year == currentyear && nowMonth == currentmonth && nowday > currentday {
                        pickerView.selectRow(currentday - 1, inComponent: 2, animated: true)
                    }
                }
            default:
                return
            }
        default:
            selectText = data[row]
            print(data[row])
        }
    }

}
