//
//  AddressPickerView.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/4/18.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit
import UIKit

class AddressPickerView: UIView, UIPickerViewDelegate, UIPickerViewDataSource {
    
    var data: [String] = []
    var cityData: [NSDictionary] = []
    private var pickerView = UIPickerView()
    private var toolView = UIToolbar()
    var cancelClosure: (Void -> Void)?
    var saveClosure: ((String) -> Void)?
    private var selectText: String?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(pickerView)
        addSubview(toolView)
        createUI()
        createData()
    }
    
    private func createUI() {
        toolView.backgroundColor = UIColor.grayColor()
        let cancelButton = UIBarButtonItem(title: "取消", style: .Plain, target: self, action: #selector(cancelClick))
        let gapButton = UIBarButtonItem(barButtonSystemItem: .FlexibleSpace, target: nil, action: nil)
        let saveButton = UIBarButtonItem(title: "保存", style: .Plain, target: self, action: #selector(saveClick))
        toolView.setItems([cancelButton, gapButton, saveButton], animated: false)
        pickerView.delegate = self
        pickerView.dataSource = self
    }
    
    private func createData() {
        let path = NSBundle.mainBundle().pathForResource("provinces", ofType: "plist")
        if let path = path {
            let arr = NSArray(contentsOfFile: path)
            if let citys = arr {
                cityData = citys as! [NSDictionary]
            }
            print(cityData)
        }
    }
    
    
    func cancelClick() {
        cancelClosure?()
    }
    
    func saveClick() {
        let row = Int(pickerView.selectedRowInComponent(0))
        let area = Int(pickerView.selectedRowInComponent(1))
        let dic = cityData[row]
        let areas = dic.valueForKey("cities") as! [String]
        let cityStr = dic.valueForKey("name") as? String
        let areaStr = areas[area]
        if let city = cityStr {
            selectText = city + areaStr
        }
        if let text = selectText {
            saveClosure?(text)
        }
    }

    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        toolView.frame = CGRect(x: 0, y: 0, width: width, height: 44)
        pickerView.frame = CGRect(x: 0, y: 44, width: width, height: 206)
    }
}

extension AddressPickerView {
    
    // MARK: UIPickerViewDelegate
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == 0 {
            return cityData.count
        } else if component == 1 {
            let row = pickerView.selectedRowInComponent(0)
            let dic = cityData[row]
            let citys = dic.valueForKey("cities") as! [String]
            return citys.count
        }
        return 0
    }
    
    func pickerView(pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusingView view: UIView?) -> UIView {
        let label = UILabel()
        label.textColor = UIColor(hex: 0x464C56)
        label.font = UIFont.systemFontOfSize(16.0)
        label.textAlignment = .Center
        if component == 0 {
            let dic = cityData[row]
            label.text = dic.valueForKey("name") as? String
        } else if component == 1 {
            let cityrow = pickerView.selectedRowInComponent(0)
            let dic = cityData[cityrow]
            let citys = dic.valueForKey("cities") as! [String]
            label.text = citys[row]
        }
        return label
    }
    
    func pickerView(pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 30
    }
    
    func pickerView(pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat {

        return 70
    }
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        if component == 0 {
            pickerView.reloadComponent(1)
            pickerView.selectRow(0, inComponent: 1, animated: true)
        }
    }
    
}

