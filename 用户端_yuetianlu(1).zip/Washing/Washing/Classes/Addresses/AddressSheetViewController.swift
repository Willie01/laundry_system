//
//  AddressSheetViewController.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/4/18.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit
//AddressSheetViewController


class AddressSheetViewController: UIViewController, UIViewControllerTransitioningDelegate {
    
    let pickerView: AddressPickerView = {
        let view = AddressPickerView()
        view.backgroundColor = UIColor.whiteColor()
        return view
    }()
    private var saveSuccessClosure: (String -> Void)?
    //    private var userEntity: SimpleUserEntity?
    private var type: ProfileType?
    
    init() {
        super.init(nibName: nil, bundle: nil)
        transitioningDelegate = self
        modalPresentationStyle = .Custom
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func present(animated: Bool = true, completion: (() -> Void)? = nil) {
        UIViewController.topMostViewController()?.presentViewController(self, animated: animated, completion: completion)
    }
    
    // MARK: UIViewControllerTransitioningDelegate
    
    func presentationControllerForPresentedViewController(presented: UIViewController, presentingViewController presenting: UIViewController, sourceViewController source: UIViewController) -> UIPresentationController? {
        return PresentationController(presentedViewController: presented, presentingViewController: presenting)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(pickerView)
        pickerView.cancelClosure = {
            self.dismissViewControllerAnimated(true, completion: nil)
        }
        pickerView.saveClosure = { (city) in
            print(city)
            self.saveSuccessClosure?(city)
            self.dismissViewControllerAnimated(true, completion: nil)
        }
        // Do any additional setup after loading the view.
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        pickerView.left = 0
        pickerView.bottom = view.bottom
        pickerView.width = view.width
        pickerView.height = 250
        
    }
    
    class func show(saveSuccessClosure: (String -> Void)) {
        let controller = AddressSheetViewController()
        controller.saveSuccessClosure = saveSuccessClosure
        controller.present()
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
}

