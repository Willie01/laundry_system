//
//  EditAddressViewController.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/3/22.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit
import CoreLocation

class EditAddressViewController: UIViewController {

    @IBOutlet weak var nameTextField: UITextField!
    
    @IBOutlet weak var phoneTextField: UITextField!
    
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var addressView: UIView!
    
    @IBOutlet weak var areaTextField: UITextField!
    @IBOutlet weak var saveButton: UIButton!
    var data: AddressModel?
    var locationManager = CLLocationManager()
    var currLocation: CLLocation?
    @IBAction func segmentAction(sender: AnyObject) {
        
    }
    
    var addressId: Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "填写地址"
        addressLabel.userInteractionEnabled = true
        addressLabel.adjustsFontSizeToFitWidth = true
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(tap))
        addressLabel.addGestureRecognizer(tapGesture)
        loadLocation()
        createUI()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func saveAction(sender: AnyObject) {
        
        //更新
        if let address = addressLabel.text, let name = nameTextField.text, telephone = phoneTextField.text, let areaField = areaTextField.text {
            guard address.length > 0 && name.length > 0 && telephone.length > 0 && areaField.length > 0 else {
                HUD.show("以上选项不能为空")
                return
            }
            let addressStr = "\(address) \(areaField)"
            if let userId = UserInfo.sharedInstance.ID {
                let dic = ["address": addressStr, "name": name, "telphone": telephone, "user_id": userId]
                
                if let id = addressId {
                    HttpSwift.post("http://www.tchautchau.cn/api/update/user_addresses/\(id)", params: dic as! Dictionary<String, AnyObject>) { (data, response, error) in
                        if let data = data {
                            
                            let dic = data.stringToDic
                            if dic.valueForKey("status") as? String == "unprocessable_entity" {
                                HUD.show("保存失败")
                            } else {
                                dispatch_async(dispatch_get_main_queue(), {
                                    HUD.show("修改成功")
                                    self.navigationController?.popToRootViewControllerAnimated(true)
                                })
                            }
                            print(dic)
                        }
                    }
                } else {
                    //增加
                    HttpSwift.post("http://www.tchautchau.cn/api/user_addresses", params: dic as! Dictionary<String, AnyObject>) { (data, response, error) in
                        if let data = data {
                            
                            let dic = data.stringToDic
                            if dic.valueForKey("status") as? String == "unprocessable_entity" {
                                HUD.show("保存失败")
                            } else {
                                dispatch_async(dispatch_get_main_queue(), {
                                    HUD.show("添加成功")
                                    self.navigationController?.popToRootViewControllerAnimated(true)
                                })
                            }
                            print(dic)
                        }
                        
                    }
                    
                }}
        } else {
            HUD.show("以上选项不能为空")
        }
        
    }



    func createUI() {
        saveButton.backgroundColor = UIColor(hex: 0x4285F4)
        if let model = data {
            nameTextField.text = model.name
            phoneTextField.text = model.telphone
            if let address = model.address {
                let adds = address.componentsSeparatedByString(" ")
                addressLabel.text = adds[0]
                if adds.count == 2 {
                    areaTextField.text = adds[1]
                }
            }
        }
    }
    
    func tap() {
        AddressSheetViewController.show({city in
            self.addressLabel.text = city
        })
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        view.endEditing(true)
    }

}

extension EditAddressViewController: CLLocationManagerDelegate {
    //打开定位
    func loadLocation()
    {
        locationManager.delegate = self
        //定位方式
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        //始终允许访问位置信息
        locationManager.requestAlwaysAuthorization()
        //使用应用程序期间允许访问位置数据
        locationManager.requestWhenInUseAuthorization()
        //开启定位
        locationManager.startUpdatingLocation()
    }
    
    //获取定位信息
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        //取得locations数组的最后一个
        let location:CLLocation = locations[locations.count-1]
        currLocation = locations.last!
        //判断是否为空
        if(location.horizontalAccuracy > 0){
            let lat = Double(String(format: "%.1f", location.coordinate.latitude))
            let long = Double(String(format: "%.1f", location.coordinate.longitude))
            print("纬度:\(long!)")
            print("经度:\(lat!)")
            LonLatToCity()
            //停止定位
            locationManager.stopUpdatingLocation()
        }
    }
    
    //出现错误
    func locationManager(manager: CLLocationManager, didFinishDeferredUpdatesWithError error: NSError?) {
        print(error)
    }
    
    ///将经纬度转换为城市名
    func LonLatToCity() {
        let geocoder: CLGeocoder = CLGeocoder()
        geocoder.reverseGeocodeLocation(currLocation ?? CLLocation()) { (placemark, error) -> Void in
            
            if(error == nil) {
                let array = placemark! as NSArray
                let mark = array.firstObject as! CLPlacemark
                //城市
                let city: String = (mark.addressDictionary! as NSDictionary).valueForKey("City") as! String
                //国家
                let country: NSString = (mark.addressDictionary! as NSDictionary).valueForKey("Country") as! NSString
                //国家编码
                // let CountryCode: NSString = (mark.addressDictionary! as NSDictionary).valueForKey("CountryCode") as! NSString
                //街道位置
                let FormattedAddressLines: NSString = (mark.addressDictionary! as NSDictionary).valueForKey("FormattedAddressLines")?.firstObject as! NSString
                //具体位置
                let Name: NSString = (mark.addressDictionary! as NSDictionary).valueForKey("Name") as! NSString
                //省
                var State: String = (mark.addressDictionary! as NSDictionary).valueForKey("State") as! String
                //区
                let SubLocality: NSString = (mark.addressDictionary! as NSDictionary).valueForKey("SubLocality") as! NSString
                //如果需要去掉“市”和“省”字眼
                State = State.stringByReplacingOccurrencesOfString("省", withString: "")
                let citynameStr = city.stringByReplacingOccurrencesOfString("市", withString: "")
                print("\(city)+\(country)+\(Name)+\(State)+\(SubLocality)+（\(FormattedAddressLines)）")
                if let _ = self.data {
                    
                } else {
                    self.addressLabel.text = "\(State)\(SubLocality)"
                    self.areaTextField.text = "\(Name)"
                }
                
            } else {
                print(error)
            }
        }
    }
    
}

