//
//  AddressViewController.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/3/21.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit

class AddressViewController: BaseTableViewController {
    
    let Width = UIScreen.mainScreen().bounds.width
    private var data: [AddressModel] = []
    var didSelect: (AddressModel -> Void)?
    private var addLabel: UILabel = {
        let label = UILabel()
        label.text = "添加地址"
        label.textAlignment = .Center
        label.backgroundColor = UIColor.groupTableViewBackgroundColor()
        return label
    }()
    var type: String?
    
    deinit {
        
    }
    
    override func registerCell() {
        tableView.registerNib(UINib(nibName: "AddressTableViewCell", bundle: nil), forCellReuseIdentifier: "AddressTableViewCell")
    }
    
    override func refreshData() {
        print(UserInfo.sharedInstance.ID)
        if let id = UserInfo.sharedInstance.ID {
            print(id)
            HttpSwift.request("get", url: "http://www.tchautchau.cn/api/users/\(id)/user_addresses") { (data, response, error) in
                self.data.removeAll()
                print(data)
                if let data = data {
                    
                    let arr = data.stringToArr
                    for dic in arr {
                        let model = AddressModel(dict: dic as! [String : AnyObject])
                        self.data.append(model)
                    }
                    
                    dispatch_async(dispatch_get_main_queue(), {
                        self.tableView.reloadData()
                    })
                    print(arr)
                    
                }
            }
        }
    }
    
    override func loadMoreData() {
        
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        tableView.frame = CGRect(x: 0, y: 0, width: view.width, height: view.height-45)
        addLabel.frame = CGRect(x: 0, y: view.height - 45, width: Width, height: 45)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "常用地址"
        view.addSubview(addLabel)
        addLabel.userInteractionEnabled = true
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(tap))
        addLabel.addGestureRecognizer(tapGesture)
        // view.addSubview(tableView)
        // Do any additional setup after loading the view.
    }
    
    func tap() {
        print("aaa")
        let controller = EditAddressViewController()
        self.navigationController?.pushViewController(controller, animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

extension AddressViewController {
    
    // MARK: UITableViewDataSource
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 80
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("AddressTableViewCell", forIndexPath: indexPath) as! AddressTableViewCell
        let model = data[indexPath.row]
        cell.setData(model)
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        let model = data[indexPath.row]
        if let _ = type {
            self.didSelect?(model)
            self.navigationController?.popViewControllerAnimated(true)
            
        } else {

            let controller = EditAddressViewController()
            controller.data = model
            controller.addressId = model.id
            self.navigationController?.pushViewController(controller, animated: true)
        }
    }
    
    func tableView(tableView: UITableView, editingStyleForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCellEditingStyle {
        return UITableViewCellEditingStyle.Delete
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == UITableViewCellEditingStyle.Delete {
            let model = data[indexPath.row]
            HttpSwift.post("http://www.tchautchau.cn/api/delete/user_addresses/\(model.id)", callback: { (data, response, error) in
                dispatch_async(dispatch_get_main_queue(), {
                    HUD.show("删除成功")
                })
                self.refreshData()
            })
        }
    }
    
}
