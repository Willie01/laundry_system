//
//  HomePageModel.swift
//  yuetianlu
//
//  Created by yuetianlu on 16/11/29.
//  Copyright © 2016年 yuetianlu. All rights reserved.
//

import Foundation

class HomePageModel: NSObject {
    var id : Int = 0
    var category_id : Int = 0
    var category_name: String?
//    var status: String?
    var logo: String?
//    var isIMAX: Bool = true
//    var r: Double = 0.0
//    var wantedCount: Int64 = 0
//    var commonSpecial: String?
//    var NearestCinemaCount: Int64 = 0
//    var NearestShowtimeCount: Int64 = 0
//    var NearestDay: Int64 = 0
//    var cC: Int64 = 0
//    var movieType: String?
    
    init(dict : [String : AnyObject]) {
        super.init()
        
        //kvo赋值
        setValuesForKeysWithDictionary(dict)
        //setValuesForKeys(dict)

    }
    
    override func setValue(value: AnyObject?, forUndefinedKey key: String) {
        
    }
    
}
