//
//  Ho,ePageViewController.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/3/19.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit

class HomePageViewController: BaseViewController {

    private var collectionView: UICollectionView!
    private var layout = UICollectionViewFlowLayout()
    private var data: [HomePageModel] = []
    private var cityModel: CityModel?
    let leftButton: UIButton = {
        let button = UIButton()
        let textcolor = UIColor(hex: 0x26292F)
        button.setTitleColor(textcolor, forState: .Normal)
        button.titleLabel?.font = UIFont.systemFontOfSize(15)
        button.setTitle("北京", forState: .Normal)
        button.width = 60
        button.height = 35
        button.layer.borderWidth = 1
        button.layer.cornerRadius = 5
        button.layer.borderColor = UIColor(hex: 0x4285F4).CGColor
        return button
    }()
    
    override var emptyTip: String {
        return "暂无订单"
    }
    
    
    deinit {
        collectionView?.delegate = nil
        collectionView?.dataSource = nil
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let dic = NSUserDefaults.standardUserDefaults().valueForKey("userInfo") {
            userInfo(dic as! NSDictionary)
        }
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 0
        layout.scrollDirection = .Vertical
        collectionView = UICollectionView(frame: CGRect.zero, collectionViewLayout: layout)
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.pagingEnabled = false
        collectionView.scrollsToTop = false
        collectionView.backgroundColor = UIColor.whiteColor()
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.registerNib(UINib(nibName: "HomeCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "HomeCollectionViewCell")
        collectionView.registerClass(HomeHeaderCollectionViewCell.self, forCellWithReuseIdentifier: "HomeHeaderCollectionViewCell")
        layout.itemSize = CGSize(width: UIScreen.mainScreen().bounds.width/3 , height: 100)
        collectionView.frame = CGRectMake(0, 0, Constants.Layout.screenWidth, Constants.Layout.screenHeight-64-49)
        view.addSubview(collectionView)
        get()
        let formatter = NSDateFormatter()
        formatter.dateFormat = Constants.dateFormat
        let date = NSDate().nextSevenDay
        print(formatter.stringFromDate(date))
        let leftItem = UIBarButtonItem(customView: leftButton)
        navigationItem.leftBarButtonItem = leftItem
        leftButton.addTarget(self, action: #selector(self.managerTagAction), forControlEvents: .TouchUpInside)
        // Do any additional setup after loading the view.
    }
    
    func managerTagAction() {
        let controller = CityViewController()
        controller.selectFinishClosure = { model in
            self.cityModel = model
            self.get()
        }
        self.navigationController?.pushViewController(controller, animated: true)
    }
    
    func get() {

        var cityId = 1
        if let city = cityModel {
            cityId = city.id
            leftButton.setTitle(city.city_name, forState: .Normal)
        }
        HttpSwift.request("get", url: "http://www.tchautchau.cn/api/cities/\(cityId)/categories_cities") { (data, response, error) in
            print(data)
            if let data = data {
                
                let arr = data.stringToArr
                self.data.removeAll()
                for dic in arr {
                    let model = HomePageModel(dict: dic as! [String : AnyObject])
                    self.data.append(model)
                }

                dispatch_async(dispatch_get_main_queue(), { 
                  self.collectionView.reloadData()  
                })
               // self.collectionView.reloadData()
                print(arr)
                
            }
        }

    }

}
//                let headerIndexPath = NSIndexPath(forItem: 0, inSection: 0)
//                self.collectionView.reloadItemsAtIndexPaths([headerIndexPath])

extension HomePageViewController: UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return 2
    }
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        } else {
            return data.count
        }
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        if indexPath.section == 0 {
            let cell = collectionView.dequeueReusableCellWithReuseIdentifier("HomeHeaderCollectionViewCell", forIndexPath: indexPath) as! HomeHeaderCollectionViewCell
            cell.didClickButton = { index in
                print(index)
                
            }
            return cell
        } else {
            let cell = collectionView.dequeueReusableCellWithReuseIdentifier("HomeCollectionViewCell", forIndexPath: indexPath) as! HomeCollectionViewCell
            let model = data[indexPath.row]
            cell.setData(model)
            return cell
        }
        
    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        let model = data[indexPath.row]
        let controller = GoodsViewController()
        controller.cateId = model.category_id
        controller.categoryData = data
        if let city = cityModel {
            controller.cityID = city.id
        }
        self.navigationController?.pushViewController(controller, animated: true)
    }
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
        if indexPath.section == 0 {
            return CGSize(width: Constants.Layout.screenWidth, height: 200)
        } else {
        return CGSize(width: (Constants.Layout.screenWidth-60)/3, height: 150 )
        }
        
    }
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAtIndex section: Int) -> CGFloat {
        if section == 0 {
            return 0
        }
        return 10
    }
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAtIndex section: Int) -> UIEdgeInsets {
        if section == 0 {
            return UIEdgeInsetsMake(0, 0, 0, 0)
        }
        return UIEdgeInsetsMake(10, 15, 10, 15)
    }
    
}


