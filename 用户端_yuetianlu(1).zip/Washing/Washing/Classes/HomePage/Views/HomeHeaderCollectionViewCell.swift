//
//  HomeHeaderCollectionViewCell.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/4/8.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit

class HomeHeaderCollectionViewCell: UICollectionViewCell, WQBannerViewDelegate {
    var bannerView: WQBannerView?
    var didClickButton: (Int -> Void)?
    override init(frame: CGRect) {
        super.init(frame: frame)
        let dataArray: NSMutableArray = NSMutableArray.init(capacity: 0)
        var dic = NSDictionary.init(objects: ["http://www.tchautchau.cn/images/test1.jpg","12"], forKeys: ["image_url","image_id"], count: 2)
        
        
        dataArray.addObject(dic)
        
        dic = NSDictionary.init(objects: ["http://www.tchautchau.cn/images/test2.jpg","13"], forKeys: ["image_url","image_id"],count: 2)
        dataArray.addObject(dic)
        
        dic = NSDictionary.init(objects: ["http://www.tchautchau.cn/images/test3.jpg","14"], forKeys: ["image_url","image_id"],count: 2)
        
        dataArray.addObject(dic)
        print(dataArray)
        
        
        if (self.bannerView != nil) {
            self.bannerView?.reloadBannerWithData(dataArray)
        }
        else {
            self.bannerView = WQBannerView.init(frame: CGRectMake(0, 0, UIScreen.mainScreen().bounds.width, 180), direction: BannerViewScrollDirection.ScrollDirectionLandscape, images: dataArray)
            self.bannerView?.backgroundColor = UIColor.whiteColor()
            self.bannerView!.rollingDelayTime = 4.0
            self.bannerView!.delegate = self
            self.bannerView?.defaultpageColor = UIColor.grayColor()
            self.bannerView?.selectpageColor = UIColor.redColor()
            self.bannerView?.imageKey = "image_url"
            self.bannerView?.imageId = "image_id"
            self.bannerView?.setSquare(0)
            self.bannerView!.setPageControlStyle(BannerViewPageStyle.PageStyle_Middle)
            self.bannerView!.startDownloadImage()
            self.bannerView?.showClose(false)
        }
        self.addSubview(bannerView!)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}

extension HomeHeaderCollectionViewCell {
    
    func imageCachedDidFinish(bannerView: WQBannerView) {
        
        print("frame = %@",bannerView.frame)
        if bannerView == self.bannerView {
            if self.bannerView!.superview == nil {
                self.addSubview(self.bannerView!)
            }
            self.bannerView!.startRolling()
        }
        else {
            self.addSubview(bannerView)
            bannerView.startRolling()
        }
        
        
    }
    
    func bannerView_didSelectImageView_withData(bannerView: WQBannerView, index: NSInteger, bannerData: String, imageid: String) {
        
        print("\(index)+\(bannerData)+\(imageid)")
        didClickButton?(index)
    }
    
    func bannerViewdidClosed(bannerView: WQBannerView) {
        
        if ((bannerView.superview) != nil)
        {
            bannerView.removeFromSuperview()
        }
        
    }
    
}
