//
//  HomeCollectionViewCell.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/3/19.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit

class HomeCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var bgImageView: UIImageView!
    
    @IBOutlet weak var titleLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        self.layer.borderColor = UIColor(hex: "#C4CEDA").CGColor
        self.layer.borderWidth = 1
        // Initialization code
    }
    
    func setData(model: HomePageModel) {
        titleLabel.text = model.category_name
        if let logo = model.logo {
            print("http://www.tchautchau.cn/\(logo)")
            bgImageView.setImageWithURL(NSURL(string: "http://www.tchautchau.cn/\(logo)"), placeholderImage: nil)
        }
    }

}
