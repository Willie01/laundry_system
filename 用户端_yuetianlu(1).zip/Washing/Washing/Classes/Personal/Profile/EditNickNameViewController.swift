//
//  EditNickNameViewController.swift
//  Client
//
//  Created by paul on 16/8/22.
//  Copyright © 2016年 36Kr. All rights reserved.
//

import UIKit


final class EditNickNameViewController: UIViewController, URLNavigable {

    private var textField: UITextField = {
        let textField = UITextField(frame: CGRect.zero)
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.textAlignment = NSTextAlignment.Center
        return textField
    }()
    
    private var separator: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor(hex: 0xC3CED9)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    init?(URL: URLConvertible, values: [String : AnyObject]) {
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private var saveButton: UIButton!
    private var cancelButton: UIButton!
    
    private var oldName = ""
    private var didEdit = false
    private var rightBarButtonItem: UIBarButtonItem!
    
    private var observerToken: AnyObject?
    
    deinit {
        if let observerToken = observerToken {
            NSNotificationCenter.defaultCenter().removeObserver(observerToken)
        }
        observerToken = nil
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "昵称"
        view.backgroundColor = UIColor.whiteColor()
        view.addSubview(separator)
        view.addSubview(textField)
        
        for constraint in ["H:|-40-[textField]-40-|", "H:|-40-[separator]-40-|", "V:|-40-[textField(50)]-0-[separator(onePixel)]"] {
            view.addConstraints(NSLayoutConstraint.constraintsWithVisualFormat(constraint, options: NSLayoutFormatOptions.DirectionLeadingToTrailing, metrics: ["onePixel" : Constants.Layout.onePixel], views: ["textField" : textField, "separator" : separator]))
        }
        let clearButton = UIButton(type: UIButtonType.System)
        clearButton.setImage(UIImage(named: "ic_common_close")?.imageWithRenderingMode(UIImageRenderingMode.AlwaysTemplate), forState: UIControlState.Normal)
        clearButton.tintColor = UIColor(hex: 0x464C56)
        clearButton.setTitle("", forState: UIControlState.Normal)
        clearButton.sizeToFit()
        clearButton.addTarget(self, action: #selector(clearAction), forControlEvents: UIControlEvents.TouchUpInside)
        textField.rightViewMode = .WhileEditing
        textField.rightView = clearButton
        
        cancelButton = UIButton(type: UIButtonType.System)
        cancelButton.setTitle("取消", forState: UIControlState.Normal)
        cancelButton.addTarget(self, action: #selector(cancelAction), forControlEvents: UIControlEvents.TouchUpInside)
        cancelButton.setTitleColor(UIColor(hex: 0x262A2F), forState: UIControlState.Normal)
        cancelButton.titleLabel?.font = UIFont.systemFontOfSize(16.0)
        cancelButton.sizeToFit()
        
        saveButton = UIButton(type: UIButtonType.System)
        saveButton.setTitle("保存", forState: UIControlState.Normal)
        saveButton.addTarget(self, action: #selector(saveAction), forControlEvents: UIControlEvents.TouchUpInside)
        saveButton.setTitleColor(UIColor(hex: 0x262A2F), forState: UIControlState.Normal)
        saveButton.setTitleColor(UIColor(hex: 0x969FA9), forState: UIControlState.Disabled)
        saveButton.titleLabel?.font = UIFont.systemFontOfSize(16.0)
        saveButton.sizeToFit()

        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: cancelButton)
        rightBarButtonItem = UIBarButtonItem(customView: saveButton)
        navigationItem.rightBarButtonItem = rightBarButtonItem
        rightBarButtonItem.enabled = false
        
        UserManager.manager.getUserInfo { (entity) in
            self.textField.text = entity?.nickName
            self.oldName = entity?.nickName ?? ""
        }
        observerToken = NSNotificationCenter.defaultCenter().addObserverForName(UITextFieldTextDidChangeNotification, object: nil, queue: NSOperationQueue.mainQueue()) { [weak self] (notification) in
            guard (notification.object as? UITextField) == self?.textField else {
                return
            }
            self?.didEdit = true
            self?.rightBarButtonItem.enabled = self?.textField.text?.characters.count > 0
        }
    }
    
    // MARK: Action
    
    func clearAction() {
        textField.text = ""
    }
    
    func cancelAction() {
        if didEdit {
            alert("确定放弃此次编辑？", style: .System, actions: [AlertAction(title: "取消", style: .Cancel), AlertAction(title: "确定", style: .Confirm)]) { (buttonIndex) in
                if buttonIndex == 1 {
                    self.navigationController?.popViewControllerAnimated(true)
                }
            }
        } else {
            navigationController?.popViewControllerAnimated(true)
        }
    }
    
    func saveAction() {
        guard textField.text?.characters.count > 0 else {
            HUD.showError("昵称不可为空")
            return
        }
        UserManager.manager.updateUserNickName(textField.text) { success, errorMessage in
            if success {
                UserManager.manager.getUserInfoFromNetwork({ (_) in
                    HUD.showSuccess("已修改")
                    self.navigationController?.popToRootViewControllerAnimated(true)
                })
            } else {
                if let message = errorMessage {
                    HUD.show(message)
                } else {
                    HUD.showError("修改失败")
                }
            }
        }
    }
    
}
