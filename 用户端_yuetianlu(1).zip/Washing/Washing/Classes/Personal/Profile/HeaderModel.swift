//
//  HeaderModel.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/5/20.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import Foundation

class HeaderModel: NSObject {
    
    var id : Int = 1
    var portrait: String?
    
    init(dict : [String : AnyObject]) {
        super.init()
        
        //kvo赋值
        setValuesForKeysWithDictionary(dict)
        //setValuesForKeys(dict)
        
    }
    
    override func setValue(value: AnyObject?, forUndefinedKey key: String) {
        
    }
    
}