//
//  MyProfileViewController.swift
//  Client
//
//  Created by paul on 16/8/22.
//  Copyright © 2016年 36Kr. All rights reserved.
//

import UIKit


class MyProfileViewController: BaseViewController,UITableViewDelegate, UITableViewDataSource {
    
    var imagePickerController: UIImagePickerController = {
        let imagePickerController = UIImagePickerController()
        imagePickerController.allowsEditing = UI_USER_INTERFACE_IDIOM() != UIUserInterfaceIdiom.Pad
        return imagePickerController
    }()
    private let sections:[[ProfileType]] = [[.NickName, .SexRole, .Birthday],[.Profession, .Industry]]
    private let headerView = ProfileHeaderView.instance()
    private let footerView = ProfileFooterView.instance()
    private var tableView: UITableView = {
        let view = UITableView(frame: CGRect.zero, style: UITableViewStyle.Grouped)
        view.separatorStyle = .SingleLine
        view.separatorColor = UIColor(hex: 0xf0f0f0)
        view.separatorInset = UIEdgeInsetsMake(0, 20, 0, 20)
        view.backgroundColor = UIColor.whiteColor()
        view.separatorStyle = .None
        return view
    }()
    
    deinit {
        tableView.delegate = nil
        tableView.dataSource = nil
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "我的资料"
        imagePickerController.delegate = self
        tableView.delegate = self
        tableView.dataSource = self
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.estimatedRowHeight = 60
        tableView.frame = CGRect(x: 0, y: 0, width: view.width, height: view.height - 64)
        headerView.frame = CGRect(x: 0, y: 0, width: view.width, height: 185)
        footerView.frame = CGRect(x: 0, y: 0, width: view.width, height: 155)
        tableView.tableHeaderView = headerView
        tableView.tableFooterView = footerView
        tableView.registerNib(UINib(nibName: "ProfileTableViewCell", bundle: nil), forCellReuseIdentifier: "ProfileTableViewCell")
        view.addSubview(tableView)
        if let url = UserInfo.sharedInstance.portrait {
            headerView.avatarImageView.setImageWithURL(NSURL(string: "http://www.tchautchau.cn/\(url)"), placeholderImage: UIImage(named: "ic_mine_avatar"))
        }
        headerView.didClickPhoto = {
            self.editAvatarAction()
        }
        //createData()
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        if let id = UserInfo.sharedInstance.ID {
            HttpSwift.request("get", url: "http://www.tchautchau.cn/api/portraits/\(id)") { (data, response, error) in
                print(data)
                if let dic = data?.stringToDic {
                    let model = HeaderModel(dict: dic as! [String : AnyObject])
                    dispatch_async(dispatch_get_main_queue(), {
                        if let logo = model.portrait {
                            self.headerView.avatarImageView.setImageWithURL(NSURL(string: "http://www.tchautchau.cn/\(logo)"), placeholderImage: UIImage(named: "ic_mine_avatar"))
                        }
                    })
                }
            }
        }
    }
    
    private func editAvatarAction() {
        let controller = HeaderImageViewController()
        navigationController?.pushViewController(controller, animated: true)
//        let alertController = UIAlertController(title: nil , message: nil, preferredStyle: .ActionSheet)
//        alertController.addAction(UIAlertAction(title: "从图库选取", style: UIAlertActionStyle.Default, handler: { (_) in
//            self.imagePickerController.sourceType = .PhotoLibrary
//            self.presentViewController(self.imagePickerController, animated: true, completion: nil)
//        }))
//        alertController.addAction(UIAlertAction(title: "拍照", style: UIAlertActionStyle.Default, handler: { (_) in
//            if UIImagePickerController.isSourceTypeAvailable(.Camera) {
//                self.imagePickerController.sourceType = .Camera
//                self.presentViewController(self.imagePickerController, animated: true, completion: nil)
//            } else {
//                HUD.showError("当前设备不支持拍照")
//            }
//        }))
//        alertController.addAction(UIAlertAction(title: "取消", style: UIAlertActionStyle.Cancel, handler: { (_) in
//            
//        }))
//        presentViewController(alertController, animated: true, completion: nil)
    }
    
    private func editSex() {
        let alertController = UIAlertController(title: nil , message: nil, preferredStyle: .ActionSheet)
        alertController.addAction(UIAlertAction(title: "男", style: UIAlertActionStyle.Default, handler: { (_) in
            self.updateSex("male")
        }))
        alertController.addAction(UIAlertAction(title: "女", style: UIAlertActionStyle.Default, handler: { (_) in
            self.updateSex("female")
        }))
        alertController.addAction(UIAlertAction(title: "取消", style: UIAlertActionStyle.Cancel, handler: { (_) in
            
        }))
        
        presentViewController(alertController, animated: true, completion: nil)
    }
    
    func editNameAction() {
        
    }
    
    private func updateSex(sex: String) {
//        if let uid = self.userEntity?.ID {
//            UserManager.manager.updateUserProfile(sex, uid: uid, type: ProfileType.SexRole, completion: { (status, message) in
//                if status == true {
//                    HUD.showSuccess("保存成功")
//                    self.userProfileEntity?.sex = sex
//                    self.tableView.reloadData()
//                    self.updateFooterView()
//                    
//                } else {
//                    if let message = message {
//                        HUD.showError(message)
//                    } else {
//                        HUD.showError("保存失败，请重新提交")
//                    }
//                }
//            })
//        }
    }
    
//    private func updateFooterView() {
//        var percent: Float = 0
//        if let _ = userEntity?.avatar {
//            percent += 1
//        }
//        if let _ = userEntity?.nickName {
//            percent += 1
//        }
//        if let _ = userProfileEntity?.sex {
//            percent += 1
//        }
//        if let _ = userProfileEntity?.birthday {
//            percent += 1
//        }
//        if let _ = userProfileEntity?.job {
//            percent += 1
//        }
//        if let _ = userProfileEntity?.industry {
//            percent += 1
//        }
//        print(percent)
//        if percent == 6 {
//            footerView.wholeEdit(true, percent: 1)
//        } else {
//            footerView.wholeEdit(false, percent: percent/6.0)
//        }
//    }
    
}


extension MyProfileViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        var validImage: UIImage?
        if let image = info[UIImagePickerControllerEditedImage] as? UIImage {
            validImage = image
        } else if let image = info[UIImagePickerControllerOriginalImage] as? UIImage {
            validImage = image
        }
        guard let image = validImage else {
            HUD.showError("获取头像失败")
            picker.dismissViewControllerAnimated(true, completion: nil)
            return
        }
                    picker.dismissViewControllerAnimated(true, completion: { [weak self] in
                        self?.headerView.avatarImageView.image = image
                        //self?.navigationController?.popViewControllerAnimated(true)
                        })
        HUD.show("设置中")
//        UserManager.manager.updateAvatarWithImage(image, successClosure: { (_) in
//            self.headerView.avatarImageView.image = image
//            HUD.showSuccess("头像更新成功")
//            picker.dismissViewControllerAnimated(true, completion: { [weak self] in
//                self?.navigationController?.popViewControllerAnimated(true)
//                })
//            }, failureClosure: { (message) in
//                HUD.showError("头像更新失败")
//                picker.dismissViewControllerAnimated(true, completion: { [weak self] in
//                    self?.navigationController?.popViewControllerAnimated(true)
//                    })
//        })
    }

}

extension MyProfileViewController {
    
    // MARK: UITableViewDataSource
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return sections.count
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sections[section].count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("ProfileTableViewCell", forIndexPath: indexPath) as! ProfileTableViewCell
        if let type = rowTypeForIndexPath(indexPath) {
            cell.setData(type)
        }
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        if let type = rowTypeForIndexPath(indexPath) {
            switch type {
            case .NickName:
                editNameAction()
            case .SexRole:
                editSex()
            case .Birthday, .Profession, .Industry:
                return ProfileSheetViewController.show(type, saveSuccessClosure: {
                    self.tableView.reloadData()
                })
            }
        }
    }
    
    private func rowTypeForIndexPath(indexPath: NSIndexPath) -> ProfileType? {
        guard indexPath.section < sections.count else {
            return nil
        }
        guard indexPath.row < sections[indexPath.section].count else {
            return nil
        }
        return sections[indexPath.section][indexPath.row]
    }
    
    private func indexPathForRowType(rowType: ProfileType) -> NSIndexPath? {
        for (sectionIndex, section) in sections.enumerate() {
            for (rowIndex, row) in section.enumerate() {
                guard row == rowType else {
                    continue
                }
                return NSIndexPath(forRow: rowIndex, inSection: sectionIndex)
            }
        }
        return nil
    }
    
}