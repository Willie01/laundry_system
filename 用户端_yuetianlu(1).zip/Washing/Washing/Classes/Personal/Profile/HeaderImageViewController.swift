//
//  HeaderImageViewController.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/5/20.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit

class HeaderImageViewController: UIViewController {

    private var collectionView: UICollectionView!
    private var layout = UICollectionViewFlowLayout()
    private var data: [HeaderModel] = []
    
    deinit {
        collectionView?.delegate = nil
        collectionView?.dataSource = nil
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        title = "选择头像"
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 0
        layout.scrollDirection = .Vertical
        collectionView = UICollectionView(frame: CGRect.zero, collectionViewLayout: layout)
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.pagingEnabled = false
        collectionView.scrollsToTop = false
        collectionView.backgroundColor = UIColor.whiteColor()
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.registerNib(UINib(nibName: "HeaderCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "HeaderCollectionViewCell")
        layout.itemSize = CGSize(width: UIScreen.mainScreen().bounds.width/3 , height: 100)
        collectionView.frame = CGRectMake(0, 0, Constants.Layout.screenWidth, Constants.Layout.screenHeight-64-49)
        view.addSubview(collectionView)

        get()
        // Do any additional setup after loading the view.
    }
    
    func get() {

        HttpSwift.request("get", url: "http://www.tchautchau.cn/api/portraits") { (data, response, error) in
            print(data)
            if let data = data {
                let arr = data.stringToArr
                self.data.removeAll()
                for dic in arr {
                    let model = HeaderModel(dict: dic as! [String : AnyObject])
                    self.data.append(model)
                }
                
                dispatch_async(dispatch_get_main_queue(), {
                    self.collectionView.reloadData()
                })
                // self.collectionView.reloadData()
                print(arr)
                
            }
        }
        
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}

extension HeaderImageViewController: UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return data.count
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("HeaderCollectionViewCell", forIndexPath: indexPath) as! HeaderCollectionViewCell
        let model = data[indexPath.row]
        cell.setData(model)
        return cell
        
    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        let model = data[indexPath.row]
        if let userId = UserInfo.sharedInstance.ID, let image = model.portrait {
            let dic = ["portrait": image]
            HttpSwift.post("http://www.tchautchau.cn/api/update/portraits/\(userId)", params: dic ) { (data, response, error) in
                if let data = data {
                    let dic = data.stringToDic
                    if dic.valueForKey("status") as? String == "unprocessable_entity" {
                        HUD.show("保存失败")
                    } else {
                        dispatch_async(dispatch_get_main_queue(), {
                            HUD.show("更新成功")
                            self.navigationController?.popViewControllerAnimated(true)
                        })
                    }
                    print(dic)
                }
            }
        }
    }
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
        
        return CGSize(width: (Constants.Layout.screenWidth-60)/3, height: (Constants.Layout.screenWidth-60)/3 )
    }
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAtIndex section: Int) -> CGFloat {
        return 10
    }
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAtIndex section: Int) -> UIEdgeInsets {
        return UIEdgeInsetsMake(10, 10, 10, 10)
    }
    
}

