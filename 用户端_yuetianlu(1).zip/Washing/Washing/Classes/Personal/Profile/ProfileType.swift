//
//  ProfileType.swift
//  Client
//
//  Created by BJQXDN0527 on 2017/4/10.
//  Copyright © 2017年 36Kr. All rights reserved.
//

import Foundation

enum ProfileType {
    case NickName // 昵称
    case SexRole // 性别
    case Birthday // 生日
    case Profession // 职业
    case Industry // 行业
    
    func title() -> String {
        switch self {
        case .NickName:
            return "昵称"
        case .SexRole:
            return "性别"
        case .Birthday:
            return "生日"
        case .Profession:
            return "职业"
        case .Industry:
            return "行业"
        }
    }
    
    func data() -> [String] {
        switch self {
        case .Profession:
            return ["学生", "白领", "中层管理者", "企业老板", "创业者", "投资人", "自由职业者", "其他"]
        case .Industry:
            return ["互联网", "IT", "制造业", "金融", "教育", "医疗医药", "建筑房地产", "传媒", "政府机关", "其他"]
        default:
            return []
        }
    }
}