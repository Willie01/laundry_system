//
//  ProfileTableViewCell.swift
//  Client
//
//  Created by BJQXDN0527 on 2017/4/10.
//  Copyright © 2017年 36Kr. All rights reserved.
//

import UIKit

class ProfileTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var profileLabel: UILabel!
    
    
    @IBOutlet weak var lineView: UIView! {
        didSet {
            lineView.backgroundColor = UIColor(hex: 0xf0f0f0)
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        createUI()
    }
    
    private func createUI() {
        titleLabel.textColor = UIColor(hex: 0x464C56)
        titleLabel.font = UIFont.systemFontOfSize(16.0, weight: UIFontWeightMedium)
        profileLabel.textColor = UIColor(hex: 0x464C56)
        profileLabel.font = UIFont.systemFontOfSize(16.0)
    }
    
    func setData(type: ProfileType) {
        titleLabel.text = type.title()
        profileLabel.text = "请选择"
        switch type {
        case .NickName:
            profileLabel.text = "aaa"
            if let name = UserInfo.sharedInstance.Name {
                profileLabel.text = name
            }
        case .SexRole:
            profileLabel.text = "男"
        case .Birthday:
            
            profileLabel.text = "1993-08-23"
            
        case .Profession:
            profileLabel.text = "学生"
            
        case .Industry:
            profileLabel.text = "互联网"
            
        }
        if profileLabel.text == "请选择" {
            profileLabel.textColor = UIColor(hex: 0x969FA9)
        } else {
            profileLabel.textColor = UIColor(hex: 0x464C56)
        }
        
        
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
