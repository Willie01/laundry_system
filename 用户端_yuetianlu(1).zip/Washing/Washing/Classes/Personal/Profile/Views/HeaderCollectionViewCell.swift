//
//  HeaderCollectionViewCell.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/5/20.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit

class HeaderCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var headerImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        headerImageView.cornerRaduis = ((Constants.Layout.screenWidth-60)/3 - 10)/2
        headerImageView.userInteractionEnabled = true
//        self.layer.borderColor = UIColor(hex: "#C4CEDA").CGColor
//        self.layer.borderWidth = 1
        // Initialization code
    }
    
    func setData(model: HeaderModel) {
//        titleLabel.text = model.category_name
        if let logo = model.portrait {
            headerImageView.setImageWithURL(NSURL(string: "http://www.tchautchau.cn/\(logo)"), placeholderImage: nil)
        }
    }

}
