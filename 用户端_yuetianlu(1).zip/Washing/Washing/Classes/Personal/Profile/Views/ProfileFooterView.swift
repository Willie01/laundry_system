//
//  ProfileFooterView.swift
//  Client
//
//  Created by BJQXDN0527 on 2017/4/10.
//  Copyright © 2017年 36Kr. All rights reserved.
//

import UIKit

class ProfileFooterView: UIView {
   
    var percentLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.whiteColor()
        label.font = UIFont.systemFontOfSize(14.0)
        label.textAlignment = .Center
        return label
    }()
    
    var bgView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.groupTableViewBackgroundColor()
        view.height = 6
        view.layer.cornerRadius = 3
        return view
    }()
    
    var paddingView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor(hex: 0x4285F4)
        view.height = 6
        view.layer.cornerRadius = 3
        return view
    }()
    
    var bgImageView: UIImageView = {
        let imageView = UIImageView()
        return imageView
    }()
    
    var descriptionLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor(hex: 0x969FA9)
        label.font = UIFont.systemFontOfSize(14.0)
        label.textAlignment = .Center
        label.numberOfLines = 0
        return label
    }()
    private let inset: CGFloat = 40
    private var paddingWidth: CGFloat = 0
    
    class func instance() -> ProfileFooterView {
        let view = ProfileFooterView(frame: CGRect.zero)
        return view
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.whiteColor()
        addSubview(bgImageView)
        bgImageView.addSubview(percentLabel)
        addSubview(bgView)
        bgView.addSubview(paddingView)
        addSubview(descriptionLabel)
        
    }
    
    func wholeEdit(editAll: Bool, percent: Float) {
        if editAll == true {
            descriptionLabel.text = "为你点36个赞！"
            descriptionLabel.sizeToFit()
            descriptionLabel.center.x = width / 2
            paddingWidth = width - 40
            paddingView.width = paddingWidth
            bgImageView.image = UIImage(named: "bubble_progress_2")
            bgImageView.frame = CGRect(x: width - 105, y: 40, width: 85, height: 31)
            percentLabel.text = "已完成100%"
        } else {
            descriptionLabel.text = "完善您的资料，我们将为您提供更贴心的服务"
            descriptionLabel.sizeToFit()
            descriptionLabel.center.x = width / 2
            paddingWidth = (width - 40) * CGFloat(percent)
            paddingView.width = paddingWidth
            bgImageView.center.x = paddingWidth + 20
            bgImageView.image = UIImage(named: "bubble_progress_1")
            percentLabel.text = "已完成\(lroundf(percent * 100))%"
        }
        layoutIfNeeded()
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        bgImageView.top = 40
        bgImageView.width = 85
        bgImageView.height = 31
        percentLabel.frame = CGRect(x: 0, y: 0, width: 85, height: 25)
        bgView.frame = CGRect(x: 20, y: bgImageView.frame.maxY + 5, width: width - 40, height: 6)
        paddingView.left = 0
        paddingView.top = 0
        paddingView.height = 6
        descriptionLabel.top = bgView.frame.maxY + 10
    }
}
