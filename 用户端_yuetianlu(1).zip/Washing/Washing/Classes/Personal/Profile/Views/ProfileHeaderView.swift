//
//  ProfileHeaderView.swift
//  Client
//
//  Created by BJQXDN0527 on 2017/4/10.
//  Copyright © 2017年 36Kr. All rights reserved.
//

import UIKit

class ProfileHeaderView: UIView {

    var avatarImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.userInteractionEnabled = true
        imageView.contentMode = .ScaleAspectFill
        imageView.transformToCycle(50.0)
        imageView.image = UIImage(named: "ic_mine_avatar")
        return imageView
    }()
    
    let cameraImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.userInteractionEnabled = true
        return imageView
    }()
    
    var didClickPhoto: (Void -> Void)?
    
    class func instance() -> ProfileHeaderView {
        let view = ProfileHeaderView(frame: CGRect.zero)
        return view
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.whiteColor()
        addSubview(avatarImageView)
        addSubview(cameraImageView)
        cameraImageView.image = UIImage(named: "ic_mine_camera")
        let avatarTapGesture = UITapGestureRecognizer(target: self, action: #selector(editAvatarAction))
        avatarImageView.addGestureRecognizer(avatarTapGesture)
    }
    
    func editAvatarAction() {
        didClickPhoto?()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        avatarImageView.top = 40
        avatarImageView.width = 100
        avatarImageView.height = 100
        avatarImageView.center.x = width/2
        cameraImageView.width = 32
        cameraImageView.height = 32
        cameraImageView.right = avatarImageView.right
        cameraImageView.bottom = avatarImageView.bottom
    }
}
