//
//  PurchaseRecordTableViewCell.swift
//  Client
//
//  Created by BJQXDN0527 on 2017/2/24.
//  Copyright © 2017年 36Kr. All rights reserved.
//

import UIKit

class PurchaseRecordTableViewCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!

    @IBOutlet weak var priceLabel: UILabel!
    
    @IBOutlet weak var dateLabel: UILabel!
    
    @IBOutlet weak var discountInfoLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        createUI()
    }

    private func createUI() {
        titleLabel.textColor = UIColor(hex: "#464C56")
        titleLabel.font = UIFont.systemFontOfSize(15)
        dateLabel.font = UIFont.systemFontOfSize(12)
        dateLabel.textColor = UIColor(hex: "#969FA9")
        priceLabel.font = UIFont.boldSystemFontOfSize(15)
        priceLabel.textColor = UIColor(hex: "#26292F")
        discountInfoLabel.textColor = UIColor(hex: "#969FA9")
        discountInfoLabel.font = UIFont.systemFontOfSize(12)
    }
    
//    func setData(type: RecordType?, data: PurchaseEntity) {
//        guard let type = type else {
//            return
//        }
//        switch type {
//        case .Exchange:
//            dateLabel.text = data.paymentTime
//            discountInfoLabel.hidden = true
//            if data.isRecharge == true {
//                priceLabel.textColor = UIColor(hex: 0x4285F4)
//                if let rechargeNum = data.rechargeNum {
//                    priceLabel.text = "+\(rechargeNum)氪点"
//                    if let formatted = formatPrice(rechargeNum) {
//                        priceLabel.text = "+\(formatted)氪点"
//                    }
//                }
//                titleLabel.text = "氪点充值"
//            } else if data.isConsume == true {
//                priceLabel.textColor = UIColor(hex: "#26292F")
//                if let consumeNum = data.consumeNum {
//                    priceLabel.text = "-\(consumeNum)氪点"
//                    let consumeFloat = Float(consumeNum)
//                    if let formatted = formatPrice(consumeFloat) {
//                        priceLabel.text = "-\(formatted)氪点"
//                    }
//                }
//                titleLabel.text = "购买专栏："+(data.goods?.name ?? "")
//            }
//        case .Purchase:
//            dateLabel.text = data.createdAt
//            if let amountActul = data.amountActul {
//                priceLabel.text = "-\(amountActul)"
//                let amountActulFloat = Float(amountActul)
//                if var formatted = formatPrice(amountActulFloat) {
//                    if formatted != "0" {
//                        formatted = "-\(formatted)"
//                    }
//                    priceLabel.text = formatted
//                }
//            }
//            titleLabel.text = "购买专栏："+(data.goods?.name ?? "")
//            discountInfoLabel.text = data.couponInfo ?? ""
//        }
//    }
    
}
