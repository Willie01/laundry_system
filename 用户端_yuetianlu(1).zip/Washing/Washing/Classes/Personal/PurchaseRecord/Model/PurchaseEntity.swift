//
//  PurchaseRecordModel.swift
//  Client
//
//  Created by BJQXDN0527 on 2017/2/24.
//  Copyright © 2017年 36Kr. All rights reserved.
//

import Foundation
//import ObjectMapper
//
//struct PurchaseEntity: Mappable {
//    
//    var ID: Int?
//    var goodsID: Int?
//    var priceID: Int?
//    var status: Int?
//    var amount: String?
//    var amountActul: String? //实际支付价格
//    var statusValue: String?
//    var bussinessID: String?
//    var createdAt: String?
//    var updatedAt: NSDate?
//    var platformType: Int?
//    var paymentTime: String?
//    var goods: GoodsEntity?
//    var isRecharge: Bool?
//    var isConsume: Bool?
//    var consumeNum: String?
//    var rechargeNum: Float?
//    var currencyUnit: String?
//    var couponInfo: String? //品牌名称
//    var coupons: [CouponEntity]?
//    
//    init?(_ map: Map) {
//        
//    }
//    
//    mutating func mapping(map: Map) {
//        ID <- map["id"]
//        goodsID <- map["goods_id"]
//        priceID <- map["goods_price_id"]
//        status <- map["status"]
//        amount <- map["amount"]
//        amountActul <- map["amount_actual"]
//        statusValue <- map["status_value"]
//        bussinessID <- map["business_id"]
//        createdAt <- map["created_at"]
//        updatedAt <- (map["updated_at"], CustomDateFormatTransform(formatString: Constants.dateFormat))
//        goods <- map["goods"]
//        platformType <- map["platform_type"]
//        paymentTime <- map["payment_time"]
//        isRecharge <- map["is_recharge"]
//        isConsume <- map["is_consume"]
//        consumeNum <- map["consume_num"]
//        rechargeNum <- map["recharge_num"]
//        currencyUnit <- map["currency_unit"]
//        couponInfo <- map["coupon_info"]
//        coupons <- map["coupons"]
//    }
//}
//
//struct GoodsEntity: Mappable {
//    var id: Int?
//    var name: String?
//    var listCover: NSURL?
//    var detailCover: NSURL?
//    init?(_ map: Map) {
//        
//    }
//    
//    mutating func mapping(map: Map) {
//        id <- map["id"]
//        name <- map["name"]
//        listCover <- (map["list_cover"],CustomURLTransform())
//        detailCover <- (map["detail_cover"],CustomURLTransform())
//    }
//    
//}
