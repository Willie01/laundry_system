//
//  RecordType.swift
//  Client
//
//  Created by BJQXDN0527 on 2017/2/24.
//  Copyright © 2017年 36Kr. All rights reserved.
//

import Foundation

enum RecordType {
    case Purchase //购买记录
    case Exchange //交易记录
    
    static func title(title: RecordType) -> String? {
        switch title {
        case .Purchase:
            return "购买记录"
        case .Exchange:
            return "交易记录"
        }
    }
    
    static func tip(tip: RecordType) -> String {
        switch tip {
        case .Purchase:
            return "无购买记录"
        case .Exchange:
            return "无交易记录"
        }
    }
    
}