//
//  PurchaseRecordViewController.swift
//  Client
//
//  Created by BJQXDN0527 on 2017/2/24.
//  Copyright © 2017年 36Kr. All rights reserved.
//

import UIKit

class PurchaseRecordViewController: BaseTableViewController {
    
    private var type: RecordType?
//    private var data = [PurchaseEntity]()
    private var page: Int = 1
    private enum LoadState {
        case Refresh
        case LoadMore
    }
    let rightButton: UIButton = {
        let button = UIButton()
        let textcolor = UIColor(hex: 0x26292F)
        button.setTitleColor(textcolor, forState: .Normal)
        button.titleLabel?.font = UIFont.systemFontOfSize(15)
        button.setTitle("客服邮箱", forState: .Normal)
        button.sizeToFit()
        return button
    }()
    
    override var emptyTip: String {
        return RecordType.tip(type ?? RecordType.Purchase)
    }
    
    deinit {
        
    }
    
    init(type: RecordType?) {
        super.init(nibName: nil, bundle: nil)
        self.title = RecordType.title(type ?? RecordType.Purchase)
        self.type = type
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func registerCell() {
        tableView.registerNib(UINib(nibName: "PurchaseRecordTableViewCell", bundle: nil), forCellReuseIdentifier: "PurchaseRecordTableViewCell")
    }
    
    override func refreshData() {
        
    }
    
    override func loadMoreData() {
       
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        let rightItem = UIBarButtonItem(customView: rightButton)
        rightButton.addTarget(self, action: #selector(self.managerTagAction), forControlEvents: .TouchUpInside)
        navigationItem.rightBarButtonItem = rightItem
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.estimatedRowHeight = 60
    }
    
    // MARK: Action
    
    func managerTagAction() {
//        alert("knowledge@36kr.com", actions: [AlertAction(title: "知道了", style: .Confirm)]) { (buttonIndex) in
//            
//        }
    }

}

extension PurchaseRecordViewController {
    
    // MARK: UITableViewDataSource
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("PurchaseRecordTableViewCell", forIndexPath: indexPath) as! PurchaseRecordTableViewCell
//        guard indexPath.row < data.count else {
//            return UITableViewCell()
//        }
//        let model = data[indexPath.row]
//        cell.setData(type, data: model)
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
    }
    
}

