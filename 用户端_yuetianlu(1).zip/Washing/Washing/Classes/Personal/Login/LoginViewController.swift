//
//  LoginViewController.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/3/19.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit

class LoginViewController: BaseViewController {
    @IBOutlet weak var userNameTextField: UITextField!

    @IBOutlet weak var passWordTextField: UITextField!
    
    @IBAction func registerAction(sender: AnyObject) {
        let registerNavController = UINavigationController(rootViewController: RegisterViewController())
        
        presentViewController(registerNavController, animated: true) { 
            
        }
    }
    

    
    @IBAction func loginAction(sender: AnyObject) {
        if let name = userNameTextField.text, let password = passWordTextField.text {
            if name.length > 0 && password.length > 0 {
                let dic = ["telphone": name, "password": password]
                HttpSwift.post("http://www.tchautchau.cn/api/users/login", params: dic) { (data, response, error) in
                    print(data)
                    if let data = data {
                        let dic = data.stringToDic
                        NSUserDefaults.standardUserDefaults().setObject(dic, forKey: "userInfo")
                        self.userInfo(dic)
                        dispatch_async(dispatch_get_main_queue(), {
                            HUD.show("登陆成功")
                            self.backAction()
                        })
                    }
                }
            } else {
                HUD.show("以上选项不能为空")
            }
            
        } else {
            HUD.show("以上选项不能为空")
        }
        

    }

    @IBAction func forgetAction(sender: AnyObject) {
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "登陆"
        let backItem = UIBarButtonItem(image: UIImage(named: "ic_close_light"), style: .Plain, target: self, action: #selector(backAction))
        navigationItem.leftBarButtonItem = backItem
        // Do any additional setup after loading the view.
    }
    
    func backAction() {
        if let _ = presentingViewController {
            dismissViewControllerAnimated(true) {
                
            }
        }
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        view.endEditing(true)
    }

}
