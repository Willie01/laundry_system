//
//  RegisterViewController.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/3/19.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit

class RegisterViewController: BaseViewController {

    @IBOutlet weak var telphoneLabel: UITextField!
    
    @IBOutlet weak var passwordLabel: UITextField!
    
    @IBOutlet weak var confirmPasswordLabel: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "注册"
        let backItem = UIBarButtonItem(image: UIImage(named: "ic_close_light"), style: .Plain, target: self, action: #selector(backAction))
        navigationItem.leftBarButtonItem = backItem
        // Do any additional setup after loading the view.
    }
    
    @IBAction func registerAction(sender: AnyObject) {
        if let phone = telphoneLabel.text, let password = passwordLabel.text, let confirm = confirmPasswordLabel.text {
            if phone.length > 0 && password.length > 0 && confirm.length > 0 {
                guard isTelNumber(phone) else {
                    HUD.show("请输入正确的手机号")
                    return
                }
                guard password == confirm else {
                    HUD.show("两次输入密码不一致")
                    return
                }
                let dic = ["telphone": phone, "password": confirm]
                HttpSwift.post("http://www.tchautchau.cn/api/users", params: dic) { (data, response, error) in
                    if let data = data {
                        
                        let dic = data.stringToDic
                        if dic.valueForKey("status") as? String == "unprocessable_entity" {
                            HUD.show("注册失败")
                        } else {
                            dispatch_async(dispatch_get_main_queue(), {
                                HUD.show("注册成功")
                                self.dismissViewControllerAnimated(true, completion: {
                                    
                                })
                            })
                        }
                        print(dic)
                        
                    }
                }
            }
        } else {
            HUD.show("以上选项不能为空")
        }
        
    }


    func isTelNumber(num:String)->Bool
    {
        var predicateStr:String!
        predicateStr = "^((13[0-9])|(15[^4,\\D]) |(17[0,0-9])|(18[0,0-9]))\\d{8}$"
        let predicate =  NSPredicate(format: "SELF MATCHES %@" ,predicateStr)
        return predicate.evaluateWithObject(num)
    }

    func backAction() {
        if let _ = presentingViewController {
            dismissViewControllerAnimated(true) {
                
            }
        }
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        view.endEditing(true)
    }

}
