//
//  AccountViewController.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/4/13.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit

class AccountViewController: UIViewController {

    @IBOutlet weak var accountLabel: UILabel!
    
    @IBOutlet weak var accountTextField: UITextField!
    
    @IBOutlet weak var accountButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "我的余额"
        createUI()
        // Do any additional setup after loading the view.
    }
    
    func createUI() {
        accountLabel.layer.cornerRadius = 5
        accountLabel.backgroundColor = UIColor(hex: 0x4285F4, alpha: 0.5)
        accountLabel.textColor = UIColor.whiteColor()
        accountLabel.layer.masksToBounds = true
        if let banlance = UserInfo.sharedInstance.balance {
            accountLabel.text = "¥\(banlance)元"
        }
    }

    @IBAction func accountAction(sender: AnyObject) {
        if let userId = UserInfo.sharedInstance.ID, let banlance = UserInfo.sharedInstance.balance, let charge = accountTextField.text {
            let price: Float = Float(banlance)! + Float(charge)!
            let dic = ["balance": "\(price)"]
            HttpSwift.post("http://www.tchautchau.cn/api/update/users/\(userId)", params: dic ) { (data, response, error) in
                if let data = data {
                    let dic = data.stringToDic
                    if dic.valueForKey("status") as? String == "unprocessable_entity" {
                        HUD.show("保存失败")
                    } else {
                        dispatch_async(dispatch_get_main_queue(), {
                            HUD.show("充值成功")
                            self.accountLabel.text = "¥\(price)元"
                            UserInfo.sharedInstance.balance = "\(price)"
                        })
                    }
                    print(dic)
                }
            }
        }

    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        view.endEditing(true)
    }

}
