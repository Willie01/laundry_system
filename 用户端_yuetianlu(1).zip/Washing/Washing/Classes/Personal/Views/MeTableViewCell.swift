//
//  MeTableViewCell.swift
//  Client
//
//  Created by paul on 16/8/17.
//  Copyright © 2016年 36Kr. All rights reserved.
//

import UIKit

private let maxCount: Int = 1000

class MeTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel! {
        didSet {
            titleLabel.font = UIFont.systemFontOfSize(16.0, weight: UIFontWeightMedium)
            titleLabel.textColor = UIColor(hex: 0x464C56)
        }
    }
    
    @IBOutlet weak var countLabel: UILabel! {
        didSet {
            countLabel.textAlignment = .Center
            countLabel.font = UIFont.systemFontOfSize(14)
            countLabel.backgroundColor = UIColor(hex: 0xF95355)
        }
    }
    
    @IBOutlet weak var iconImageView: UIImageView!
    
    @IBOutlet weak var iconWidthConstraint: NSLayoutConstraint! {
        didSet {
            iconWidthConstraint.constant = 0
        }
    }
    @IBOutlet weak var titleLabelLeftConstraint: NSLayoutConstraint! {
        didSet {
            titleLabelLeftConstraint.constant = 0
        }
    }
    
    @IBOutlet weak var countLabelWidthConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var countLabelHeightConstraint: NSLayoutConstraint!
    
    var count: Int? {
        didSet {
            setupCountLabelWithCount(count)
        }
    }
    
    var iconImageName: String? {
        didSet {
            if let iconImageName = iconImageName {
                iconWidthConstraint.constant = 24.0
                titleLabelLeftConstraint.constant = 10.0
                iconImageView.image = UIImage(named: iconImageName)
            } else {
                iconWidthConstraint.constant = 0
                titleLabelLeftConstraint.constant = 0
                iconImageView.image = nil
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setupCountLabelWithCount(0)
    }
    
    override func drawRect(rect: CGRect) {
        guard let context: CGContextRef = UIGraphicsGetCurrentContext() else {
            return
        }
        CGContextSetAllowsAntialiasing(context, true)
        CGContextSetLineWidth(context, 2.0 * Constants.Layout.onePixel)
        CGContextSetStrokeColorWithColor(context, UIColor(hex: 0xF0F0F0).CGColor)
        CGContextMoveToPoint(context, 20.0, 49.0)
        CGContextAddLineToPoint(context, rect.width - 20.0, 49.0)
        CGContextStrokePath(context)
    }
    
    private func setupCountLabelWithCount(count: Int?) {
        guard var count = count where count > 0 else {
            countLabel.hidden = true
            return
        }
        countLabel.hidden = false
        count = min(maxCount, count)

        if count == maxCount {
            countLabel.text = "\(999)+"
        } else {
            countLabel.text = "\(count)"
        }
        
        countLabel.sizeToFit()
        var spacing: CGFloat = 6.0
        var width = 2.0 * spacing + countLabel.width
        let height = countLabel.height
        
        if count < 10 {
            width = height
            spacing = 0
        }
        countLabelWidthConstraint.constant = width
        countLabelHeightConstraint.constant = height
        let path = UIBezierPath(roundedRect: CGRect(origin: CGPoint.zero, size: CGSize(width: width, height: height)), cornerRadius: height / 2.0)
        let maskLayer = CAShapeLayer()
        maskLayer.path = path.CGPath
        countLabel.layer.mask = maskLayer
    }
    
}
