//
//  MeTableViewHeader.swift
//  Client
//
//  Created by paul on 16/8/17.
//  Copyright © 2016年 36Kr. All rights reserved.
//

import UIKit

class MeTableViewHeader: UIView {

    var avatarImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .ScaleAspectFill
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()
  
    var nameLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.blackColor()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = ""
        label.font = UIFont.systemFontOfSize(18.0, weight: UIFontWeightMedium)
        label.textColor = UIColor(hex: 0x464C56)
        label.textAlignment = .Center
        return label
    }()
    
    private let defaultAvatar = UIImage(named: "ic_mine_avatar")
    
    var tapAvatarClosure: (Void -> Void)?
    
    class var viewHeight: CGFloat {
        return 230.0
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(avatarImageView)
        addSubview(nameLabel)
        
        for constraint in ["H:|-0-[label]-0-|", "H:[imageView(100)]", "V:|-64-[imageView(100)]-10-[label(>=20)]"]{
            addConstraints(NSLayoutConstraint.constraintsWithVisualFormat(constraint, options: NSLayoutFormatOptions.AlignAllCenterX, metrics: nil, views: ["label" : nameLabel, "imageView" : avatarImageView]))
        }
        avatarImageView.layer.cornerRadius = 50
        avatarImageView.layer.masksToBounds = true
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(tap))
        addGestureRecognizer(tapGesture)
        setHeaderUnloginState()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func tap() {
        tapAvatarClosure?()
    }
    
    func setHeaderData(avatar: NSURL?, name: String?) {
//        avatarImageView.setImageWithURL(avatar, defaultLogo: UIImage(named: "ic_common_avatar"))
//        nameLabel.text = name
//        nameLabel.textColor = UIColor(hex: 0x464C56)
    }
    
    func setHeaderUnloginState() {
        avatarImageView.image = defaultAvatar
        nameLabel.text = "点击登录"
        nameLabel.textColor = UIColor(hex: 0x969fa9)
    }
    
}
