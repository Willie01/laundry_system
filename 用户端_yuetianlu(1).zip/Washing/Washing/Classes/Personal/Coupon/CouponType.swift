//
//  CouponType.swift
//  Client
//
//  Created by BJQXDN0527 on 2017/3/22.
//  Copyright © 2017年 36Kr. All rights reserved.
//

import Foundation

enum CouponType { // 四种不同的界面
    case MyCoupon // 我的优惠券
    case Purchase // 购买显示优惠券
    case OutOfDateCoupon // 过期优惠券
    case UnavailableCoupon // 不可用优惠券
    
    static func title(title: CouponType) -> String {
        switch title {
        case .MyCoupon:
            return "我的优惠券"
        case .Purchase:
            return "可用优惠券"
        case .OutOfDateCoupon:
            return "过期优惠券"
        case .UnavailableCoupon:
            return "不可用优惠券"
        }
    }
    
    static func tip(tip: CouponType) -> String {
        switch tip {
        case .MyCoupon:
            return "暂无可用优惠券"
        case .Purchase:
            return "暂无可用优惠券"
        case .OutOfDateCoupon:
            return "暂无过期优惠券"
        case .UnavailableCoupon:
            return "暂无不可用优惠券"
        }
    }
    
    static func type(type: CouponType) -> Int {
        switch type {
        case .MyCoupon:
            return 1  // 可用优惠券
        case .Purchase:
            return 1  // 商品可用优惠券
        case .UnavailableCoupon:
            return 0  // 不可用优惠券
        case .OutOfDateCoupon:
            return 2  // 过期优惠券
        }
    }
    
}

enum CouponStatus { // 界面中不同优惠券状态
    case Normal // 可用优惠券
    case Selected // 当前选中优惠券
    case Nonused // 不可用优惠券
    case OutOfDate // 已过期优惠券
    
    static func type(type: CouponStatus) -> Int {
        switch type {
        case .Normal:
            return 1
        case .OutOfDate:
            return 2
        default:
            return 1
        }
    }
}

enum PayCouponStatus {  // 支付时选择优惠券状态
    case NoneAvailable // 无可用优惠券
    case UnSelect // 选择优惠券
    case AvailableCoupon // 可用优惠券
    
    static func title(state: PayCouponStatus) -> String {
        switch state {
        case .NoneAvailable:
            return "无可用优惠券"
        case .UnSelect:
            return "请选择优惠券"
        case .AvailableCoupon:
            return ""
        }
    }
}
