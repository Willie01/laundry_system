//
//  CouponEntity.swift
//  Client
//
//  Created by BJQXDN0527 on 2017/3/22.
//  Copyright © 2017年 36Kr. All rights reserved.
//

import Foundation

class CouponEntity: NSObject {
    
    var id : Int = 1
    var price: Int = 1000
    var end_on: String?
    var coupon_type: String?
    var coupon_type_name: String?
    var coupon_name: String?
    
    init(dict : [String : AnyObject]) {
        super.init()
        
        //kvo赋值
        setValuesForKeysWithDictionary(dict)
        //setValuesForKeys(dict)
        
    }
    
    override func setValue(value: AnyObject?, forUndefinedKey key: String) {
        
    }
    
}