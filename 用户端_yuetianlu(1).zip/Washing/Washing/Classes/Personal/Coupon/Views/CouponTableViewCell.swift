//
//  CouponTableViewCell.swift
//  Client
//
//  Created by BJQXDN0527 on 2017/3/22.
//  Copyright © 2017年 36Kr. All rights reserved.
//

import UIKit

class CouponTableViewCell: UITableViewCell {
    
    @IBOutlet weak var bgView: UIView!

    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var dateLabel: UILabel!
    
    @IBOutlet weak var priceLabel: UILabel!
    
    @IBOutlet weak var descriptionLabel: PaddingLabel!
    
    @IBOutlet weak var lineView: UIView!
    
    @IBOutlet weak var iconImageView: UIImageView!
    
    @IBOutlet weak var outOfDateImageView: UIImageView!
    var couponStatus: CouponStatus = .Normal {
        didSet {
           configCouponStatus(couponStatus)
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        createUI()
    }
    
    func createUI() {
        bgView.layer.cornerRadius = 4
        titleLabel.font = UIFont.boldSystemFontOfSize(16)
        priceLabel.font = UIFont.boldSystemFontOfSize(36)
        priceLabel.adjustsFontSizeToFitWidth = true
        descriptionLabel.layer.cornerRadius = 4
        descriptionLabel.layer.masksToBounds = true
        iconImageView.hidden = true
        outOfDateImageView.hidden = true
        let dotView = UIView()
        dotView.frame = CGRect(x: 0, y: 0, width: lineView.bounds.width, height: lineView.bounds.height)
        lineView.addSubview(dotView)
        let dotteShapLayer = CAShapeLayer()
        let mdotteShapePath = CGPathCreateMutable()
        dotteShapLayer.fillColor = UIColor.whiteColor().CGColor
        dotteShapLayer.strokeColor = UIColor(hex: 0x000000).CGColor
        dotteShapLayer.lineWidth = 1.0
        CGPathMoveToPoint(mdotteShapePath, nil, 6.5, 5)
        CGPathAddLineToPoint(mdotteShapePath, nil, UIScreen.mainScreen().bounds.width - 49, 5)
        dotteShapLayer.path = mdotteShapePath
        let arr :NSArray = NSArray(array: [3,5])
        dotteShapLayer.lineDashPhase = 1.0
        dotteShapLayer.lineDashPattern = arr as? [NSNumber]
        dotView.alpha = 0.15
        dotView.layer.addSublayer(dotteShapLayer)
        let text = "10 元"
        let attributedString = NSMutableAttributedString(string: text)
        attributedString.addAttribute(NSFontAttributeName, value: UIFont.systemFontOfSize(16), range: (text as NSString).rangeOfString("元"))
        priceLabel.attributedText = attributedString
    }
    
    private func normalState() {
        titleLabel.textColor = UIColor.whiteColor()
        dateLabel.textColor = UIColor(hex: 0xffffff, alpha: 0.8)
        priceLabel.textColor = UIColor.whiteColor()
        descriptionLabel.textColor = UIColor(hex: 0xffffff, alpha: 0.8)
        descriptionLabel.backgroundColor = UIColor(hex: 0xF95355)
        lineView.backgroundColor = UIColor(hex: 0xF95355)
        bgView.backgroundColor = UIColor(hex: 0xF95355)
       
    }
    
    private func unavailabelState() {
        titleLabel.textColor = UIColor(hex: 0x969FA9)
        dateLabel.textColor = UIColor(hex: 0x969FA9, alpha: 0.75)
        priceLabel.textColor = UIColor(hex: 0x969FA9)
        descriptionLabel.textColor = UIColor(hex: 0x969FA9, alpha: 0.75)
        descriptionLabel.backgroundColor = UIColor(hex: 0xF0F0F0)
        lineView.backgroundColor = UIColor(hex: 0xF0F0F0)
        bgView.backgroundColor = UIColor(hex: 0xF0F0F0)
    }
    
    private func configCouponStatus(state: CouponStatus) {
        iconImageView.hidden = true
        outOfDateImageView.hidden = true
        switch state {
        case .Normal:
            normalState()
        case .Selected:
            normalState()
            iconImageView.hidden = false
        case .Nonused:
            unavailabelState()
        case .OutOfDate:
            unavailabelState()
            outOfDateImageView.hidden = false
        }
    }
    func setData(data: CouponEntity) {
        if let time = data.end_on {
            dateLabel.text = "有效期至\(time)"
        }
        
        let text = "\(data.price) 元"
        let attributedString = NSMutableAttributedString(string: text)
        attributedString.addAttribute(NSFontAttributeName, value: UIFont.systemFontOfSize(16), range: (text as NSString).rangeOfString("元"))
        priceLabel.attributedText = attributedString
        descriptionLabel.text = data.coupon_type_name
        titleLabel.text = data.coupon_name
        
    }

//    func setData(data: CouponEntity) {
//        var text: String = ""
//        if let activityName = data.couponActivity?.brandName {
//            if activityName.length > 0 {
//                text = "\(activityName) · "
//            }
//        }
//        if let name = data.name {
//            text = text + name
//        }
//        titleLabel.text = text
//        if let amount = data.amount {
//            let amountFloat = Float(amount)
//            priceLabel.text = "\(amount) 元"
//            if let formatted = formatPrice(amountFloat) {
//                priceLabel.text = "\(formatted) 元"
//            }
//            let text = priceLabel.text ?? "0 元"
//            let attributedString = NSMutableAttributedString(string: text)
//            attributedString.addAttribute(NSFontAttributeName, value: UIFont.systemFontOfSize(16), range: (text as NSString).rangeOfString("元"))
//            priceLabel.attributedText = attributedString
//        }
//        if let date = data.couponBatch?.unvalidateAt {
//            let dateFormatter = NSDateFormatter()
//            dateFormatter.dateFormat = "yyyy'年'MM'月'dd'日'"
//            let dateStr = dateFormatter.stringFromDate(date)
//            dateLabel.text = "有效期至\(dateStr)"
//        }
//        if let goodID = data.goodsID{
//            if goodID == 0 {
//                descriptionLabel.text = "所有专栏可用"
//            } else {
//                descriptionLabel.text = "仅限开氪专栏《\(data.goods?.name ?? "")》购买使用"
//            }
//        }
//    }
    
}
