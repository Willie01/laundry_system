//
//  CouponViewController.swift
//  Client
//
//  Created by BJQXDN0527 on 2017/3/22.
//  Copyright © 2017年 36Kr. All rights reserved.
//

import UIKit

class CouponViewController: BaseTableViewController {
    
    private var type: CouponType
    private var data: [CouponEntity] = []
//    var selectData: CouponEntity?
    var goodsID: Int?
    var selectStatus: PayCouponStatus = .AvailableCoupon
    
    private let inset: CGFloat = 140
    
    private let unavailabelButton: UIButton = {
        let button = UIButton()
        let color = UIColor(hex: 0x464C56)
        button.setTitleColor(color, forState: .Normal)
        button.titleLabel?.font = UIFont.systemFontOfSize(14)
        button.setTitle("不可用优惠券", forState: .Normal)
        let image = UIImage(named: "arrow_right")
        button.sizeToFit()
        let iconView = UIImageView()
        iconView.image = image
        button.addSubview(iconView)
        let text = "查看不可用优惠券"
        let contentWidth = (text as NSString).boundingRectWithSize(CGSize(width: Constants.Layout.screenWidth, height: 40), options: .UsesLineFragmentOrigin,attributes: [NSFontAttributeName : UIFont.systemFontOfSize(14)],context: nil).size.width
        iconView.frame = CGRect(x: (Constants.Layout.screenWidth - 140) / 2 + contentWidth + 10, y: 13, width: 14, height: 14)
        return button
    }()
    
    private let tipButton: UIButton = {
        let button = UIButton()
        let color = UIColor(hex: 0x464C56)
        button.setTitleColor(color, forState: .Normal)
        button.titleLabel?.font = UIFont.systemFontOfSize(14)
        button.setTitle("查看过期优惠券", forState: .Normal)
        let image = UIImage(named: "arrow_right")
        button.setImage(image, forState: .Normal)
        button.titleEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 14)
        button.imageEdgeInsets = UIEdgeInsets(top: 8, left: 140 - 14, bottom: 8, right: 0)
        return button
    }()
    
    private let nonuseButton: UIButton = {
        let button = UIButton()
        button.layer.borderWidth = 1
        let color = UIColor(hex: 0x464C56)
        button.layer.borderColor = color.CGColor
        button.layer.cornerRadius = 20
        button.setTitleColor(color, forState: .Normal)
        button.titleLabel?.font = UIFont.systemFontOfSize(14)
        button.width = 160
        button.height = 40
        button.setTitle("不使用优惠券", forState: .Normal)
        return button
    }()
    var didUnusedCouponClosure: (Void -> Void)?
    var didSelectedCouponClosure: (CouponEntity-> Void)?
    
    override var emptyImageName: String {
        return "pic_no_coupon"
    }
    
    override var emptyTip: String {
        return CouponType.tip(self.type ?? .MyCoupon)
    }
    
//    override var reloadEnabled: Bool {
//        return false
//    }
//    override var loadMoreEnabled: Bool {
//        return false
//    }
    
    deinit {
        
    }
    
    init(type: CouponType) {
        self.type = type
        super.init(nibName: nil, bundle: nil)
        self.title = CouponType.title(type)
        switch type {
        case .Purchase:
            createGuidView()
            let backItem = UIBarButtonItem(image: UIImage(named: "ic_common_nav_back_white"), style: .Plain, target: self, action: #selector(backAction))
            navigationItem.leftBarButtonItem = backItem
            unavailabelButton.setTitle("查看不可用优惠券", forState: .Normal)
        case .MyCoupon:
            createGuidView()
            unavailabelButton.setTitle("查看过期优惠券", forState: .Normal)
        case .OutOfDateCoupon:
            return
        case .UnavailableCoupon:
            return
        
        }
    }
    
    override func registerCell() {
        tableView.registerNib(UINib(nibName: "CouponTableViewCell", bundle: nil), forCellReuseIdentifier: "CouponTableViewCell")
    }
    
    override func refreshData() {
        
        if let id = UserInfo.sharedInstance.ID {
            HttpSwift.request("get", url: "http://www.tchautchau.cn/api/coupons_users/\(id)") { (data, response, error) in
                print(data)
                if let data = data {
                    
                    let arr = data.stringToArr
                    for dic in arr {
                        let model = CouponEntity(dict: dic as! [String : AnyObject])
                        self.data.append(model)
                    }
                    
                    dispatch_async(dispatch_get_main_queue(), {
                        self.tableView.reloadData()
                    })
                }
            }
        }
    }
    
    override func loadMoreData() {
        
    }
    
   
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        if type == .Purchase {
            navigationController?.setNavigationBarHidden(false, animated: animated)
        }
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        if type == .Purchase && navigationController?.viewControllers.count == 1 {
            navigationController?.setNavigationBarHidden(true, animated: animated)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.separatorStyle = .None
        tableView.estimatedRowHeight = 30
        tableView.rowHeight = UITableViewAutomaticDimension
        tipButton.addTarget(self, action: #selector(self.unavailabelAction), forControlEvents: .TouchUpInside)
        unavailabelButton.addTarget(self, action: #selector(self.unavailabelAction), forControlEvents: .TouchUpInside)
        
        unavailabelButton.frame = CGRect(x: 0, y: 0, width: inset, height: 40)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        switch type {
        case .Purchase:
            tableView.frame = CGRect(x: 0, y: 0, width: view.width, height: view.height-50)
        default:
            return
        }
    }
    
    private func createGuidView() {
//        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "使用说明", style: .Plain, target: self, action: #selector(self.managerTagAction))
    }
    
    // MARK: Action
    func managerTagAction() {
        
    }
    
    func backAction() {
        navigationController?.popViewControllerAnimated(true)
    }
    
    func unavailabelAction() {
        
        
    }
    
    func unusedAction() {
        didUnusedCouponClosure?()
        navigationController?.popViewControllerAnimated(true)
    }

}

extension CouponViewController {
    
    // MARK: UITableViewDataSource
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("CouponTableViewCell", forIndexPath: indexPath) as! CouponTableViewCell
        cell.selectionStyle = .None
        cell.couponStatus = .Normal
        guard indexPath.row < data.count else {
            return UITableViewCell()
        }
        let model = data[indexPath.row]
//        switch type {
//        case .MyCoupon:
//            cell.couponStatus = .Normal
//        case .OutOfDateCoupon:
//            cell.couponStatus = .OutOfDate
//        case .Purchase:
//            if indexPath.row == 0 && selectStatus != .UnSelect{
//                cell.couponStatus = .Selected
//            } else {
//                cell.couponStatus = .Normal
//            }
//        case .UnavailableCoupon:
//            if let status = model.couponBatch?.expired {
//                if status == CouponStatus.type(.OutOfDate) {
//                    cell.couponStatus = .OutOfDate
//                } else {
//                    cell.couponStatus = .Nonused
//                }
//            }
//        }
        cell.setData(model)
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        if type == .Purchase {
            let model = data[indexPath.row]
            didSelectedCouponClosure?(model)
            dismissViewControllerAnimated(true, completion: nil)
        }

    }
    
    
}
