//
//  MeTabController.swift
//  Client
//
//  Created by aidenluo on 7/29/16.
//  Copyright © 2016 36Kr. All rights reserved.
//

import Foundation
import UIKit

final class PersonalViewController: BaseViewController {
    
    private var tableView: UITableView = {
        let tableView = UITableView(frame: CGRect.zero, style: UITableViewStyle.Grouped)
        tableView.backgroundColor = UIColor.whiteColor()
        tableView.registerNib(UINib(nibName: "MeTableViewCell", bundle: nil), forCellReuseIdentifier: "MeTableViewCell")
        tableView.separatorStyle = .None
        tableView.rowHeight = 50.0
        return tableView
    }()
    
    private var headerViewFrame: CGRect {
        return CGRect(origin: CGPoint.zero, size: CGSize(width: Constants.Layout.screenWidth, height: MeTableViewHeader.viewHeight))
    }

    
    private enum RowType {
        case Profile // 我的资料
        case Account// 我的余额
        case Settings // 设置
        case Address // 我的地址
        case DiscountCard // 优惠券
        
        func title() -> String {
            switch self {
            case .Profile:
                return "我的资料"
            case .Account:
                return "我的余额"
            case .Settings:
                return "设置"
            case .Address:
                return "我的地址"
            case .DiscountCard:
                return "我的优惠券"
            }
        }
        
        func icon() -> String {
            switch self {
            case .Profile:
                return "ic_mine_profile"
            case .Account:
                return "ic_mine_favorite"
            case .Settings:
                return "ic_mine_settings"
            case .Address:
                return "ic_mine_follow"
            case .DiscountCard:
                return "ic_mine_history"
            }
        }
        
    }
    
    private let sections: [[RowType]] = [
        [
            .Profile,
            .Account,
        ],
        [
            .Address,
            .DiscountCard,
        ],
        [
            .Settings,
        ]
    ]
    
    private var headerView: MeTableViewHeader = {
        let view = MeTableViewHeader(frame: CGRect.zero)
        return view
    }()
    
    private let statusBarBackground: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.whiteColor()
        view.frame = CGRect(origin: CGPoint.zero, size: CGSize(width: Constants.Layout.screenWidth, height: Constants.Layout.statusBarHeight))
        return view
    }()
    
    deinit {
        tableView.delegate = nil
        tableView.dataSource = nil
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        if let id = UserInfo.sharedInstance.ID {
            HttpSwift.request("get", url: "http://www.tchautchau.cn/api/portraits/\(id)") { (data, response, error) in
                print(data)
                if let dic = data?.stringToDic {
                    let model = HeaderModel(dict: dic as! [String : AnyObject])
                    dispatch_async(dispatch_get_main_queue(), {
                        if let logo = model.portrait {
                             self.headerView.avatarImageView.setImageWithURL(NSURL(string: "http://www.tchautchau.cn/\(logo)"), placeholderImage: UIImage(named: "ic_mine_avatar"))
                        }
                    })
                }
            }
        }
//        let index = NSIndexPath(forRow: 0, inSection: 2)
//        let cell = tableView.cellForRowAtIndexPath(index) as! MeTableViewCell
        if let name = UserInfo.sharedInstance.Phone {
            headerView.nameLabel.text = name
            //cell.titleLabel.text = "退出登录"
        } else {
            headerView.nameLabel.text = "点击登录"
            //cell.titleLabel.text = "点击登录"
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.setNavigationBarHidden(true, animated: false)
        view.addSubview(tableView)
        tableView.delegate = self
        tableView.dataSource = self
        headerView.frame = headerViewFrame
        headerView.tapAvatarClosure = {
            if let _ = UserInfo.sharedInstance.ID {
                return
            }
            let loginNavController = UINavigationController(rootViewController: LoginViewController())
            
            self.presentViewController(loginNavController, animated: true) {
                
            }
        }
        tableView.tableHeaderView = headerView
        tableView.reloadData()
        view.addSubview(statusBarBackground)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        tableView.frame = view.bounds
    }

}

extension PersonalViewController: UITableViewDelegate, UITableViewDataSource {
    
    // MARK: UITableViewDelegate
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        guard let type = rowTypeForIndexPath(indexPath) else {
            return
        }
        switch type {
        case .Profile:
            if let _ = UserInfo.sharedInstance.ID {
                self.navigationController?.pushViewController(MyProfileViewController(), animated: true)
            } else {
                HUD.show("请先进行登陆")
            }
        case .Account:
            if let _ = UserInfo.sharedInstance.ID {
                self.navigationController?.pushViewController(AccountViewController(), animated: true)
            } else {
                HUD.show("请先进行登陆")
            }
        case .Address:
            if let _ = UserInfo.sharedInstance.ID {
                self.navigationController?.pushViewController(AddressViewController(), animated: true)
            } else {
                HUD.show("请先进行登陆")
            }
        case .DiscountCard:
            if let _ = UserInfo.sharedInstance.ID {
                UIViewController.topViewController()?.navigationController?.pushViewController(CouponViewController(type: CouponType.MyCoupon), animated: true)
            } else {
                HUD.show("请先进行登陆")
            }
        case .Settings:
            let loginNavController = UINavigationController(rootViewController: LoginViewController())
            
            presentViewController(loginNavController, animated: true) {
                
            }
        }
    }
    
    // MARK: UITableViewDataSource
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return sections.count
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sections[section].count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("MeTableViewCell", forIndexPath: indexPath) as! MeTableViewCell
        if let type = rowTypeForIndexPath(indexPath) {
            cell.titleLabel.text = type.title()
            cell.iconImageName = type.icon()
        }
        return cell
    }
    
    private func rowTypeForIndexPath(indexPath: NSIndexPath) -> RowType? {
        guard indexPath.section < sections.count else {
            return nil
        }
        guard indexPath.row < sections[indexPath.section].count else {
            return nil
        }
        return sections[indexPath.section][indexPath.row]
    }
    
    private func indexPathForRowType(rowType: RowType) -> NSIndexPath? {
        for (sectionIndex, section) in sections.enumerate() {
            for (rowIndex, row) in section.enumerate() {
                guard row == rowType else {
                    continue
                }
                return NSIndexPath(forRow: rowIndex, inSection: sectionIndex)
            }
        }
        return nil
    }
    
}

/*
 //        if isSwipeToRight {
 //            turnRight = true
 //            willToIndex = Int((scrollView.contentOffset.x + scrollView.frame.width - 0.1) / scrollView.frame.width)
 //            if turnLeft {
 //                currentIndex -= 1
 //                turnLeft = false
 //            }
 //            percent = scrollPercent - CGFloat(currentIndex)
 //            percent = percent > 1 ? 1:percent
 //            let index = Int(scrollView.contentOffset.x / scrollView.frame.width)
 //            currentIndex = index
 //            print("\(percent)---scroll-\(scrollPercent) current-\(currentIndex)")
 //        } else {
 //            turnLeft = true
 //            willToIndex = Int(scrollView.contentOffset.x / scrollView.frame.width)
 //            if turnRight {
 //                currentIndex += 1
 //                turnRight = false
 //            }
 //            percent = CGFloat(currentIndex) - scrollPercent
 //            percent = percent > 1 ? 1:percent
 //            let index = ceil(scrollView.contentOffset.x / scrollView.frame.width)
 //            currentIndex = Int(index)
 //            print("\(percent)---scroll-\(scrollPercent) current-\(currentIndex)")
 //        }
 */