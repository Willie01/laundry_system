//
//  HUDWindow.swift
//  Client
//
//  Created by aidenluo on 8/24/16.
//  Copyright © 2016 36Kr. All rights reserved.
//

import UIKit

class HUDWindow: UIWindow {

    let frameView: HUDFrameView
    init(frameView: HUDFrameView = HUDFrameView()) {
        self.frameView = frameView
        super.init(frame: UIApplication.sharedApplication().delegate!.window!!.bounds)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        frameView = HUDFrameView()
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit() {
        rootViewController = HUDWindowRootViewController()
        windowLevel = UIWindowLevelNormal + 500.0
        backgroundColor = UIColor.clearColor()
        
        addSubview(backgroundView)
        addSubview(frameView)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        frameView.center = center
        backgroundView.frame = bounds
    }
    
    func showFrameView() {
        layer.removeAllAnimations()
        makeKeyAndVisible()
        frameView.center = center
        frameView.alpha = 1.0
        hidden = false
    }
    
    private var willHide = false
    
    func hideFrameView(animated anim: Bool, completion: ((Bool) -> Void)? = nil) {
        let finalize: (finished: Bool) -> (Void) = { finished in
            self.hidden = true
            self.willHide = false
            
            completion?(finished)
        }
        
        if hidden {
            return
        }
        
        willHide = true
        
        if anim {
            UIView.animateWithDuration(0.25, animations: {
                self.frameView.alpha = 0.0
                self.hideBackground(animated: false)
                }, completion: { bool in finalize(finished: true) } )
        } else {
            self.frameView.alpha = 0.0
            finalize(finished: true)
        }
    }
    
    private let backgroundView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor(white:0.0, alpha:0.25)
        view.alpha = 0.0
        return view
    }()
    
    func showBackground(animated anim: Bool) {
        if anim {
            UIView.animateWithDuration(0.175) {
                self.backgroundView.alpha = 1.0
            }
        } else {
            backgroundView.alpha = 1.0
        }
    }
    
    func hideBackground(animated anim: Bool) {
        if anim {
            UIView.animateWithDuration(0.65) {
                self.backgroundView.alpha = 0.0
            }
        } else {
            backgroundView.alpha = 0.0
        }
    }

}
