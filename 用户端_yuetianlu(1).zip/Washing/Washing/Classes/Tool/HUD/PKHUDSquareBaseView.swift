//
//  PKHUDSquareBaseView.swift
//  PKHUD
//
//  Created by Philip Kluz on 6/12/15.
//  Copyright (c) 2016 NSExceptional. All rights reserved.
//  Licensed under the MIT license.
//

import UIKit

/// PKHUDSquareBaseView provides a square view, which you can subclass and add additional views to.
class PKHUDSquareBaseView: UIView {
    
    static let defaultSquareBaseViewFrame = CGRect(origin: CGPointZero, size: CGSize(width: 100, height: 100))

    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    init(image: UIImage?) {
        super.init(frame: PKHUDSquareBaseView.defaultSquareBaseViewFrame)
        imageView.image = image?.imageWithRenderingMode(.AlwaysTemplate)
        addSubview(imageView)
        imageView.sizeToFit()
        imageView.center = center
    }
    
    init(title: String?) {
        super.init(frame: PKHUDSquareBaseView.defaultSquareBaseViewFrame)
        titleLabel.text = title
        addSubview(titleLabel)
        titleLabel.sizeToFit()
        size = CGSizeMake(max(width, titleLabel.width + 40), 60)
        titleLabel.center = center
    }
    
    init(image: UIImage?, title: String?) {
        super.init(frame: PKHUDSquareBaseView.defaultSquareBaseViewFrame)
        imageView.image = image?.imageWithRenderingMode(.AlwaysTemplate)
        titleLabel.text = title
        addSubview(imageView)
        addSubview(titleLabel)
        imageView.sizeToFit()
        titleLabel.sizeToFit()
        size = CGSizeMake(max(width, titleLabel.width + 40), height)
        imageView.center = center
        imageView.top = 20
        titleLabel.center = center
        titleLabel.top = imageView.bottom + 8
    }

    let imageView: UIImageView = {
        let imageView = UIImageView()
        imageView.clipsToBounds = false
        imageView.contentMode = .Center
        imageView.tintColor = UIColor(hex: 0x464c56)
        imageView.size = CGSizeMake(37, 37)
        return imageView
    }()
    
    let titleLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .Center
        label.font = UIFont.systemFontOfSize(14, weight: UIFontWeightMedium)
        label.textColor = UIColor(hex: 0x464c56)
        label.adjustsFontSizeToFitWidth = true
        return label
    }()
}
