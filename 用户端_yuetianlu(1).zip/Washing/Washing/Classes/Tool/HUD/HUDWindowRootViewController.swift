//
//  HUDWindowRootViewController.swift
//  Client
//
//  Created by aidenluo on 8/24/16.
//  Copyright © 2016 36Kr. All rights reserved.
//

import UIKit

class HUDWindowRootViewController: UIViewController {

    override func supportedInterfaceOrientations() -> UIInterfaceOrientationMask {
        if let rootViewController = UIApplication.sharedApplication().delegate?.window??.rootViewController {
            return rootViewController.supportedInterfaceOrientations()
        } else {
            return UIInterfaceOrientationMask.Portrait
        }
    }
    
    override func preferredStatusBarStyle() -> UIStatusBarStyle {
        return self.presentingViewController?.preferredStatusBarStyle() ?? UIApplication.sharedApplication().statusBarStyle
    }
    
    override func prefersStatusBarHidden() -> Bool {
        return self.presentingViewController?.prefersStatusBarHidden() ?? UIApplication.sharedApplication().statusBarHidden
    }
    
    override func preferredStatusBarUpdateAnimation() -> UIStatusBarAnimation {
        if let rootViewController = UIApplication.sharedApplication().delegate?.window??.rootViewController {
            return rootViewController.preferredStatusBarUpdateAnimation()
        } else {
            return .None
        }
    }
    
    override func shouldAutorotate() -> Bool {
        if let rootViewController = UIApplication.sharedApplication().delegate?.window??.rootViewController {
            return rootViewController.shouldAutorotate()
        } else {
            return false
        }
    }


}
