//
//  HUD.swift
//  Client
//
//  Created by aidenluo on 8/11/16.
//  Copyright © 2016 36Kr. All rights reserved.
//

import Foundation

struct HUD {
    
    static let hideDelayTime = 1.75
    static func setupAppearance(dimsBackground: Bool) {
        PKHUD.sharedHUD.dimsBackground = dimsBackground
        PKHUD.sharedHUD.userInteractionOnUnderlyingViewsEnabled = true
    }
    
    static func show(dimsBackground: Bool = false, userInteractionOnUnderlyingViewsEnabled: Bool = true) {
        HUD.setupAppearance(dimsBackground)
        PKHUD.sharedHUD.userInteractionOnUnderlyingViewsEnabled = userInteractionOnUnderlyingViewsEnabled
        guard PKHUD.sharedHUD.isVisible == false else { return }
        PKHUD.sharedHUD.contentView = PKHUDRotatingImageView(image: UIImage(named: "ic_toast_loading"))
        PKHUD.sharedHUD.show()
    }
    
    static func dismiss() {
        PKHUD.sharedHUD.hide(false) { (finished) in
            UIApplication.sharedApplication().keyWindow?.makeKeyAndVisible()
        }
    }
    
    static func show(message: String, dimsBackground: Bool = false) {
        HUD.setupAppearance(dimsBackground)
        PKHUD.sharedHUD.contentView = PKHUDSquareBaseView(title: message)
        PKHUD.sharedHUD.show()
        PKHUD.sharedHUD.hide(afterDelay: hideDelayTime) { (finished) in
            UIApplication.sharedApplication().keyWindow?.makeKeyAndVisible()
        }
    }
    
    static func showSuccess(message: String, dimsBackground: Bool = false) {
        HUD.setupAppearance(dimsBackground)
        PKHUD.sharedHUD.contentView = PKHUDSquareBaseView(image: UIImage(named: "ic_toast_success"), title: message)
        PKHUD.sharedHUD.show()
        PKHUD.sharedHUD.hide(afterDelay: hideDelayTime) { (finished) in
            UIApplication.sharedApplication().keyWindow?.makeKeyAndVisible()
        }
    }
    
    static func showError(message: String, dimsBackground: Bool = false) {
        HUD.setupAppearance(dimsBackground)
        PKHUD.sharedHUD.contentView = PKHUDSquareBaseView(image: UIImage(named: "ic_toast_warning"), title: message)
        PKHUD.sharedHUD.show()
        PKHUD.sharedHUD.hide(afterDelay: hideDelayTime) { (finished) in
            UIApplication.sharedApplication().keyWindow?.makeKeyAndVisible()
        }
    }
    
}