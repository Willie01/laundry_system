//
//  UIViewController+TopViewController.swift
//  AlertView
//
//  Created by paul on 15/12/1.
//  Copyright © 2015年 小普. All rights reserved.
//

import UIKit

extension UIViewController {
    static func topViewController(viewController: UIViewController? = nil) -> UIViewController?
    {
        let viewController = viewController ?? (UIApplication.sharedApplication().delegate as? AppDelegate)?.window?.rootViewController
        
        if let navigationController = viewController as? UINavigationController
            where !navigationController.viewControllers.isEmpty
        {
            return topViewController(navigationController.viewControllers.last)
        } else if let tabBarController = viewController as? UITabBarController,
            selectedController = tabBarController.selectedViewController
        {
            return topViewController(selectedController)
        } else if let presentedController = viewController?.presentedViewController {
            return topViewController(presentedController)
        }
        
        return viewController
    }
}
