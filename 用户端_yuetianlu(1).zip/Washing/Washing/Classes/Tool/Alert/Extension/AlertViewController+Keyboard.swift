//
//  AlertViewController+Keyboard.swift
//  Client
//
//  Created by paul on 16/1/8.
//  Copyright © 2016年 36Kr. All rights reserved.
//

import UIKit

extension AlertViewController {
    
    func addKeyboardNotification() {
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(keyboardWillShowNotification), name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(keyboardWillHideNotification), name: UIKeyboardWillHideNotification, object: nil)
    }
    
    func removeKeyboardNotification() {
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    func keyboardWillShowNotification() {
        let currentSize = iPhoneScreenSize.currentScreenSize()
        var constant: CGFloat = 0
        
        switch currentSize {
        case .Inch3_5:
            constant = 100
        case .Inch4_0:
            constant = 50
        case .Inch4_7:
            constant = 40
        case .Inch5_5:
            constant = 20
        default:
            constant = 30
        }
        
        UIView.animateWithDuration(0.25) { () -> Void in
            self.centerYConstraint?.constant = constant
            self.view.layoutIfNeeded()
        }
    }
    
    func keyboardWillHideNotification() {
        UIView.animateWithDuration(0.25) { () -> Void in
            self.centerYConstraint?.constant = 0
            self.view.layoutIfNeeded()
        }
    }
    
}

private protocol ScreenSize {
    func screenSize() -> CGSize
}

private enum iPhoneScreenSize: ScreenSize {
    case Unknown
    case Inch3_5
    case Inch4_0
    case Inch4_7
    case Inch5_5
    
    func screenSize() -> CGSize {
        switch self {
            
        case .Inch3_5:
            return CGSize(width: 320.0, height: 480.0)
            
        case .Inch4_0:
            return CGSize(width: 320.0, height: 568.0)
            
        case .Inch4_7:
            return CGSize(width: 375.0, height: 667.0)
            
        case .Inch5_5:
            return CGSize(width: 414.0, height: 736)
            
        case .Unknown:
            return CGSize.zero
            
        }
    }
    
    static func currentScreenSize() -> iPhoneScreenSize {
        let screenSize = UIScreen.mainScreen().bounds.size
        let iPhoneCollection = [iPhoneScreenSize.Inch3_5, .Inch4_0, .Inch4_7, .Inch5_5]
        
        var currentScreenSize = iPhoneScreenSize.Unknown
        iPhoneCollection.forEach { (phone) -> () in
            if screenSize == phone.screenSize() {
                currentScreenSize = phone
                return
            }
        }
        return currentScreenSize
    }
}