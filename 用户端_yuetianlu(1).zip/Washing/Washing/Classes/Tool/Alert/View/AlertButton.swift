//
//  AlertButton.swift
//  AlertView
//
//  Created by paul on 15/11/30.
//  Copyright © 2015年 小普. All rights reserved.
//

import UIKit

enum AlertButtonStyle: Int {
    case Cancel
    case Confirm
}

@IBDesignable
class AlertButton: UIButton {
    
    @IBInspectable var style: Int = 0 {
        didSet {
            switch style {
            case AlertButtonStyle.Confirm.rawValue:
                backgroundColor = UIColor.whiteColor()
                cornerRaduis = 0
            case AlertButtonStyle.Cancel.rawValue:
                backgroundColor = UIColor.whiteColor()
                cornerRaduis = 0
                setTitleColor(UIColor.grayColor(), forState: .Normal)
            default:
                ()
            }
        }
    }
    
    @IBInspectable var titleColor: UIColor = UIColor.whiteColor() {
        didSet {
            setTitleColor(titleColor, forState: UIControlState.Normal)
        }
    }
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        titleColor = UIColor.whiteColor()
    }
}
