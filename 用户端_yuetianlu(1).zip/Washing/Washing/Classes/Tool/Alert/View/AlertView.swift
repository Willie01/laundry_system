//
//  AlertView.swift
//  AlertView
//
//  Created by paul on 15/11/30.
//  Copyright © 2015年 小普. All rights reserved.
//

import UIKit

struct AlertAction {
    var title: String
    var style: AlertButtonStyle
    
    static let localizationTableName: String = "AlertLocalization"
    
    static var defaultAction: AlertAction {
        return AlertAction(title: "确定", style: AlertButtonStyle.Confirm)
    }
    
    init(title: String, style: AlertButtonStyle = .Confirm) {
        self.title = title
        self.style = style
    }
    
}

enum AlertStyle {
    case Presentation
    case System
}

protocol AlertViewAppearance {
    var titleFont: UIFont { get }
    var titleColor: UIColor { get }
    var subtitleFont: UIFont { get }
    var subtitleColor: UIColor { get }
    var buttonsSeparatorColor: UIColor { get }
    var confirmButtonColor: UIColor { get }
    var confirmButtonFont: UIFont { get }
    var cancelButtonColor: UIColor { get }
    var cancelButtonFont: UIFont { get }
    var alertCornerRadius: CGFloat { get }
}

struct DefaultAlertViewAppearance: AlertViewAppearance {
    var titleFont: UIFont = UIFont.systemFontOfSize(16.0, weight: UIFontWeightMedium)
    var titleColor: UIColor = UIColor.blackColor()
    var subtitleFont: UIFont = UIFont.systemFontOfSize(14.0)
    var subtitleColor: UIColor = UIColor.grayColor()
    var buttonsSeparatorColor: UIColor = UIColor.grayColor()
    var confirmButtonColor: UIColor = UIColor.blackColor()
    var confirmButtonFont: UIFont = UIFont.systemFontOfSize(14.0, weight: UIFontWeightMedium)
    var cancelButtonColor: UIColor = UIColor.grayColor()
    var cancelButtonFont: UIFont = UIFont.systemFontOfSize(14.0, weight: UIFontWeightMedium)
    var alertCornerRadius: CGFloat = 5.0
}

private let AlertViewButtonHeight: CGFloat = 50.0
private let MarginTop: CGFloat = 25.0


@IBDesignable

class AlertView: UIView {
    
    @IBOutlet weak var contentView: UIView!
    
    @IBOutlet weak var imageView: UIImageView!

    @IBOutlet weak var titleLabel: UILabel! {
        didSet {
            titleLabel.numberOfLines = 0
        }
    }

    @IBOutlet weak var messageLabel: UILabel!

    @IBOutlet weak var buttonsWrapperView: UIView!

    @IBOutlet weak var noImageViewHeightConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var imageViewTopConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var titleLabelTopConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var messageLabelTopConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var noCustomViewHeightConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var closeButton: UIButton!
    
    @IBOutlet weak var customView: UIView! {
        didSet {
            customView.backgroundColor = UIColor.whiteColor()
        }
    }
    
    @IBOutlet weak var customViewBottomConstraint: NSLayoutConstraint!

    var title: String? {
        didSet {
            titleLabel.text = title
            
            if let title = title where (title as NSString).length > 0 {
                titleLabelTopConstraint.constant = MarginTop
            } else {
                titleLabelTopConstraint.constant = 0
            }
        }
    }
    
    var message: String? {
        didSet {
            messageLabel.text = message
            
            if let message = message where (message as NSString).length > 0 {
                messageLabelTopConstraint.constant = MarginTop
            } else {
                messageLabelTopConstraint.constant = 0
            }
        }
    }
    
    var image: UIImage? {
        didSet {
            imageView.image = image
            
            if let _ = image {
                imageViewTopConstraint.constant = MarginTop
                noImageViewHeightConstraint.active = false
            } else {
                imageViewTopConstraint.constant = 0
                noImageViewHeightConstraint.active = true
            }
        }
    }
    
    var spacing: CGFloat {
        return 1.0 / UIScreen.mainScreen().scale
    }
    
    private(set) var buttons: [AlertButton]?
    
    var appearance: AlertViewAppearance?
    
    weak var controller: AlertViewController? {
        didSet {
            setupAppearance()
        }
    }

    var alertActions: [AlertAction]? {
        didSet {
            if let actions = alertActions
            {
                if let buttons = buttons {
                    for button in buttons {
                        button.removeFromSuperview()
                    }
                }
                var newButtons = [AlertButton]()
                for action in actions {
                    let button = AlertButton(type: .System)
                    button.style = action.style.rawValue
                    button.setTitle(action.title, forState: .Normal)
                    button.sizeToFit()
                    var frame = button.frame
                    frame.size.height = AlertViewButtonHeight
                    button.frame = frame
                    button.addTarget(self, action: #selector(AlertView.buttonAction(_:)), forControlEvents: .TouchUpInside)
                    newButtons.append(button)
                    buttonsWrapperView.addSubview(button)
                }
                buttons = newButtons
                
                if newButtons.count == 2 {
                    var views = [String : UIButton]()
                    let firstButton = newButtons.first!
                    let lastButton = newButtons.last!
                    firstButton.translatesAutoresizingMaskIntoConstraints = false
                    lastButton.translatesAutoresizingMaskIntoConstraints = false
                    views["button0"] = firstButton
                    views["button1"] = lastButton
                    
                    for constraints in ["V:|-spacing-[button0(AlertViewButtonHeight)]-0-|",
                                        "V:|-spacing-[button1(AlertViewButtonHeight)]-0-|",
                                        "H:|-0-[button0]-spacing-[button1(==button0)]-0-|"]
                    {
                        addConstraints(NSLayoutConstraint.constraintsWithVisualFormat(constraints, options: .DirectionLeadingToTrailing, metrics: ["AlertViewButtonHeight" : AlertViewButtonHeight, "spacing" : spacing], views: views))
                    }
                } else {
                    var views = [String : UIButton]()
                    var v_constraint = "V:|-spacing"
                    var h_constraint = ""
                    
                    var index = 0
                    buttons!.forEach({ (button) -> () in
                        button.translatesAutoresizingMaskIntoConstraints = false
                        if index == 0 {
                            v_constraint += "-[button\(index)(AlertViewButtonHeight)]-spacing"
                        } else {
                            v_constraint += "-[button\(index)(==button\(index-1))]-spacing"
                            
                        }
                        views["button\(index)"] = button
                        h_constraint = "H:|-0-[button\(index)]-0-|"
                        self.addConstraints(NSLayoutConstraint.constraintsWithVisualFormat(h_constraint, options: [.AlignAllCenterX], metrics: nil, views: views))
                        index+=1
                    })
                    v_constraint += "-|"
                    self.addConstraints(NSLayoutConstraint.constraintsWithVisualFormat(v_constraint, options: [.AlignAllLeading], metrics: ["AlertViewButtonHeight" : AlertViewButtonHeight, "spacing" : spacing], views: views))
                }
            }
        }
    }
    
    private func setupAppearance() {
        titleLabel?.font = appearance?.titleFont
        titleLabel?.textColor = appearance?.titleColor
        messageLabel?.font = appearance?.subtitleFont
        messageLabel?.textColor = appearance?.subtitleColor
        messageLabel.adjustsFontSizeToFitWidth = true
        buttonsWrapperView?.backgroundColor = appearance?.buttonsSeparatorColor
        if let cornerRaduis = appearance?.alertCornerRadius where cornerRaduis > 0 {
            layer.cornerRadius = cornerRaduis
            layer.masksToBounds = true
        }
        buttons?.forEach({ (button) in
            if button.style == AlertButtonStyle.Confirm.rawValue {
                button.setTitleColor(appearance?.confirmButtonColor, forState: UIControlState.Normal)
                button.titleLabel?.font = appearance?.confirmButtonFont
            } else if button.style == AlertButtonStyle.Cancel.rawValue {
                button.setTitleColor(appearance?.cancelButtonColor, forState: UIControlState.Normal)
                button.titleLabel?.font = appearance?.cancelButtonFont
            }
        })
    }
    
    override func willMoveToSuperview(newSuperview: UIView?) {
        super.willMoveToSuperview(newSuperview)
        if let _ = newSuperview {
            setupAppearance()
        }
    }
    
    /// Must invoke this method for custom content display!!!
    func addSubviewToCustomView(view: UIView, setUpConstraints: ((containerView: UIView) -> Void))
    {
        noCustomViewHeightConstraint.active = false
        customViewBottomConstraint.constant = 0
        customView.addSubview(view)
        setUpConstraints(containerView: customView)
    }

    // MARK: Layout
    
    override func layoutSubviews()
    {
        super.layoutSubviews()
        messageLabel?.preferredMaxLayoutWidth = messageLabel.bounds.width
        layoutIfNeeded()
    }
    
    // MARK: Action
    
    func buttonAction(sender: AlertButton)
    {
        guard let buttons = buttons,
            let index = buttons.indexOf(sender)
            else { return }
        
        controller?.dismiss(buttonIndex: index)
    }
    
    @IBAction func closeAction(sender: AnyObject) {
        controller?.dismiss(buttonIndex: -1)
    }
    
}
