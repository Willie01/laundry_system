//
//  AlertViewController.swift
//  AlertView
//
//  Created by paul on 15/11/30.
//  Copyright © 2015年 小普. All rights reserved.
//

import UIKit

class AlertViewController: UIViewController, UIViewControllerTransitioningDelegate {

    private(set) var alertView: AlertView!
    
    private(set) var centerYConstraint: NSLayoutConstraint?
    
    private var alertStyle: AlertStyle = .Presentation
    
    var tapDimmingViewToDismiss: Bool = false
    
    var didDismissClosure: ((buttonIndex: Int) -> Void)?
    
    var statusBarStyle: UIStatusBarStyle?
    var showStatusBar: Bool?
    
    override func preferredStatusBarStyle() -> UIStatusBarStyle {
        return statusBarStyle ?? .Default
    }
    
    override func prefersStatusBarHidden() -> Bool {
        return showStatusBar ?? true
    }
    
    // MARK: Override
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: NSBundle?)
    {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        commonInit()
    }

    required init?(coder aDecoder: NSCoder)
    {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit()
    {
        transitioningDelegate = self
        modalPresentationStyle = .Custom
        alertView = NSBundle.mainBundle().loadNibNamed("AlertView", owner: self, options: nil).first as! AlertView
        alertView.translatesAutoresizingMaskIntoConstraints = false
        alertView.controller = self
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.clearColor()
        view.addSubview(alertView)
        
        view.addConstraint(NSLayoutConstraint(item: view, attribute: .CenterX, relatedBy: .Equal, toItem: alertView, attribute: .CenterX, multiplier: 1.0, constant: 0))
        view.addConstraint(NSLayoutConstraint(item: alertView, attribute: .Width, relatedBy: .Equal, toItem: nil, attribute: .NotAnAttribute, multiplier: 1.0, constant: 300.0))
        centerYConstraint = NSLayoutConstraint(item: view, attribute: .CenterY, relatedBy: .Equal, toItem: alertView, attribute: .CenterY, multiplier: 1.0, constant: 0)
        view.addConstraint(centerYConstraint!)
        view.userInteractionEnabled = true
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(tapAction))
        view.addGestureRecognizer(tapGesture)
    }
    
    func tapAction() {
        if self.tapDimmingViewToDismiss {
            self.dismissViewControllerAnimated(true, completion: nil)
        }
    }
    
    // MARK: Class Method
    
    class func show(title title: String? = nil, message: String? = nil, image: UIImage? = nil, style: AlertStyle = .System, tapDimmingViewToDismiss: Bool = false, showCloseButton: Bool = false, appearance: AlertViewAppearance = DefaultAlertViewAppearance(), actions: [AlertAction] = [AlertAction.defaultAction], didDismiss: ((buttonIndex: Int) -> Void)? = nil)
    {
        let alertViewController = AlertViewController()
        let alertView = alertViewController.alertView
        alertView.appearance = appearance
        alertView.setNeedsUpdateConstraints()
        alertView.updateConstraintsIfNeeded()
        alertView.title = title
        alertView.message = message
        alertView.image = image
        alertView.closeButton.hidden = !showCloseButton
        alertView.alertActions = actions
        alertViewController.alertStyle = style
        alertViewController.tapDimmingViewToDismiss = tapDimmingViewToDismiss
        alertViewController.didDismissClosure = didDismiss
        if let fromVc = UIViewController.topViewController() {
            alertViewController.showStatusBar = fromVc.prefersStatusBarHidden()
            alertViewController.statusBarStyle = fromVc.preferredStatusBarStyle()
        }
        alertViewController.present()
    }
    
    class func showCustomView(customView: UIView, title: String? = nil, message: String?, image: UIImage? = nil, style: AlertStyle = .Presentation, appearance: AlertViewAppearance = DefaultAlertViewAppearance(), showCloseButton: Bool = false, actions: [AlertAction] = [AlertAction.defaultAction], setupConstraint: (containerView: UIView) -> Void, didDismiss: ((buttonIndex: Int) -> Void)? = nil)
    {
        let alertViewController = AlertViewController()
        let alertView = alertViewController.alertView
        alertView.appearance = appearance
        alertView.addSubviewToCustomView(customView, setUpConstraints: setupConstraint)
        alertView.title = title
        alertView.message = message
        alertView.image = image
        alertView.closeButton.hidden = !showCloseButton
        alertView.alertActions = actions
        alertViewController.alertStyle = style
        alertViewController.didDismissClosure = didDismiss
        if let fromVc = UIViewController.topViewController() {
            alertViewController.showStatusBar = fromVc.prefersStatusBarHidden()
            alertViewController.statusBarStyle = fromVc.preferredStatusBarStyle()
        }
        alertViewController.present()
    }
    
    // MARK: Instance Method
    
    func present(animated: Bool = true, completion: (() -> Void)? = nil)
    {
        UIViewController.topViewController()?.presentViewController(self, animated: animated, completion: completion)
    }
    
    func dismiss(animated: Bool = true, buttonIndex: Int, completion: (() -> Void)? = nil)
    {
        dismissViewControllerAnimated(animated) { () -> Void in
            completion?()
            self.didDismissClosure?(buttonIndex: buttonIndex)
        }
    }
    
    // MARK: UIViewControllerTransitioningDelegate
    
    func animationControllerForPresentedController(presented: UIViewController, presentingController presenting: UIViewController, sourceController source: UIViewController) -> UIViewControllerAnimatedTransitioning?
    {
        switch alertStyle {
        case .Presentation:
            return nil
        case .System:
            let animator = AlertAnimator()
            animator.isPresentation = true
            return animator
        }
    }
    
    func animationControllerForDismissedController(dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning?
    {
        switch alertStyle {
        case .Presentation:
            return nil
        case .System:
            return AlertAnimator()
        }
    }
    
    func presentationControllerForPresentedViewController(presented: UIViewController, presentingViewController presenting: UIViewController, sourceViewController source: UIViewController) -> UIPresentationController?
    {
        return PresentationController(presentedViewController: presented, presentingViewController: presenting)
    }
}

