//
//  rootType.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/3/19.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import Foundation

enum rootType {
    case Tab
    case Login
}
