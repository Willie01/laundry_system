//
//  GlobalConstants.swift
//  Client
//
//  Created by Shannon Wu on 11/12/15.
//  Copyright © 2015 36Kr. All rights reserved.
//

import Foundation
import UIKit

func KRLog(msg: String) {
    #if DEBUG
        LogUtil.log(msg)
    #endif
}

struct Constants {
    
    struct Color {
        
        static var bgColor: UIColor {
            return UIColor(hex: 0xf2f4f5)
        }
        
        static var containerBgColor: UIColor {
            return UIColor(hex: 0xf9f9f9)
        }
            
        static var navBarColor: UIColor {
            return UIColor(hex: 0xffffff)
        }
        
        static var title: UIColor {
            return UIColor(hex: 0x222c38)
        }
        
        static var content: UIColor {
            return UIColor(hex: 0x5a626d)
        }
        
        static var prompt: UIColor {
            return UIColor(hex: 0x969fa9)
        }
        
        static var divider: UIColor {
            return UIColor(hex: 0xe7e7e7)
        }
        
        static var empty: UIColor {
            return UIColor(hex: 0xcccccc)
        }
        
        static var tabbarSelect: UIColor {
            return UIColor(hex: 0x4285f4)
        }
        
        static var tabbarNormal: UIColor {
            return UIColor(hex: 0x969fa9)
        }
        
        static var success: UIColor {
            return UIColor(hex: 0x31c27c)
        }
        
        static var failure: UIColor {
            return UIColor(hex: 0xf0633d)
        }
        
        static var auxiliary: UIColor {
            return UIColor(hex: 0xf8627e)
        }
        
        static var wechat: UIColor {
            return UIColor(hex: 0x9ea6b0)
        }
        
        static var wechatBtn: UIColor {
            return UIColor(hex: 0x58cd94)
        }
        
        static var tableViewHightColor: UIColor {
            return UIColor(hex: 0xd9d9d9)
        }
        
        static var chatIncomingSelectedColor: UIColor {
            return UIColor(hex: 0x0093ca)
        }
        
        static var chatOutgoingSelectedColor: UIColor {
            return UIColor(hex: 0xaee0f8)
        }
        
        static var indicatorView_current: UIColor {
            return UIColor(hex: 0x7080a4)
        }
        
        static var indicatorView_normail: UIColor {
            return UIColor(hex: 0x3f4a66)
        }
        
        static var launchBtnFastText: UIColor {
            return UIColor(hex: 0xe5edff)
        }
        
        static var launchBtnBg: UIColor {
            return UIColor(hex: 0x63759d)
        }
        
        static var launchBtnText: UIColor {
            return UIColor(hex: 0x63759d)
        }
        
    }
    
    struct Layout {
        static var onePixel: CGFloat {
            return 1.0 / UIScreen.mainScreen().scale
        }
        
        static var normalLogoSize: CGSize {
            return CGSizeMake(50, 50)
        }
        
        static var bigLogoSize: CGSize {
            return CGSizeMake(67, 67)
        }
        
        static var navBarHeight: CGFloat {
            return 64
        }
        
        static var tabBarHeight: CGFloat {
            return 49
        }
        
        static var statusBarHeight: CGFloat {
            return 20.0
        }
        
        static var screenWidth: CGFloat {
            return UIScreen.mainScreen().bounds.width
        }
        
        static var screenHeight: CGFloat {
            return UIScreen.mainScreen().bounds.height
        }
    }
    
    struct Font {
        static var headline: UIFont {
            return UIFont.systemFontOfSize(18)
        }
        static var boldHeadline: UIFont {
            return UIFont.systemFontOfSize(18.0, weight: UIFontWeightMedium)
        }
        
        static var subheadline: UIFont {
            return UIFont.systemFontOfSize(17)
        }
        
        static var boldSubheadline: UIFont {
            return UIFont.systemFontOfSize(17, weight: UIFontWeightMedium)
        }
        
        static var caption1: UIFont {
            return UIFont.systemFontOfSize(15)
        }
        
        static var boldCaption1: UIFont {
            return UIFont.systemFontOfSize(15, weight: UIFontWeightMedium)
        }
        
        static var body: UIFont {
            return UIFont.systemFontOfSize(14)
        }
        
        static var boldBody: UIFont {
            return UIFont.systemFontOfSize(14, weight: UIFontWeightMedium)
        }
        
        static var caption2: UIFont {
            return UIFont.systemFontOfSize(13)
        }
        
        static var footnote: UIFont {
            return UIFont.systemFontOfSize(11)
        }
        
        static var content: UIFont {
            return UIFont.systemFontOfSize(16)
        }
        
        static var boldContent: UIFont {
            return UIFont.systemFontOfSize(16, weight: UIFontWeightMedium)
        }
        
        static var paragraphStyle: NSMutableParagraphStyle {
            let style = NSMutableParagraphStyle()
            style.lineSpacing = 5.0
            style.paragraphSpacing = 10.0
            return style
        }
    }
    
    
    struct Network {
        static let Domain = "www.tchautchau.cn"
    }
    
    struct TipText {
        static let NetworkError = "网络不给力"
    }
    
    static var dateFormat: String {
        return "yyyy-MM-dd HH:mm:ss"
    }
    
}

func fibonacci(number: Int) -> Int {
    if number <= 1 {
        return number
    } else {
        return fibonacci(number - 1) + fibonacci(number - 2)
    }
}

func getSpecificStr(regex: String,input: String) -> String? {
    do {
        
        let regex = try NSRegularExpression(pattern: regex, options: NSRegularExpressionOptions.CaseInsensitive)
        let matches = regex.matchesInString(input, options: [], range: NSMakeRange(0, input.characters.count))
        
        if let match = matches.first {
            let range = match.rangeAtIndex(1)
            if let swiftRange = rangeFromNSRange(range, forString: input) {
                let result = input.substringWithRange(swiftRange)
                return result
            }
        }
    } catch {
        // regex was bad!
    }
    return nil
}

func rangeFromNSRange(nsRange: NSRange, forString str: String) -> Range<String.Index>? {
    let fromUTF16 = str.utf16.startIndex.advancedBy(nsRange.location, limit: str.utf16.endIndex)
    let toUTF16 = fromUTF16.advancedBy(nsRange.length, limit: str.utf16.endIndex)
    
    if let from = String.Index(fromUTF16, within: str),
        let to = String.Index(toUTF16, within: str) {
        return from ..< to
    }
    
    return nil
}


func blur(image: UIImage, blurRadius: CGFloat) -> UIImage {
    var isSimulator: Bool {
        #if (arch(i386) || arch(x86_64)) && os(iOS)
            return true
        #else
            return false
        #endif
    }
    if isSimulator {
        return image
    }
    let inputImage = CIImage(image: image)
    let filter = CIFilter(name: "CIGaussianBlur")!
    filter.setValue(inputImage, forKey: kCIInputImageKey)
    filter.setValue(blurRadius, forKey: kCIInputRadiusKey)
    let context = CIContext(options: nil)
    let outputImage = filter.outputImage!
    let outputImageRef = context.createCGImage(outputImage, fromRect: outputImage.extent)
    let result = UIImage(CGImage: outputImageRef)
    return result
}

// MARK: - Fix Crash Work around
extension UIAlertController {
    public override func supportedInterfaceOrientations() -> UIInterfaceOrientationMask {
        return UIInterfaceOrientationMask.Portrait
    }
    public override func shouldAutorotate() -> Bool {
        return false
    }
}

extension NSString {
    var stringToDic : NSDictionary{
        var returnData:NSDictionary? = nil;
        var dataWeb:NSData = self.dataUsingEncoding(NSUTF8StringEncoding)!
        
        do {
//            let JSONDecodeObject = try NSJSONSerialization.JSONObjectWithData(dataWeb, options: .AllowFragments)
//            guard let JSONObject = JSONDecodeObject as? [NSDictionary] else { return  }
            let json = try NSJSONSerialization.JSONObjectWithData(dataWeb, options: .AllowFragments)
            if(json.count != 0 && json.count != nil ){
                returnData = json as? NSDictionary
            }
        } catch {
            
        }
//        if let json:AnyObject = try NSJSONSerialization.JSONObjectWithData(dataWeb, options: NSJSONReadingOptions()){
//            if(json.count != 0 && json.count != nil ){
//                returnData = json as? NSDictionary
//            }
//        }
        return returnData ?? NSDictionary()
    }
    
    var stringToArr : NSArray {
        var returnData:NSArray? = nil;
        var dataWeb:NSData = self.dataUsingEncoding(NSUTF8StringEncoding)!
        
        do {
            //            let JSONDecodeObject = try NSJSONSerialization.JSONObjectWithData(dataWeb, options: .AllowFragments)
            //            guard let JSONObject = JSONDecodeObject as? [NSDictionary] else { return  }
            let json = try NSJSONSerialization.JSONObjectWithData(dataWeb, options: .AllowFragments)
            if(json.count != 0 && json.count != nil ){
                returnData = json as? NSArray
            }
        } catch {
            
        }
        //        if let json:AnyObject = try NSJSONSerialization.JSONObjectWithData(dataWeb, options: NSJSONReadingOptions()){
        //            if(json.count != 0 && json.count != nil ){
        //                returnData = json as? NSDictionary
        //            }
        //        }
        return returnData ?? []
    }
}
