//import Foundation
//
//public extension String {
//
//    public var localized: String {
//        return localizedString(self)
//    }
//    
//    public var securedURLString: String {
//        if let url = URLValue {
//            //如果没有scheme，默认当http处理，譬如www.baidu.com
//            if url.scheme == "" {
//                return "https://" + self
//            } else if url.scheme == "http" {
//                return replace("http://", with: "https://")
//            }
//        }
//        return self
//    }
//    
//    //版本比较
//    func isOlderVersionThan(otherVersion: String) -> Bool {
//        return self.compare(otherVersion, options: NSStringCompareOptions.NumericSearch) == NSComparisonResult.OrderedAscending
//    }
//    
//    func isNewerVersionThan(otherVersion: String) -> Bool {
//        return self.compare(otherVersion, options: NSStringCompareOptions.NumericSearch) == NSComparisonResult.OrderedDescending
//    }
//}
