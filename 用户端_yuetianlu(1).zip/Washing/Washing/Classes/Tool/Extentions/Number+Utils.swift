//
//  Int+Utils.swift
//  Client
//
//  Created by Shannon Wu on 12/8/15.
//  Copyright © 2015 36Kr. All rights reserved.
//

import Foundation

let doubleDateFormmater: NSDateFormatter =  {
    let formatter = NSDateFormatter()
    return formatter
}()

extension Int {
    var stringValue: String {
        return "\(self)"
    }
    
    var readableString: String {
        if self < 0 {
            return ""
        }
        let base = 10000
        if self >= base {
            if self % base == 0 {
                return "\(self/base)万"
            }
            return String(format: "%.1f万", Double(self)/Double(base))
        }
        return "\(self)"
    }
    
}


extension Double {
    // 截取到小数点后几位
    func format(f: Int) -> String {
        return NSString(format: "%.\(f)f", self) as String
    }
    
    
    var dateStringRepresentationShortNews: String {
        let oldDate = NSDate(timeIntervalSince1970: self)
        doubleDateFormmater.dateFormat = "HH:mm"
        return doubleDateFormmater.stringFromDate(oldDate)
    }
    
    var dateStringRepresentation: String {
        let calender = NSCalendar.currentCalendar()
        let now = NSDate()
        let oldDate = NSDate(timeIntervalSince1970: self)
        if calender.isDateInToday(oldDate) {
            let timeInterval = now.timeIntervalSince1970 - self
            if timeInterval < 60 {
                return "刚刚"
            } else if timeInterval < 60 * 60 {
                return "\(Int(timeInterval/60))分钟前"
            } else {
                return "\(Int(timeInterval/3600))小时前"
            }
        } else if calender.isDateInYesterday(oldDate) {
            return "昨天"
        } else {
            doubleDateFormmater.dateFormat = "yyyy-MM-dd"
            return doubleDateFormmater.stringFromDate(oldDate)
        }
    }
    
}
