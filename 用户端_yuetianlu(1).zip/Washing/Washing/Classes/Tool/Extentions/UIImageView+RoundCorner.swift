//
//  UIImageView+RoundCorner.swift
//  Client
//
//  Created by paul on 16/8/1.
//  Copyright © 2016年 36Kr. All rights reserved.
//

import Foundation

extension UIImageView {
 
    func transformToRoundCorner(radius: CGFloat) {
        let maskLayer = CAShapeLayer()
        let roundedPath = UIBezierPath(roundedRect: bounds, cornerRadius: radius)
        maskLayer.path = roundedPath.CGPath
        self.layer.mask = maskLayer;
    }
    
}