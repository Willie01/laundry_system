
//  UIImageView+Utils.swift
//  Client
//
//  Created by 孟冰川 on 15/12/14.
//  Copyright © 2015年 36Kr. All rights reserved.


import UIKit
import YYWebImage

let grayDefaultImage = UIImage(color: UIColor(hex: 0xf0f0f0))

extension UIImageView {
    
    func transformToCycle(radius: CGFloat){
        let maskLayer = CAShapeLayer()
        let roundedPath = UIBezierPath(arcCenter: CGPointMake(radius, radius), radius: radius, startAngle: 0, endAngle: CGFloat(M_PI * 2.0), clockwise: true)
        maskLayer.path = roundedPath.CGPath
        self.layer.mask = maskLayer;
    }
    
    func setImageWithURL(url: NSURL?, defaultLogo: UIImage? = grayDefaultImage, completion: (UIImage? -> Void)? = nil) {
        var formatURL = url
        if let url = url {
            if url.scheme == "http" {
                formatURL = NSURL(string: url.absoluteString.replace("http://", with: "https://"))
            }
        }
        yy_setImageWithURL(formatURL, placeholder: defaultLogo, options: .SetImageWithFadeAnimation) { (image, url, type, state, error) in
            completion?(image)
        }
    }
    
}

func downloadImageWithURL(URL: NSURL, options: YYWebImageOptions = YYWebImageOptions.AllowBackgroundTask, progress: YYWebImageProgressBlock? = nil, transform: YYWebImageTransformBlock? = nil, completion: YYWebImageCompletionBlock?) {
    var formatURL = URL
    if URL.scheme == "http" {
        if let validURL = NSURL(string: URL.absoluteString.replace("http://", with: "https://")) {
            formatURL = validURL
        }
    }
    YYWebImageManager.sharedManager().requestImageWithURL(formatURL, options: options, progress: progress, transform: transform, completion: completion)
}