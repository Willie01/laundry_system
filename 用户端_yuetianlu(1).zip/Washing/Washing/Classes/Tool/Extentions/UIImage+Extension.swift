import UIKit

public extension UIImage {

  public convenience init(color: UIColor, size: CGSize = CGSize(width: 1, height: 1)) {
    let rect = CGRect(origin: CGPointZero, size: size)
    UIGraphicsBeginImageContextWithOptions(size, true, 1)
    color.setFill()
    UIRectFill(rect)
    let image = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()

    self.init(CGImage: image.CGImage!)
  }

  public var hasContent: Bool {
    return CGImage != nil || CIImage != nil
  }
    
    func fixOrientation() -> UIImage? {
        if imageOrientation == UIImageOrientation.Up {
            return self
        }
        
        var transform = CGAffineTransformIdentity
        
        switch imageOrientation {
        case UIImageOrientation.Down:
            fallthrough
        case UIImageOrientation.DownMirrored:
            transform = CGAffineTransformTranslate(transform, size.width, size.height)
            transform = CGAffineTransformRotate(transform, CGFloat(M_PI))
        case UIImageOrientation.Left:
            fallthrough
        case UIImageOrientation.LeftMirrored:
            transform = CGAffineTransformTranslate(transform, size.width, 0)
            transform = CGAffineTransformRotate(transform, CGFloat(M_PI_2))
        case UIImageOrientation.Right:
            fallthrough
        case UIImageOrientation.RightMirrored:
            transform = CGAffineTransformTranslate(transform, 0, size.height)
            transform = CGAffineTransformRotate(transform, CGFloat(-M_PI_2))
        case UIImageOrientation.Up:
            fallthrough
        case UIImageOrientation.UpMirrored:
            fallthrough
        default:
            ()
        }
        
        switch imageOrientation {
        case UIImageOrientation.UpMirrored:
            fallthrough
        case UIImageOrientation.DownMirrored:
            transform = CGAffineTransformTranslate(transform, size.width, 0)
            transform = CGAffineTransformScale(transform, -1, 1)
        case UIImageOrientation.LeftMirrored:
            fallthrough
        case UIImageOrientation.RightMirrored:
            transform = CGAffineTransformTranslate(transform, size.height, 0)
            transform = CGAffineTransformScale(transform, -1, 1)
        case UIImageOrientation.Up:
            fallthrough
        case UIImageOrientation.Down:
            fallthrough
        case UIImageOrientation.Left:
            fallthrough
        case UIImageOrientation.Right:
            fallthrough
        default:
            ()
        }
        
        let ctx = CGBitmapContextCreate(nil, Int(size.width), Int(size.height), CGImageGetBitsPerComponent(self.CGImage), 0, CGImageGetColorSpace(self.CGImage), CGImageGetBitmapInfo(self.CGImage).rawValue)
        CGContextConcatCTM(ctx, transform)
        
        switch imageOrientation {
        case UIImageOrientation.Left:
            fallthrough
        case UIImageOrientation.LeftMirrored:
            fallthrough
        case UIImageOrientation.Right:
            fallthrough
        case UIImageOrientation.RightMirrored:
            CGContextDrawImage(ctx, CGRect(x: 0, y: 0, width: size.height, height: size.width), self.CGImage)
        default:
            CGContextDrawImage(ctx, CGRect(x: 0, y: 0, width: size.width, height: size.height), CGImage)
        }
        
        if let cgImage = CGBitmapContextCreateImage(ctx) {
            return UIImage(CGImage: cgImage)
        }
        return nil
    }
}
