//
//  UIView+Snapshot.swift
//  Client
//
//  Created by aidenluo on 8/19/16.
//  Copyright © 2016 36Kr. All rights reserved.
//

import Foundation
import UIKit

extension UIView {
    
    func snapshot(scale: CGFloat = UIScreen.mainScreen().scale) -> UIImage {
        UIGraphicsBeginImageContextWithOptions(bounds.size, opaque, scale);
        drawViewHierarchyInRect(bounds, afterScreenUpdates: true)
        let snapshot = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return snapshot
    }
    
}