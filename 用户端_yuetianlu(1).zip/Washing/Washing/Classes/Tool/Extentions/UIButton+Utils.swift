//
//  UIButton+Utils.swift
//  Client
//
//  Created by aidenluo on 8/4/16.
//  Copyright © 2016 36Kr. All rights reserved.
//

import Foundation
import UIKit

extension UIButton {
    
    func alignImageAndTitleVertically(padding: CGFloat = 6.0) {
        let imageSize = self.imageView!.frame.size
        let titleSize = self.titleLabel!.frame.size
        let totalHeight = imageSize.height + titleSize.height + padding
        
        self.imageEdgeInsets = UIEdgeInsets(
            top: -(totalHeight - imageSize.height),
            left: 0,
            bottom: 0,
            right: -titleSize.width
        )
        
        self.titleEdgeInsets = UIEdgeInsets(
            top: 0,
            left: -imageSize.width,
            bottom: -(totalHeight - titleSize.height),
            right: 0
        )
    }
    
}

class CustomeHitAreaButton: UIButton {
    
    var hitTestEdgeInsets: UIEdgeInsets = UIEdgeInsetsZero
    
    override func pointInside(point: CGPoint, withEvent event: UIEvent?) -> Bool {
        if UIEdgeInsetsEqualToEdgeInsets(hitTestEdgeInsets, UIEdgeInsetsZero) || !enabled || hidden {
            return super.pointInside(point, withEvent: event)
        }
        let relativeFrame = bounds
        let hitFrame = UIEdgeInsetsInsetRect(relativeFrame, hitTestEdgeInsets)
        return CGRectContainsPoint(hitFrame, point)
    }
    
}