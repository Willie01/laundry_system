//
//  GoodsTableViewCell.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/3/19.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit

class GoodsTableViewCell: UITableViewCell {

    @IBOutlet weak var bgImageView: UIImageView!
    
    @IBOutlet weak var goodsNameLabel: UILabel!
    
    @IBOutlet weak var priceLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()        // Initialization code
    }
    
    func setData(model: GoodsModel) {
        if let logo = model.logo {
            bgImageView.setImageWithURL(NSURL(string: "http://www.tchautchau.cn/\(logo)"), placeholderImage: nil)
        }
        goodsNameLabel.text = model.product_name
        if let price = model.price {
            priceLabel.text = "价格：\(price)元"
        }

    }
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
