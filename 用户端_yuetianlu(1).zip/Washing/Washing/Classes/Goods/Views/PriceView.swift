//
//  PriceView.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/3/21.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit

class PriceView: UIView {

  
    @IBOutlet weak var orderButton: UIButton!
    
    var didClick: (Void -> Void)?
    
    @IBAction func payClick(sender: AnyObject) {
        didClick?()
    }
    
    class func instance() -> PriceView{
        let priceView = NSBundle.mainBundle().loadNibNamed("PriceView", owner: self, options: nil).first as!PriceView
        return priceView
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.backgroundColor = UIColor.groupTableViewBackgroundColor()
        orderButton.backgroundColor = UIColor(hex: 0x4285F4)
    }
}
