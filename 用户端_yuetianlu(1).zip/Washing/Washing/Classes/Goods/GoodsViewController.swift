//
//  OrderViewController.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/3/14.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit

class GoodsViewController: BaseTableViewController {
    
    var cateId: Int?
    var categoryData: [HomePageModel] = []
    var cityID: Int = 1
    private var data: [GoodsModel] = []
    let Width = UIScreen.mainScreen().bounds.width
    let Height = UIScreen.mainScreen().bounds.height
    private var priceView = PriceView.instance()
    private var price: Int = 0
    
    deinit {
        
    }
    
    override func registerCell() {
        tableView.registerNib(UINib(nibName: "GoodsTableViewCell", bundle: nil), forCellReuseIdentifier: "GoodsTableViewCell")
    }
    
    override func refreshData() {
        guard let id = cateId else {
            return
        }
        ///api/cities/:city_id/categories/:category_id/products_cities
        HttpSwift.request("get", url: "http://www.tchautchau.cn/api/cities/\(cityID)/categories/\(id)/products_cities") { (data, response, error) in
            print(data)
            if let data = data {
                
                let arr = data.stringToArr
                for dic in arr {
                    let model = GoodsModel(dict: dic as! [String : AnyObject])
                    self.data.append(model)
                }

                dispatch_async(dispatch_get_main_queue(), {
                    self.tableView.reloadData()
                })
                print(arr)
                
            }
        }

    }
    
    override func loadMoreData() {
        
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        tableView.frame = CGRect(x: 0, y: 0, width: view.width, height: view.height-60)
        priceView.frame = CGRect(x: 0, y: view.height - 60, width: Width, height: 60)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "商品"
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.estimatedRowHeight = 60
        view.addSubview(priceView)
        priceView.didClick = {
            let controller = AppointmentViewController()
            controller.categoryData = self.categoryData
            controller.orderPrice = self.price
            controller.cityID = self.cityID
            self.navigationController?.pushViewController(controller, animated: true)
        }
        // view.addSubview(tableView)
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

extension GoodsViewController {
    
    // MARK: UITableViewDataSource
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 140
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("GoodsTableViewCell", forIndexPath: indexPath) as! GoodsTableViewCell

        let model = data[indexPath.row]
        cell.setData(model)
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        guard indexPath.row < data.count else {
            return
        }
                
    }
    
}
