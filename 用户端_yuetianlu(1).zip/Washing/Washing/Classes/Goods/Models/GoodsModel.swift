//
//  GoodsModel.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/4/13.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import Foundation

class GoodsModel: NSObject {
    var id : Int = 0
    var category_id: Int = 0
    var product_name: String?
    var logo: String?
    var price: String?
    init(dict : [String : AnyObject]) {
        super.init()
        
        //kvo赋值
        setValuesForKeysWithDictionary(dict)
        //setValuesForKeys(dict)
        
    }
    
    override func setValue(value: AnyObject?, forUndefinedKey key: String) {
        
    }
    
}