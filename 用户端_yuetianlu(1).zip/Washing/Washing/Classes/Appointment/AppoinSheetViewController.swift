//
//  AppoinSheetViewController.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/4/21.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit

class AppoinSheetViewController: UIViewController, UIViewControllerTransitioningDelegate {

    var pickerView: PickerDateView = {
        let view = PickerDateView()
        view.backgroundColor = UIColor.whiteColor()
        return view
    }()
    
    var categoryView: CategoriesView = {
        let view = CategoriesView()
        view.backgroundColor = UIColor.whiteColor()
        return view
    }()
    var saveSuccessClosure: (NSDate -> Void)?
    var saveNameSuccessClosure: ([HomePageModel] -> Void)?

    var type: String?
    
    init() {
        super.init(nibName: nil, bundle: nil)
        transitioningDelegate = self
        modalPresentationStyle = .Custom
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func present(animated: Bool = true, completion: (() -> Void)? = nil) {
        UIViewController.topMostViewController()?.presentViewController(self, animated: animated, completion: completion)
    }
    
    // MARK: UIViewControllerTransitioningDelegate
    
    func presentationControllerForPresentedViewController(presented: UIViewController, presentingViewController presenting: UIViewController, sourceViewController source: UIViewController) -> UIPresentationController? {
        return PresentationController(presentedViewController: presented, presentingViewController: presenting)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let type = type {
            if type == "time" {
                view.addSubview(pickerView)
                pickerView.cancelClosure = {
                    self.dismissViewControllerAnimated(true, completion: nil)
                }
                pickerView.saveClosure = { (date) in
                    self.saveSuccessClosure?(date)
                    self.dismissViewControllerAnimated(true, completion: nil)
                }

            } else {
                view.addSubview(categoryView)
                categoryView.cancelClosure = {
                    self.dismissViewControllerAnimated(true, completion: nil)
                }
                categoryView.saveClosure = { (data) in
                    self.saveNameSuccessClosure?(data)
                    self.dismissViewControllerAnimated(true, completion: nil)
                }
            }
        }
                // Do any additional setup after loading the view.
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if let type = type {
            if type == "time" {
                pickerView.left = 0
                pickerView.bottom = view.bottom
                pickerView.width = view.width
                pickerView.height = 250
            } else {
                categoryView.left = 0
                categoryView.bottom = view.bottom
                categoryView.width = view.width
                categoryView.height = 250
            }
        }

    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    class func show(type: String, saveSuccessClosure: (NSDate -> Void)) {
        let controller = AppoinSheetViewController()
        controller.type = type
        controller.saveSuccessClosure = saveSuccessClosure
        controller.present()
    }
    
    class func showName(type: String, data: [HomePageModel], saveSuccessClosure: ([HomePageModel] -> Void)) {
        let controller = AppoinSheetViewController()
        controller.type = type
        controller.categoryView.categoryData = data
        controller.saveNameSuccessClosure = saveSuccessClosure
        controller.present()
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        dismissViewControllerAnimated(true, completion: nil)
    }

}
