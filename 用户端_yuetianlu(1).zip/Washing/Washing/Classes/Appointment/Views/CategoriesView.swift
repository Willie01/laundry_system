//
//  CategoriesView.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/4/21.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit

class CategoriesView: UIView {
    
    var categoryData: [HomePageModel] = [] {
        didSet {
            createUI()
        }
    }
    private var pickerView: UIView = {
        let view = UIView()
        return view
    }()
    
    var cancelClosure: (Void -> Void)?
    var saveClosure: ([HomePageModel] -> Void)?
    private var selectData: [HomePageModel] = []
    
    private var categoryButton: UIButton = {
        let button = UIButton()
        button.setBackgroundImage(UIImage.init(color: UIColor.whiteColor()), forState: .Normal)
        button.setBackgroundImage(UIImage.init(color: UIColor(hex: 0x4285F4)), forState: .Selected)
        button.setTitleColor(UIColor(hex: 0x4285F4), forState: .Normal)
        button.setTitleColor(UIColor.whiteColor(), forState: .Selected)
        button.layer.borderWidth = 0.5
        button.layer.borderColor = UIColor.grayColor().CGColor
        return button
    }()
    
    private var toolView = UIToolbar()

    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(toolView)
        addSubview(pickerView)
    }
    
    private func createUI() {
        toolView.backgroundColor = UIColor.whiteColor()
        let cancelButton = UIBarButtonItem(title: "取消", style: .Plain, target: self, action: #selector(cancelClick))
        let gapButton = UIBarButtonItem(barButtonSystemItem: .FlexibleSpace, target: nil, action: nil)
        let saveButton = UIBarButtonItem(title: "保存", style: .Plain, target: self, action: #selector(saveClick))
        toolView.setItems([cancelButton, gapButton, saveButton], animated: false)
        
        for num in 0..<categoryData.count {
            let model = categoryData[num]
            let button = UIButton()
            button.setBackgroundImage(UIImage.init(color: UIColor.whiteColor()), forState: .Normal)
            button.setBackgroundImage(UIImage.init(color: UIColor(hex: 0x4285F4)), forState: .Selected)
            button.setTitleColor(UIColor(hex: 0x4285F4), forState: .Normal)
            button.setTitleColor(UIColor.whiteColor(), forState: .Selected)
            button.layer.borderWidth = 1
            button.selected = false
            button.layer.borderColor = UIColor.grayColor().CGColor
            if let name = model.category_name {
                button.setTitle(name, forState: .Normal)
            }
            button.tag = num
            button.frame = CGRect(x: CGFloat(num % 3) * (Constants.Layout.screenWidth / 3), y: CGFloat(num / 3 * 100) + 3, width: Constants.Layout.screenWidth / 3, height: 100)
            button.addTarget(self, action: #selector(ValueChanged(_:)), forControlEvents: .TouchUpInside)
            pickerView.addSubview(button)
        }
    }
    
    func ValueChanged(sender: UIButton) {
        sender.selected = !sender.selected
        if sender.selected {
            selectData.append(categoryData[sender.tag])

        } else {
            for num in 0..<selectData.count {
                let model = selectData[num]
                if model == categoryData[sender.tag] {
                    selectData.removeAtIndex(num)
                    return
                }
            }
        }
    }
    
    func cancelClick() {
        cancelClosure?()
    }
    
    func saveClick() {
        for model in selectData {
            print(model.category_name)
        }
        saveClosure?(selectData)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        toolView.frame = CGRect(x: 0, y: 0, width: width, height: 44)
        pickerView.frame = CGRect(x: 0, y: 44, width: width, height: 206)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
