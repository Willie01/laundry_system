//
//  NameTableViewCell.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/4/19.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit

class NameTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var contentLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        createUI()
    }

    private func createUI() {
        self.layer.borderWidth = 1
        self.layer.borderColor = UIColor(hex: 0x4285F4).CGColor
        titleLabel.textColor = UIColor(hex: 0x464C56)
        titleLabel.font = UIFont.systemFontOfSize(16.0, weight: UIFontWeightMedium)
        contentLabel.textColor = UIColor(hex: 0x464C56)
        contentLabel.font = UIFont.systemFontOfSize(16.0)
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
