//
//  DescriptionTableViewCell.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/4/19.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit

class DescriptionTableViewCell: UITableViewCell {

    @IBOutlet weak var oneLabel: UILabel!
    
    @IBOutlet weak var secondLabel: UILabel!
    
    @IBOutlet weak var orderButton: UIButton!
    
    var didOrderClick: (Void -> Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        createUI()
    }
    
    private func createUI() {
        oneLabel.textColor = UIColor(hex: 0x464C56)
        oneLabel.font = UIFont.systemFontOfSize(15.0)
        secondLabel.textColor = UIColor(hex: 0x464C56)
        secondLabel.font = UIFont.systemFontOfSize(15.0)
        orderButton.layer.masksToBounds = true
        orderButton.layer.cornerRadius = 5
//        orderButton.layer.borderWidth = 1
//        orderButton.layer.borderColor = UIColor(hex: 0x4285F4).CGColor
        orderButton.backgroundColor = UIColor(hex: 0x4285F4)
        orderButton.setTitleColor(UIColor.whiteColor(), forState: .Normal)
    }
    
    @IBAction func orderAction(sender: AnyObject) {
        didOrderClick?()
    }
    

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
