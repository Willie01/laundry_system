//
//  ProfileDatePickerView.swift
//  Client
//
//  Created by BJQXDN0527 on 2017/4/14.
//  Copyright © 2017年 36Kr. All rights reserved.
//

import UIKit

class PickerDateView: UIView {
    
    var pickerView: UIDatePicker = {
        let pickerView = UIDatePicker()
        pickerView.datePickerMode = UIDatePickerMode.DateAndTime
        pickerView.locale = NSLocale.init(localeIdentifier: "zh_CN")
        let formatter = NSDateFormatter()
        formatter.dateFormat = Constants.dateFormat
        pickerView.minimumDate = NSDate()
        pickerView.maximumDate = NSDate().nextSevenDay
        return pickerView
    }()
    private var toolView = UIToolbar()
    private let formatter: NSDateFormatter = {
        let formatter = NSDateFormatter()
        formatter.dateFormat = Constants.dateFormat
        return formatter
    }()
    var cancelClosure: (Void -> Void)?
    var saveClosure: (NSDate -> Void)?
    var selectDate: NSDate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(toolView)
        addSubview(pickerView)
        pickerView.addTarget(self, action: #selector(dateValueChangedAction), forControlEvents: .ValueChanged)
        createUI()
        selectDate = NSDate()
    }
    
    private func createData() {
     
    }
    
    private func createUI() {
        toolView.backgroundColor = UIColor.grayColor()
        let cancelButton = UIBarButtonItem(title: "取消", style: .Plain, target: self, action: #selector(cancelClick))
        let gapButton = UIBarButtonItem(barButtonSystemItem: .FlexibleSpace, target: nil, action: nil)
        let saveButton = UIBarButtonItem(title: "保存", style: .Plain, target: self, action: #selector(saveClick))
        toolView.setItems([cancelButton, gapButton, saveButton], animated: false)
    }
    
    // MARK: Action
    
    func dateValueChangedAction() {
        selectDate = pickerView.date
    }
    
    func cancelClick() {
        cancelClosure?()
    }
    
    func saveClick() {
        if let date = selectDate {
            saveClosure?(date)
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        toolView.frame = CGRect(x: 0, y: 0, width: width, height: 44)
        pickerView.frame = CGRect(x: 0, y: 44, width: width, height: 206)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
