//
//  AppointmentViewController.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/4/19.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit

class AppointmentViewController: BaseViewController {

    var categoryData: [HomePageModel] = []
    var orderPrice: Int = 0
    private var selectCategpryData: [HomePageModel] = []
    private var tableView: UITableView = {
        let tableView = UITableView(frame: CGRect.zero, style: UITableViewStyle.Grouped)
        tableView.backgroundColor = UIColor.whiteColor()
        tableView.registerNib(UINib(nibName: "NameTableViewCell", bundle: nil), forCellReuseIdentifier: "NameTableViewCell")
        tableView.registerNib(UINib(nibName: "AddressTableViewCell", bundle: nil), forCellReuseIdentifier: "AddressTableViewCell")
        tableView.registerNib(UINib(nibName: "TimeTableViewCell", bundle: nil), forCellReuseIdentifier: "TimeTableViewCell")
        tableView.registerNib(UINib(nibName: "DescriptionTableViewCell", bundle: nil), forCellReuseIdentifier: "DescriptionTableViewCell")
        tableView.separatorStyle = .None
        tableView.rowHeight = 50.0
        tableView.backgroundColor = UIColor.whiteColor()
        return tableView
    }()
    private var nameStr: String = ""
    var cityID: Int = 0
    private enum sectionType {
        case Name
        case Address
        case Time
        case Description
    }
    private var entity: AddressModel?
    private var selectDate: NSDate?
    private let data: [sectionType] = [.Name, .Address, .Time, .Description]
    
    private let formatter: NSDateFormatter = {
        let formatter = NSDateFormatter()
        formatter.dateFormat = Constants.dateFormat
        return formatter
    }()
    
    deinit {
        tableView.delegate = nil
        tableView.dataSource = nil
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "预约下单"
        tableView.delegate = self
        tableView.dataSource = self
        view.addSubview(tableView)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        tableView.frame = CGRect(x: 0, y: 0, width: Constants.Layout.screenWidth, height: Constants.Layout.screenHeight)
    }

}

extension AppointmentViewController: UITableViewDelegate, UITableViewDataSource {
    
    // MARK: UITableViewDelegate
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        let type = data[indexPath.section]
        switch type {
        case .Name:
            AppoinSheetViewController.showName("name", data: categoryData, saveSuccessClosure: { (datas) in
                self.selectCategpryData = datas
                let index = NSIndexPath(forRow: 0, inSection: 0)
                let cell = tableView.cellForRowAtIndexPath(index) as? NameTableViewCell
                self.nameStr = ""
                for model in datas {
                    if let name = model.category_name {
                        self.nameStr = self.nameStr + name + "、"
                    }
                }
                cell?.contentLabel.text = self.nameStr
                
            })
            
        case .Address:
            let controller = AddressViewController()
            controller.type = "Order"
            controller.didSelect = { (model) in
                self.entity = model
                let index = NSIndexPath(forRow: 0, inSection: 1)
                let cell = tableView.cellForRowAtIndexPath(index) as? AddressTableViewCell
                cell?.setData(model)
                cell?.createOrderUI()
            }
            self.navigationController?.pushViewController(controller, animated: true)
        case .Time:
            AppoinSheetViewController.show("time", saveSuccessClosure: { (date) in
                self.selectDate = date
                let index = NSIndexPath(forRow: 0, inSection: 2)
                let cell = tableView.cellForRowAtIndexPath(index) as? TimeTableViewCell
                cell?.timeLabel.text = self.formatter.stringFromDate(date)
            })
        case .Description:
            return
        }
    }
    
    // MARK: UITableViewDataSource
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return data.count
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let type = data[indexPath.section]
        switch type {
        case .Name:
            let cell = tableView.dequeueReusableCellWithIdentifier("NameTableViewCell", forIndexPath: indexPath) as! NameTableViewCell
            
            return cell
        case .Address:
            let cell = tableView.dequeueReusableCellWithIdentifier("AddressTableViewCell", forIndexPath: indexPath) as! AddressTableViewCell
            cell.setOrderDate()
            cell.createOrderUI()
            return cell
        case .Time:
            let cell = tableView.dequeueReusableCellWithIdentifier("TimeTableViewCell", forIndexPath: indexPath) as! TimeTableViewCell
            
            return cell
        case .Description:
            let cell = tableView.dequeueReusableCellWithIdentifier("DescriptionTableViewCell", forIndexPath: indexPath) as! DescriptionTableViewCell
            cell.didOrderClick = {
                //确认预约
                if let userId = UserInfo.sharedInstance.ID, let address = self.entity?.address, let date = self.selectDate {
                    let dic = ["address": address, "user_id": userId, "appointment_time": date, "city_id": self.cityID]
                    //, "order_number": "\(NSDate().timeIntervalSince1970)"
                    HttpSwift.post("http://www.tchautchau.cn/api/orders", params: dic ) { (data, response, error) in
                        if let data = data {
                            
                            let dic = data.stringToDic
                            if dic.valueForKey("status") as? String == "unprocessable_entity" {
                                HUD.show("保存失败")
                            } else {
                                dispatch_async(dispatch_get_main_queue(), {
                                    HUD.show("预约成功")
                                    self.navigationController?.popToRootViewControllerAnimated(true)
                                })
                            }
                            print(dic)
                        }
                    }
                    
                } else {
                    HUD.show("以上选项不能为空")
                }
            }
            return cell
        }
        
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        let type = data[indexPath.section]
        switch type {
        case .Address:
            return 80
        case .Description:
            return 150
        default:
            return 60
        }
    }
    
    
}
