//
//  OrderDetailViewController.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/5/6.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit

class OrderDetailViewController: BaseTableViewController {
    
    private var data: [OrderItemModel] = []
    var orderID: Int = 0
    var type: Int = 0
    var ordermodel: OrderModel?
    var paySuccessClosure: (Void -> Void)?
    
    deinit {
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.estimatedRowHeight = 60
        title = "订单详情"
        // Do any additional setup after loading the view.
    }
    
    override func registerCell() {
        tableView.registerNib(UINib(nibName: "OrderTableViewCell", bundle: nil), forCellReuseIdentifier: "OrderTableViewCell")
    }
    // get '/api/users/:user_id/statuses/:status/orders'
    override func refreshData() {
        if let id = UserInfo.sharedInstance.ID {
            print(id)
            HttpSwift.request("get", url: "http://www.tchautchau.cn/api/orders/\(orderID)/order_items") { (data, response, error) in
                print(data)
                self.data.removeAll()
                if let data = data {
                    let arr = data.stringToArr
                    for dic in arr {
                        let model = OrderItemModel(dict: dic as! [String : AnyObject])
                        self.data.append(model)
                    }
                    dispatch_async(dispatch_get_main_queue(), {
                        self.tableView.reloadData()
                    })
                    print(arr)
                }
            }
        }
    }
    
    override func loadMoreData() {
        
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        tableView.frame = CGRect(x: 0, y: 0, width: view.width, height: view.height - 50)
        
        }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

extension OrderDetailViewController {
    
    // MARK: UITableViewDataSource
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("OrderTableViewCell", forIndexPath: indexPath) as! OrderTableViewCell
        let model = data[indexPath.row]
        if let ordermodel = ordermodel {
            cell.setItemData(model, order: ordermodel)
        }
        return cell
    }
    
    
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
    }
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let label = UILabel()
        label.textAlignment = .Center
        label.font = UIFont.systemFontOfSize(15)
        if let logistics_name = ordermodel?.logistics_name, let payName = ordermodel?.pay_status_name {
            label.text = "\(logistics_name)_\(payName)"
        }
        return label
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 60
    }
    
    func tableView(tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        
        let payButton = UIButton()
        if ordermodel?.pay_status_name == "未支付" {
            payButton.setTitle("确认支付", forState: .Normal)
        }
//        if type == 2{
//           payButton.setTitle("确认评价", forState: .Normal)
//        }
        payButton.layer.masksToBounds = true
        payButton.layer.cornerRadius = 5
        payButton.backgroundColor = UIColor(hex: 0x4285F4)
        payButton.setTitleColor(UIColor.whiteColor(), forState: .Normal)
        payButton.addTarget(self, action: #selector(self.payClick), forControlEvents: .TouchUpInside)
        payButton.frame = CGRect(x: 40, y: 40, width: UIScreen.mainScreen().bounds.width - 80, height: 50)
        return payButton
    }
    
    func tableView(tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        if data.count == 0 || type == 0 || ordermodel?.pay_status_name == "已支付" {
            return 0
        }
        return 60
    }
    
    func payClick() {
        if let ordermodel = ordermodel {
            OrderSheetViewController.show(ordermodel) { (_) in
                HUD.show("支付成功")
                self.paySuccessClosure?()
                self.navigationController?.popViewControllerAnimated(true)
            }
        }
    }
    
}

