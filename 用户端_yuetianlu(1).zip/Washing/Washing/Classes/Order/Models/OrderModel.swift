//
//  OrderModel.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/4/14.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import Foundation

class OrderModel: NSObject {
    
    var id : Int = 0
    var user_id: Int = 0
    var status: String?
    var item_num: Int?
    var total_price: String?
    var address: String?
    var finished_date: String?
    var appointment_time: String?
    var order_number: String?
    var order_name: String?
    var logistics_name: String?
    var pay_status_name: String?
    //var default: Int = 0
    init(dict : [String : AnyObject]) {
        super.init()
        
        //kvo赋值
        setValuesForKeysWithDictionary(dict)
        //setValuesForKeys(dict)
        
    }
    
    override func setValue(value: AnyObject?, forUndefinedKey key: String) {
        
    }
    
}