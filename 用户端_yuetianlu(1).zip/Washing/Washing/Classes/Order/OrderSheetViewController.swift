//
//  OrderSheetViewController.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/5/6.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit

class OrderSheetViewController: UIViewController, UIViewControllerTransitioningDelegate {
    
    var payView: PayView = {
        let view = PayView.newInstance()
        view.backgroundColor = UIColor.whiteColor()
        return view
    }()
    var couponInfo = CouponEntity(dict: [:])
    var orderModel = OrderModel(dict: [:])
    var successClosure: (Void -> Void)?
    var totalPrice: Float = 0
    var payPrice: Float  = 0
    
    init() {
        super.init(nibName: nil, bundle: nil)
        transitioningDelegate = self
        modalPresentationStyle = .Custom
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func present(animated: Bool = true, completion: (() -> Void)? = nil) {
        UIViewController.topMostViewController()?.presentViewController(self, animated: animated, completion: completion)
    }
    
    // MARK: UIViewControllerTransitioningDelegate
    
    func presentationControllerForPresentedViewController(presented: UIViewController, presentingViewController presenting: UIViewController, sourceViewController source: UIViewController) -> UIPresentationController? {
        return PresentationController(presentedViewController: presented, presentingViewController: presenting)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(payView)

        if let price = orderModel.total_price {
            totalPrice = Float(price)!
            payPrice = totalPrice
            payView.titleLabel.text = "您将支付\(price)元"
        }
        payView.selectCouponClick = {
            let controller = CouponViewController(type: .Purchase)
            controller.didSelectedCouponClosure = { model in
                self.couponInfo = model
                self.payView.couponLabel.text = "优惠\(model.price)元"
                let price = self.totalPrice - Float(model.price)
                self.payPrice = price
                if price < 0 {
                    self.payView.payButton.setTitle("立即支付0元", forState: .Normal)
                } else {
                    self.payView.payButton.setTitle("立即支付\(price)元", forState: .Normal)
                }
                
            }
            let nav = UINavigationController(rootViewController: controller)
            UIViewController.topMostViewController()?.presentViewController(nav, animated: true, completion: nil)
        }
        payView.closeClosure = {
            self.dismissViewControllerAnimated(true, completion: nil)
        }
        payView.payClick = {
            if let userId = UserInfo.sharedInstance.ID, let banlance = UserInfo.sharedInstance.balance {
                let price: Float = Float(banlance)! - self.payPrice
                let dic = ["balance": "\(price)"]
                HttpSwift.post("http://www.tchautchau.cn/api/update/users/\(userId)", params: dic ) { (data, response, error) in
                    if let data = data {
                        let dic = data.stringToDic
                        if dic.valueForKey("status") as? String == "unprocessable_entity" {
                            HUD.show("支付失败")
                        } else {
                            
                            let dic = ["pay_status_id": "1", "finished_date": NSDate()]
                            HttpSwift.post("http://www.tchautchau.cn/api/update/orders/\(self.orderModel.id)", params: dic, callback: { (data, response, error) in
                                dispatch_async(dispatch_get_main_queue(), {
                                    UserInfo.sharedInstance.balance = "\(price)"
                                    HUD.show("支付成功")
                                    self.successClosure?()
                                })

                            })
                            
                        }
                        print(dic)
                    }
                }
            }
            
            self.dismissViewControllerAnimated(true, completion: nil)
        }
        // Do any additional setup after loading the view.
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        payView.left = 0
        payView.bottom = view.bottom
        payView.width = view.width
        payView.height = 300
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    class func show(model:OrderModel, successClosure: (Void -> Void)) {
        let controller = OrderSheetViewController()
        controller.successClosure = successClosure
        controller.orderModel = model
        controller.present()
    }
    
}
