//
//  OrderTableViewCell.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/3/16.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit

class OrderTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var goodLabel: UILabel!
    
    @IBOutlet weak var priceLabel: UILabel!
    
    @IBOutlet weak var dateLabel: UILabel!

    @IBOutlet weak var OrderNumLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func setData(model: OrderModel) {
        OrderNumLabel.text = "订单号暂无"
        goodLabel.text = "暂无"
        priceLabel.text = "¥0元"
        if let date = model.appointment_time {
            dateLabel.text = date
        }
        if let name = model.order_name {
            goodLabel.text = name
        }
      
        if let orderNum = model.order_number {
            OrderNumLabel.text = "订单号：\(orderNum)"
        }
        if let price = model.total_price {
             priceLabel.text = "¥\(price)元"
        }
    }
    
    func setItemData(model: OrderItemModel, order: OrderModel) {
        OrderNumLabel.text = "订单号暂无"
        goodLabel.text = "暂无"
        priceLabel.text = ""
        if let name = model.product_name {
            goodLabel.text = name
        }
        
        if let name = order.pay_status_name {
            priceLabel.text = name
        }
        OrderNumLabel.text = "数量：\(model.number)"
        dateLabel.text = order.finished_date
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
