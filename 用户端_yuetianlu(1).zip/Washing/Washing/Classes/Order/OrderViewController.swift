//
//  OrderViewController.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/3/14.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit

class OrderViewController: BaseTableViewController {
    let Width = UIScreen.mainScreen().bounds.width
    let Height = UIScreen.mainScreen().bounds.height
    private var data: [OrderModel] = []
    
    private enum OrderType {
        case NotFinish
        case Washing
        case Finished
        
    }
    
    private var selectType: Int = 0
    let selectSegment: UISegmentedControl = {
        let segmentView = UISegmentedControl(items: ["未取单", "进行中", "已完成"])
        //默认状态item字的颜色
        let titleTextAttributes = [NSForegroundColorAttributeName : UIColor.blackColor() as AnyObject]
        segmentView.setTitleTextAttributes(titleTextAttributes, forState: UIControlState.Normal)
        //选中状态item字的颜色
        segmentView.setTitleTextAttributes([NSForegroundColorAttributeName : UIColor.whiteColor() as AnyObject], forState: UIControlState.Selected)
        //选中状态item的颜色
        segmentView.tintColor = UIColor(hex: 0x4285F4)
        //momentary＝true显示一下selected state之后恢复普通状态
        segmentView.momentary = false
        //        segmentView.backgroundColor = UIColor.lightGrayColor()
        segmentView.selectedSegmentIndex = 0
        
        return segmentView
    }()
    override var emptyTip: String {
        return "暂无订单"
    }
    
    deinit {

    }
    
    override func registerCell() {
       tableView.registerNib(UINib(nibName: "OrderTableViewCell", bundle: nil), forCellReuseIdentifier: "OrderTableViewCell")
       //tableView.registerClass(OrderTableViewCell.self, forCellReuseIdentifier: "OrderTableViewCell")
    }
    // get '/api/users/:user_id/statuses/:status/orders'
    override func refreshData() {
        if let id = UserInfo.sharedInstance.ID {
            print(id)
            HttpSwift.request("get", url: "http://www.tchautchau.cn/api/users/\(id)/logistics/\(selectType)/orders") { (data, response, error) in
                print(data)
                self.data.removeAll()
                if let data = data {
                    let arr = data.stringToArr
                    for dic in arr {
                        let model = OrderModel(dict: dic as! [String : AnyObject])
                        self.data.append(model)
                    }
                    dispatch_async(dispatch_get_main_queue(), {
                        self.tableView.reloadData()
                    })
                    print(arr)
                }
            }
        }
    }
    
    override func loadMoreData() {
        
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        tableView.frame = CGRect(x: 0, y: 50, width: view.width, height: view.height - 50)
        selectSegment.frame = CGRect(x: 20, y: 10, width: view.width - 40, height: 40)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.estimatedRowHeight = 60
        view.addSubview(selectSegment)
        selectSegment.addTarget(self, action: #selector(segmentValueChanged(_:)), forControlEvents: UIControlEvents.ValueChanged)
       // view.addSubview(tableView)
        // Do any additional setup after loading the view.
    }
    
    func segmentValueChanged(sender:UISegmentedControl){
        debugPrint(sender.selectedSegmentIndex)
        selectType = sender.selectedSegmentIndex
        refreshData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

extension OrderViewController {
    
    // MARK: UITableViewDataSource
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("OrderTableViewCell", forIndexPath: indexPath) as! OrderTableViewCell
        let model = data[indexPath.row]
        cell.setData(model)
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        guard indexPath.row < data.count else {
            return
        }
        let model = data[indexPath.row]
        let controller = OrderDetailViewController()
        controller.type = selectType
        controller.orderID = model.id
        controller.ordermodel = model
        controller.paySuccessClosure = {
            self.refreshData()
        }
        navigationController?.pushViewController(controller, animated: true)
    }
    
}
