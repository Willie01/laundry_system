//
//  PayView.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/5/5.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit

class PayView: UIView {

    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var couponView: UIView!
    
    @IBOutlet weak var couponLabel: UILabel!
    
    @IBOutlet weak var payButton: UIButton!
    
    @IBOutlet weak var closeImageView: UIImageView!
    
    var selectCouponClick: (Void -> Void)?
    var payClick: (Void -> Void)?
    var closeClosure: (Void -> Void)?
    
    static func newInstance() -> PayView{
        
        return NSBundle.mainBundle().loadNibNamed("PayView", owner: self, options: nil).first as! PayView
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        createUI()
    }
    
    private func createUI() {
        payButton.layer.masksToBounds = true
        payButton.layer.cornerRadius = 5
        payButton.backgroundColor = UIColor(hex: 0x4285F4)
        payButton.setTitleColor(UIColor.whiteColor(), forState: .Normal)
        couponLabel.userInteractionEnabled = true
        closeImageView.userInteractionEnabled = true
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.tapClick))
        couponLabel.addGestureRecognizer(tap)
        
        let closeTap = UITapGestureRecognizer(target: self, action: #selector(self.closeClick))
        closeImageView.addGestureRecognizer(closeTap)
        
    }
    
    func tapClick() {
        selectCouponClick?()
    }
    
    func closeClick() {
        closeClosure?()
    }
    
    
    @IBAction func payClick(sender: AnyObject) {
        payClick?()
    }
    
}
