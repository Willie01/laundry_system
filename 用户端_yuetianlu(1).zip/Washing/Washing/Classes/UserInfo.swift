//
//  UserInfo.swift
//  yuetianlu
//
//  Created by yuetianlu on 16/11/29.
//  Copyright © 2016年 yuetianlu. All rights reserved.
//

import Foundation



class UserInfo {
    
    var ID: Int?
    var Name: String?
    var Phone: String?
    var Password: String?
    var balance: String?
    var email: String?
    var portrait: String?
    
    static let sharedInstance = UserInfo()
    private init() {} // 这就阻止其他对象使用这个类的默认的'()'初始化方法
}
