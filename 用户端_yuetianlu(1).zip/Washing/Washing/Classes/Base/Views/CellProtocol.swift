//
//  CellProtocol.swift
//  Client
//
//  Created by paul on 16/8/1.
//  Copyright © 2016年 36Kr. All rights reserved.
//

//import Foundation
//import UIKit
//
//protocol CellProtocol {
//    func setData(data: CellData)
//}
//
//extension UITableViewCell {
//    
//    static var reuseIdentifier: String {
//        return String(self)
//    }
//    
//}
//
//extension UICollectionViewCell {
//    
//    static var reuseIdentifier: String {
//        return String(self)
//    }
//    
//}
//
//extension UITableViewHeaderFooterView {
//    
//    static var reuseIdentifierForClass: String {
//        return String(self)
//    }
//    
//}