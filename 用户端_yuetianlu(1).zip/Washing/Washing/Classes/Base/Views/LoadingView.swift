//
//  LoadingView.swift
//  Client
//
//  Created by aidenluo on 1/14/16.
//  Copyright © 2016 36Kr. All rights reserved.
//

import UIKit
//import SVProgressHUD

enum LoadingState {
    case Initial
    case Loading
    case Success
    case Fail
    case Empty
}

class LoadingView: UIView {
    
    var indicatorCenterYOffset: CGFloat = -64
    var imageViewCenterYOffset: CGFloat = 0
    
    let indicator: UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage(named: "ic_toast_loading")?.imageWithRenderingMode(.AlwaysTemplate)
        imageView.clipsToBounds = true
        imageView.contentMode = .ScaleAspectFit
        imageView.tintColor = UIColor(hex: 0x464c56)
        imageView.size = CGSizeMake(25, 25)
        return imageView
    }()
    
    let imageView: UIImageView = {
        let view = UIImageView()
        view.image = UIImage(named: "ic_common_placeholder_nodata")
        view.sizeToFit()
        view.hidden = true
        return view
    }()
    
    let label: UILabel = {
        let view = UILabel()
        view.backgroundColor = UIColor.clearColor()
        view.font = UIFont.systemFontOfSize(14)
        view.textColor = UIColor(hex: 0x969fa9)
        view.numberOfLines = 0
        view.text = "服务器开小差，没有拿到数据\n\n请点击屏幕再试一次"
        view.textAlignment = .Center
        view.sizeToFit()
        view.hidden = true
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.whiteColor()
        addSubview(indicator)
        addSubview(imageView)
        addSubview(label)
    }
    
    var loadingState: LoadingState = .Initial {
        didSet {
            switch loadingState {
            case .Loading:
                if indicator.layer.actionForKey("progressAnimation") == nil {
                   // indicator.layer.addAnimation(PKHUDAnimation.continuousRotation(), forKey: "progressAnimation")
                }
                imageView.hidden = true
                label.hidden = true
                indicator.hidden = false
            case .Fail:
                indicator.hidden = true
                imageView.hidden = false
                label.hidden = false
            case .Empty:
                indicator.hidden = true
                imageView.hidden = false
                label.hidden = false
            default: break
            }
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        indicator.center = CGPointMake(CGRectGetMidX(bounds), CGRectGetMidY(bounds) + indicatorCenterYOffset)
        imageView.center = CGPointMake(CGRectGetMidX(bounds), CGRectGetMidY(bounds))
        imageView.top = 144 + imageViewCenterYOffset
        label.width = width - 40
        label.center = CGPointMake(CGRectGetMidX(bounds), CGRectGetMidY(bounds))
        label.top = imageView.bottom + 10
    }

}
