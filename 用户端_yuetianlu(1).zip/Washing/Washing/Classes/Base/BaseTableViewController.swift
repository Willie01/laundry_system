//
//  BaseTableViewController.swift
//  Client
//
//  Created by paul on 16/8/1.
//  Copyright © 2016年 36Kr. All rights reserved.
//

import UIKit

private var BaseTableViewControllerContext = 0

class BaseTableViewController: BaseViewController, UITableViewDelegate, UITableViewDataSource {
    
    var tableView: UITableView!
    
    var reloadEnabled: Bool {
        return true
    }
    var loadMoreEnabled: Bool {
        return true
    }
    
    // MARK: Lifecycle
    
    deinit {
        tableView.delegate = nil
        tableView.dataSource = nil
    }
    
    init(tableView: UITableView) {
        super.init(nibName: nil, bundle: nil)
        commonInit(tableView)
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: NSBundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        commonInit(nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func commonInit(tableView: UITableView?) {
        if tableView == nil {
            self.tableView = UITableView(frame: CGRect.zero, style: UITableViewStyle.Plain)
        } else {
            self.tableView = tableView
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(tableView)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .SingleLine
        tableView.separatorColor = UIColor(hex: 0xf0f0f0)
        tableView.separatorInset = UIEdgeInsetsMake(0, 20, 0, 20)
        tableView.tableFooterView = UIView()
//        if reloadEnabled {
//            refreshData()
//        }
        registerCell()
        loadingState = .Success
        loadingData()
    }
    
    // MARK: Layout
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        tableView.frame = CGRect(x: 0, y: 0, width: view.width, height: view.height)
    }
    
    
    override func loadingData() {
        refreshData()
    }
    
    func refreshData() {
        assertionFailure("must override this")
    }
    
    func loadMoreData() {
        assertionFailure("must override this")
    }
    
    func reloadTableView() {
        tableView.reloadData()
    }
    
    func registerCell() {
        assertionFailure("must override this")
    }

    
    // MARK: UITableViewDataSource
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 0
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        return UITableViewCell()
    }
    
}

