//
//  BaseViewController.swift
//  Client
//
//  Created by aidenluo on 7/28/16.
//  Copyright © 2016 36Kr. All rights reserved.
//

import UIKit

class BaseViewController: UIViewController {
    
    //子类重写提供空页面图片
    var emptyImageName: String {
        return "ic_common_placeholder_nodata"
    }
    
    var emptyImageEnable: Bool {
        return true
    }
    
    var emptyNeedClickReload: Bool {
        return false
    }
    
    //子类重写提供空页面提示文字
    var emptyTip: String {
        return "暂无数据"
    }
    
    var loadingViewBelowView: UIView? {
        return nil
    }
    
    var loadingState: LoadingState = .Initial {
        didSet {
            loadingView.loadingState = loadingState
            loadingStateDidChange(loadingState)
            switch loadingState {
            case .Loading:
                view.bringSubviewToFront(loadingView)
                if let coverView = loadingViewBelowView {
                    view.insertSubview(loadingView, belowSubview: coverView)
                }
                loadingView.hidden = false
            case .Success:
                view.sendSubviewToBack(loadingView)
                loadingView.hidden = true
            case .Fail:
                view.bringSubviewToFront(loadingView)
                if let coverView = loadingViewBelowView {
                    view.insertSubview(loadingView, belowSubview: coverView)
                }
                loadingView.hidden = false
                loadingView.imageView.image = emptyImageEnable ? UIImage(named: "ic_common_placeholder_pagemissing") : nil
                loadingView.label.text = NSLocalizedString("点击屏幕，重新加载", comment: "")
                loadingView.label.sizeToFit()
            case .Empty:
                view.bringSubviewToFront(loadingView)
                if let coverView = loadingViewBelowView {
                    view.insertSubview(loadingView, belowSubview: coverView)
                }
                loadingView.hidden = false
                loadingView.imageView.image = emptyImageEnable ? UIImage(named: emptyImageName) : nil
                loadingView.label.text = emptyTip
                loadingView.label.sizeToFit()
            default:
                view.sendSubviewToBack(loadingView)
                loadingView.hidden = true
            }
        }
    }
    
    var loadingView: LoadingView!
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        trackViewDidAppear()
        setNeedsStatusBarAppearanceUpdate()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        rt_disableInteractivePop = false
        view.backgroundColor = UIColor.whiteColor()
        loadingView = LoadingView(frame: view.bounds)
        loadingView.imageView.image = UIImage(named: emptyImageName)
        loadingView.label.text = emptyTip
        loadingView.frame = view.bounds
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.loadingViewTap))
        loadingView.addGestureRecognizer(tap)
        view.addSubview(loadingView)
        loadingState = .Success
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        loadingView.frame = view.bounds
    }
    
    func loadingStateDidChange(state: LoadingState) {
        
    }
    
    func loadingViewTap() {
        if loadingState == .Fail || (loadingState == .Empty && emptyNeedClickReload) {
            loadingState = .Loading
            loadingData()
        }
    }
    
    func loadingData() {
        
    }
    
    override var hidesBottomBarWhenPushed: Bool {
        get {
            return navigationController?.childViewControllers.count > 1
        }
        set {
            super.hidesBottomBarWhenPushed = true
        }
    }
    
    override func preferredStatusBarStyle() -> UIStatusBarStyle {
        return .Default
    }
    
    override func prefersStatusBarHidden() -> Bool {
        return false
    }
    
    override func preferredStatusBarUpdateAnimation() -> UIStatusBarAnimation {
        return .Fade
    }
    
    func trackViewDidAppear() {
        
    }
    
    func userInfo(dic: NSDictionary) {
        UserInfo.sharedInstance.ID = dic.valueForKey("id") as? Int
        print(UserInfo.sharedInstance.ID)
        UserInfo.sharedInstance.Name = dic.valueForKey("username") as? String
        UserInfo.sharedInstance.Phone = dic.valueForKey("telphone") as? String
        UserInfo.sharedInstance.Password = dic.valueForKey("password") as? String
        UserInfo.sharedInstance.balance = dic.valueForKey("balance") as? String
        UserInfo.sharedInstance.email = dic.valueForKey("email") as? String
        UserInfo.sharedInstance.portrait = dic.valueForKey("portrait") as? String
    }
    
}