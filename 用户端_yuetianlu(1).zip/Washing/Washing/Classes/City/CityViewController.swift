//
//  CityViewController.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/5/5.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit

class CityViewController: BaseTableViewController {
    
    var cityData: [CityModel] = []
    var selectFinishClosure: (CityModel -> Void)?
    
    deinit {
        
    }
    
    override func registerCell() {
        tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: "CityCell")
    }
    
    override func refreshData() {
        HttpSwift.request("get", url: "http://www.tchautchau.cn/api/cities") { (data, response, error) in
            print(data)
            if let data = data {
                
                let arr = data.stringToArr
                for dic in arr {
                    let model = CityModel(dict: dic as! [String : AnyObject])
                    self.cityData.append(model)
                }
                
                dispatch_async(dispatch_get_main_queue(), {
                    self.tableView.reloadData()
                })
            }
        }
    }
    
    override func loadMoreData() {
        
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        tableView.frame = CGRect(x: 0, y: 0, width: view.width, height: view.height)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "城市选择"
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

extension CityViewController {
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cityData.count
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 60
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        guard indexPath.row < cityData.count else {
            return UITableViewCell()
        }
        let cell = tableView.dequeueReusableCellWithIdentifier("CityCell", forIndexPath: indexPath) 
        let model = cityData[indexPath.row]
        cell.textLabel?.text = model.city_name
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        let model = cityData[indexPath.row]
        selectFinishClosure?(model)
        NSUserDefaults.standardUserDefaults().setObject(model.id, forKey: "cityID")
        self.navigationController?.popViewControllerAnimated(true)
    }
}
