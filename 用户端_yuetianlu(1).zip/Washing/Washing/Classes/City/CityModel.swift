//
//  CityModel.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/5/5.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import Foundation

class CityModel: NSObject {
    
    var id : Int = 1
    var region_id: Int = 1000
    var city_name: String?

    init(dict : [String : AnyObject]) {
        super.init()
        
        //kvo赋值
        setValuesForKeysWithDictionary(dict)
        //setValuesForKeys(dict)
        
    }
    
    override func setValue(value: AnyObject?, forUndefinedKey key: String) {
        
    }
    
}