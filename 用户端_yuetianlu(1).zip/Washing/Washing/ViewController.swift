//
//  ViewController.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/3/14.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit
import CoreLocation
class ViewController: UIViewController {

    var locationManager = CLLocationManager()
    var currLocation: CLLocation?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.yellowColor()
        loadLocation()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension ViewController: CLLocationManagerDelegate {
    //打开定位
    func loadLocation()
    {
        locationManager.delegate = self
        //定位方式
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        //始终允许访问位置信息
        locationManager.requestAlwaysAuthorization()
        //使用应用程序期间允许访问位置数据
        locationManager.requestWhenInUseAuthorization()
        //开启定位
        locationManager.startUpdatingLocation()
    }
    
    //获取定位信息
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        //取得locations数组的最后一个
        let location:CLLocation = locations[locations.count-1]
        currLocation = locations.last!
        //判断是否为空
        if(location.horizontalAccuracy > 0){
            let lat = Double(String(format: "%.1f", location.coordinate.latitude))
            let long = Double(String(format: "%.1f", location.coordinate.longitude))
            print("纬度:\(long!)")
            print("经度:\(lat!)")
            LonLatToCity()
            //停止定位
            locationManager.stopUpdatingLocation()
        }
    }
    
    //出现错误
    func locationManager(manager: CLLocationManager, didFinishDeferredUpdatesWithError error: NSError?) {
        print(error)
    }
    
    ///将经纬度转换为城市名
    func LonLatToCity() {
        let geocoder: CLGeocoder = CLGeocoder()
        geocoder.reverseGeocodeLocation(currLocation ?? CLLocation()) { (placemark, error) -> Void in
            
            if(error == nil) {
                let array = placemark! as NSArray
                let mark = array.firstObject as! CLPlacemark
                //城市
                let city: String = (mark.addressDictionary! as NSDictionary).valueForKey("City") as! String
                //国家
                let country: NSString = (mark.addressDictionary! as NSDictionary).valueForKey("Country") as! NSString
                //国家编码
                // let CountryCode: NSString = (mark.addressDictionary! as NSDictionary).valueForKey("CountryCode") as! NSString
                //街道位置
                let FormattedAddressLines: NSString = (mark.addressDictionary! as NSDictionary).valueForKey("FormattedAddressLines")?.firstObject as! NSString
                //具体位置
                let Name: NSString = (mark.addressDictionary! as NSDictionary).valueForKey("Name") as! NSString
                //省
                var State: String = (mark.addressDictionary! as NSDictionary).valueForKey("State") as! String
                //区
                let SubLocality: NSString = (mark.addressDictionary! as NSDictionary).valueForKey("SubLocality") as! NSString
                //如果需要去掉“市”和“省”字眼
                State = State.stringByReplacingOccurrencesOfString("省", withString: "")
                let citynameStr = city.stringByReplacingOccurrencesOfString("市", withString: "")
                print("\(city)+\(country)+\(FormattedAddressLines)+\(Name)+\(State)+\(SubLocality)")
                
            } else {
                print(error)
            }
        }
    }
    
}

/*
 
 
 struct UpdateUserProfileRequest: TargetType {
 var info: UserBasicInfo
 
 init(info: UserBasicInfo) {
 self.info = info
 }
 
 init(info: (Void -> UserBasicInfo)) {
 self.info = info()
 }
 
 var baseURL: NSURL {
 return Constants.Network.NewsAPI
 }
 
 var path: String {
 if let uid = info.uid {
 return "user/\(uid)"
 }
 return "user/\(info.uid)"
 }
 
 var method: Moya.Method {
 return .PUT
 }
 
 var parameters: [String: AnyObject]? {
 var params = [String : AnyObject]()
 
 if let sex = info.sex {
 params["sex"] = sex
 }
 if let job = info.job {
 params["job"] = job
 }
 if let industry = info.industry {
 params["industry"] = industry
 }
 if let birthday	 = info.birthday {
 params["birthday"] = birthday
 }
 return params
 }
 
 var sampleData: NSData {
 return NSData()
 }
 
 var multipartBody: [Moya.MultipartFormData]? {
 return nil
 }
 
 }
 */