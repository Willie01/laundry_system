//
//  AppDelegate.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/3/14.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit
import RTRootNavigationController
@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        // Override point for customization after application launch.
        setupAppearance()
        rootController(rootType.Tab)
        return true
    }
    
    func rootController(type: rootType) {
        switch type {
        case .Tab:
            let tabBarController = TabbarViewController()
            let rootVC = RTRootNavigationController(rootViewControllerNoWrapping: tabBarController)
            rootVC.useSystemBackBarButtonItem = true
            window?.rootViewController = rootVC
        case .Login:
            window?.rootViewController = LoginViewController()
        }
        
    }

    func applicationWillResignActive(application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(application: UIApplication) {
        // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }


}

// MARK: - Appearance
extension AppDelegate {
    
    func setupAppearance() {
        UINavigationBar.appearance().translucent = false
        UINavigationBar.appearance().barTintColor = Constants.Color.navBarColor
        UINavigationBar.appearance().tintColor = UIColor(hex: 0x212121)
        let backArrow = UIImage(named: "ic_common_nav_back_offset")
        UINavigationBar.appearance().backIndicatorImage = backArrow
        UINavigationBar.appearance().backIndicatorTransitionMaskImage = backArrow
        UIBarButtonItem.appearance().setBackButtonTitlePositionAdjustment(UIOffset(horizontal: CGFloat.max, vertical: CGFloat.max), forBarMetrics: .Default)
        UIBarButtonItem.appearanceWhenContainedInInstancesOfClasses([UINavigationBar.self]).setTitleTextAttributes([NSFontAttributeName : UIFont.systemFontOfSize(15, weight: UIFontWeightRegular)], forState: UIControlState.Normal)
        UITabBar.appearance().translucent = false
        UITabBarItem.appearance().setTitleTextAttributes([NSForegroundColorAttributeName : UIColor(hex: 0x969fa9)], forState: UIControlState.Normal)
        UITabBarItem.appearance().setTitleTextAttributes([NSForegroundColorAttributeName : Constants.Color.tabbarSelect], forState: UIControlState.Selected)
        let tableViewSelectedBackgroundView = UIView()
        tableViewSelectedBackgroundView.backgroundColor = UIColor(hex: 0xf0f0f0)
        UITableViewCell.appearance().selectedBackgroundView = tableViewSelectedBackgroundView
    }
    
}

