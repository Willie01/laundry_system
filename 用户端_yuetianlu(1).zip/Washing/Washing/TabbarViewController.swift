//
//  TabbarViewController.swift
//  Washing
//
//  Created by BJQXDN0527 on 2017/3/14.
//  Copyright © 2017年 yuetainlu. All rights reserved.
//

import UIKit
import RTRootNavigationController

class TabbarViewController: UITabBarController {

    private var controller: HomePageViewController = HomePageViewController()
    private var orderController: OrderViewController = OrderViewController()
    private var personalController: PersonalViewController = PersonalViewController()
    private var meTab: RTContainerNavigationController!
    private var orderTab: RTContainerNavigationController!
    private var personalTab: RTContainerNavigationController!
    override func viewDidLoad() {
        super.viewDidLoad()
        initControllers()
        setupControllers()

        // Do any additional setup after loading the view.
    }
    
    private func initControllers() {
        controller.title = "首页"
        meTab = RTContainerNavigationController(rootViewController: controller)
        meTab.tabBarItem.title = "首页"
        meTab.tabBarItem.image = UIImage(named: "btn_first_home_normal")?.imageWithRenderingMode(UIImageRenderingMode.AlwaysOriginal)
        meTab.tabBarItem.selectedImage = UIImage(named: "btn_first_home_select")?.imageWithRenderingMode(UIImageRenderingMode.AlwaysOriginal)
        self.meTab.tabBarItem.setTitleTextAttributes([NSForegroundColorAttributeName : UIColor.redColor()], forState: UIControlState.Selected)
        orderController.title = "我的订单"
        orderTab = RTContainerNavigationController(rootViewController: orderController)
        orderTab.tabBarItem.title = "订单"
        orderTab.tabBarItem.image = UIImage(named: "bnt_first_shopcart_normal")?.imageWithRenderingMode(UIImageRenderingMode.AlwaysOriginal)
        orderTab.tabBarItem.selectedImage = UIImage(named: "bnt_first_shopcart_select")?.imageWithRenderingMode(UIImageRenderingMode.AlwaysOriginal)
        self.orderTab.tabBarItem.setTitleTextAttributes([NSForegroundColorAttributeName : UIColor.redColor()], forState: UIControlState.Selected)
        personalTab = RTContainerNavigationController(rootViewController: personalController)
        personalTab.tabBarItem.title = "个人中心"
        personalController.title = "个人中心"
        personalTab.tabBarItem.image = UIImage(named: "bnt_first_personcenter_normal")?.imageWithRenderingMode(UIImageRenderingMode.AlwaysOriginal)
        personalTab.tabBarItem.selectedImage = UIImage(named: "bnt_first_personcenter_select")?.imageWithRenderingMode(UIImageRenderingMode.AlwaysOriginal)
        self.personalTab.tabBarItem.setTitleTextAttributes([NSForegroundColorAttributeName : UIColor.redColor()], forState: UIControlState.Selected)
        
    }
    
    private func setupControllers() {
        var controllers = [UIViewController]()
        controllers.append(meTab)
        controllers.append(orderTab)
        controllers.append(personalTab)
        setViewControllers(controllers, animated: true)
        //selectIndex(0)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

/*extension TabbarViewController {
    
    class func currentController() -> TabBarController? {
        guard let navigationController = (UIApplication.sharedApplication().delegate as? AppDelegate)?.window?.rootViewController as? RTRootNavigationController,
            let tabBarController = navigationController.viewControllers.first as? TabBarController else {
                return nil
        }
        return tabBarController
    }
    
    func viewControllerForIndex(index: TabBarIndex) -> UIViewController? {
        if let i = tabBarIndex.indexOf(index) where i >= 0 && i < tabBarIndex.count {
            return viewControllers?[i]
        }
        return nil
    }
    
    func selectIndex(index: TabBarIndex) {
        if let i = tabBarIndex.indexOf(index) {
            selectedIndex = i
        }
    }
    
    func setUnreadBadge(unread: Bool, atIndex index: TabBarIndex) {
        guard let i = tabBarIndex.indexOf(index) where i < viewControllers?.count else {
            return
        }
        guard let tabBarItem = viewControllers?[i].tabBarItem else {
            return
        }
        tabBarItem.setUnreadState(unread)
    }
    
}

extension TabbarViewController: UITabBarControllerDelegate {
    
    func tabBarController(tabBarController: UITabBarController, shouldSelectViewController viewController: UIViewController) -> Bool {
        if tabBarController.selectedViewController == viewController {
            if let nvc = tabBarController.selectedViewController as? UINavigationController {
                nvc.childViewControllers.first?.contentScollerView?.beiginRefresh()
            }
        }
        return !tabBarController.selectedViewController!.isEqual(viewController)
    }
    
}
 //            isPayButtonAnimating = true
 //            self.payButton.left = 10
 //            UIView.animateWithDuration(1, delay: 0, usingSpringWithDamping: 0.15, initialSpringVelocity: 0, options: UIViewAnimationOptions(), animations: {
 //                self.payButton.center.x = self.width / 2
 //                }, completion: { (_) in
 //                    self.isPayButtonAnimating = false
 //                    self.payButton.purchasingState = .Failed
 //                    self.purchasingState = .Purchase
 //            })
 
 */
